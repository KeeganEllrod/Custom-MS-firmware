/* $Id: ms2_extra_can.c,v 1.55 2016/08/22 15:57:25 jsmcortina Exp $
 * Copyright 2006, 2007, 2008, 2009, 2010, 2011, 2012, 2013
 * James Murray and Kenneth Culver
 *
 * This file is a part of MS2/Extra.
 *
 * CanInit()
    Origin: Al Grippo.
    Minor: XEPisms by James Murray
    Majority: Al Grippo
 * can_sendburn()
    Origin: Al Grippo.
    Majority: Re-write James Murray
    Majority: James Murray
 * can_crc32()
    Origin: Code by James Murray using MS-CAN framework.
    Majority: James Murray
 * can_reqdata()
    Origin: Al Grippo.
    Majority: Re-write James Murray
    Majority: James Murray
 * can_snddata()
    Origin: Al Grippo.
    Majority: Re-write James Murray
    Majority: James Murray
 * can_sndMSG_PROT()
    Origin: James Murray
    Majority: James Murray
 * can_sndMSG_SPND()
    Origin: James Murray
    Majority: James Murray
 * can_poll()
    Origin: Jean Belanger
    Moderate: XEPisms by James Murray
    Majority: Jean Belanger / James Murray
 * send_can11bit()
    Origin: "stevevp" used with permission
    Majority: Complete re-write James Murray
 * send_can29bit()
    Origin: send_can11bit()
    Majority: Re-write to 29bit, James Murray
 * can_broadcast()
    Origin: "stevevp" used with permission
    Moderate: James Murray
    Majority: stevevp / James Murray
 * can_bcast_outpc_cont()
    Origin: James Murray
    Majority: James Murray
 * can_bcast_outpc()
    Origin: James Murray
    Majority: James Murray
* can_do_tx()
    Origin: James Murray
    Majority: James Murray
* can_build_msg()
    Origin: James Murray
    Majority: James Murray
* can_build_msg_req()
    Origin: James Murray
    Majority: James Murray
* chk_crc
    Origin: James Murray
    Majority: James Murray
* can_build_outmsg
    Origin: Al Grippo
    Majority: Al Grippo / Jean Belanger / James Murray
* can_dashbcast()
    Origin: James Murray
    Majority: James Murray

 *
 * You should have received a copy of the code LICENSE along with this source,
 * ask on the www.msextra.com forum if you did not.
 *
 */
#include "ms2_extra.h"

#define CAN_INC_TXRING \
    can_tx_num++; /* Increment count */\
    can_tx_in++; /* Next ring buffer slot */\
    if (can_tx_in >= NO_CANTXMSG) {\
        can_tx_in = 0;\
    }

void CanInit(void)
{
    unsigned int ix;
    /* Set up CAN communications */
    /* Enable CAN, set Init mode so can change registers */
    CANCTL1 |= 0x80;
    CANCTL0 |= 0x01;

    can_error = 0;
    can_error_cnt = 0;
    flagbyte3 &= ~(flagbyte3_can_reset | flagbyte3_sndcandat | flagbyte3_getcandat);

    while(!(CANCTL1 & 0x01));  // make sure in init mode

    /* Set Can enable, use IPBusclk (24 MHz),clear rest */
    CANCTL1 = 0xC0;  
    /* Set timing for .5Mbits/ sec */
    CANBTR0 = 0xC2;  /* SJW=4,BR Prescaler= 3(24MHz CAN clk) */
    CANBTR1 = 0x1C;  /* Set time quanta: tseg2 =2,tseg1=13 
                        (16 Tq total including sync seg (=1)) */
    CANIDAC = 0x00;   /* 2 32-bit acceptance filters */
    /* CAN message format:
     * Reg Bits: 7 <-------------------- 0
     * IDR0:    |---var_off(11 bits)----|  (Header bits 28 <-- 21)
     * IDR1:    |cont'd 1 1 --msg type--|  (Header bits 20 <-- 15)
     * IDR2:    |---From ID--|--To ID---|  (Header bits 14 <--  7)
     * IDR3:    |--var_blk-|--spare--rtr|  (Header bits  6 <-- 0,rtr)
     */  
    /* Set identifier acceptance and mask registers to accept 
       messages only for can_id or device #15 (=> all devices) */
    /* 1st 32-bit filter bank-to mask filtering, set bit=1 */
    CANIDMR0 = 0xFF;           // anything ok in IDR0(var offset)
    CANIDAR1 = 0x18;           // 0,0,0,SRR=IDE=1
    CANIDMR1 = 0xE7;		   // anything ok for var_off cont'd, msgtype
    CANIDAR2 = CANid;     // rcv msg must be to can_id, but
    CANIDMR2 = 0xF0;			 // can be from any other device
    CANIDMR3 = 0xFF;           // any var_blk, spare, rtr
    /* 2nd 32-bit filter bank */
    CANIDMR4 = 0xFF;           // anything ok in IDR0(var offset)
    CANIDAR5 = 0x18;           // 0,0,0,SRR=IDE=1
    CANIDMR5 = 0xE7;		   // anything ok for var_off cont'd, msgtype
    CANIDAR6 = 0x0F;			 // rcv msg can be to everyone (id=15), and
    CANIDMR6 = 0xF0;			 // can be from any other device
    CANIDMR7 = 0xFF;           // any var_blk, spare, rtr

    /* clear init mode */
    CANCTL0 &= 0xFE;  
    /* wait for synch to bus */
    ix = 0;
    while ((!(CANCTL0 & 0x10)) && (ix < 0xfffe)) {
        ix++;
        asm("nop");
        asm("nop");
        asm("nop");
        asm("nop");
    }
    if (ix == 0xfffe) { // Did not sync in time
        // CAN broken
        conf_err = 54;
    }

    CANTIER = 0; /* Do not enable TX interrupts */
    /* clear RX flag to ready for CAN recv interrupt */
    CANRFLG = 0xC3;
    CANRIER = 0x01; /* set CAN rcv full interrupt bit */

    can_tx_in = 0;
    can_tx_out = 0;
    can_tx_num = 0;
    return;
}

unsigned int can_sendburn(unsigned int table, unsigned int id)
{
    unsigned int ret;
    unsigned char tmp_data[8];
    /* Must be called with interrupts disabled */
    ret = can_build_msg(MSG_BURN, id, table, 0, 0, (unsigned char *)&tmp_data, 0);
    flagbyte3 |= flagbyte3_getcandat;
    can_getid = id;
    cp_time = (unsigned int)lmms;
    flagbyte22 |= FLAGBYTE22_REMOTEBURN;

    return ret;
}

unsigned int can_crc32(unsigned int table, unsigned int id)
{
    unsigned int ret;
    unsigned char tmp_data[8];
    /* Must be called with interrupts disabled */
    tmp_data[0] = MSG_CRC;
    tmp_data[1] = 6; /* Send back to table 6 */
    tmp_data[2] = 0; /* Send back to offset 0 at this time */
    tmp_data[3] = 4; /* Always 4 bytes */

    ret = can_build_msg(MSG_XTND, id, table, 0, 4, (unsigned char *)&tmp_data, 0);

    flagbyte3 |= flagbyte3_getcandat;
    can_getid = id;
    cp_time = (unsigned int)lmms;
    return ret;
}

unsigned int can_reqdata(unsigned int table, unsigned int id, unsigned int offset, unsigned char num)
{
    /* Must be called with interrupts disabled */
    /* Create the first read in a series of passthrough requests */
    unsigned int ret;

    if ((num) && (num <= 8)) {
        ret = can_build_msg_req(id, table, offset, 6, 0, num);

        flagbyte3 |= flagbyte3_getcandat;
        can_getid = id;
        cp_time = (unsigned int)lmms;
    } else {
        ret = 1;
    }
    return ret;
}

unsigned int can_snddata(unsigned int table, unsigned int id, unsigned int offset, unsigned char num, unsigned int bufad)
{
    unsigned int ret;
    /* Must be called with interrupts disabled */
    /* Send data */
    /* called from serial.c and can.c  */

    if ((num) && (num <= 8)) {
        ret = can_build_msg(MSG_CMD, id, table, offset, num, (unsigned char *)bufad, 1); /* passthrough action */

        cp_time = (unsigned int)lmms;
    } else {
        ret = 1;
    }
    return ret;
}

unsigned int can_sndMSG_PROT(unsigned int id, unsigned char sz)
{
    unsigned int ret;
    unsigned char tmp_data[8];
    /* Must be called with interrupts disabled */

    tmp_data[0] = MSG_PROT;
    tmp_data[1] = 6; /* Send back to table 6 */
    tmp_data[2] = 0; /* Send back to offset 0 at this time */
    tmp_data[3] = sz; /* # bytes - either 1 (just protocol no.) or 5 (block sizes as well) */

    ret = can_build_msg(MSG_XTND, id, 0, 0, 4, (unsigned char *)&tmp_data, 0);

    flagbyte3 |= flagbyte3_getcandat;
    can_getid = id;
    cp_time = (unsigned int)lmms;
    return ret;
}

unsigned int can_sndMSG_SPND(unsigned int onoff)
{
    /* Send a message to CANid=15. This may not be supported on receiving end. */
    unsigned int ret;
    unsigned char tmp_data[8];

    tmp_data[0] = onoff;
    ret = can_build_msg(MSG_SPND, 15, 0, 0, 1, (unsigned char *)&tmp_data, 0);

    return ret;
}

void can_poll_remote(void)
{
    /***************************************************************************
     **
     **  CAN polling from I/O slave device
     **
     **************************************************************************/
    /* CAN message set up as follows
     * cx_msg_type = type of message being sent. MSG_REQ is a request for data
     * cx_dest = remote CANid that we are sending message to
     * cx_destvarblk = which variable block (page) to get data from. page 6 = realtime data, outpc
     * cx_destvaroff = offset within that datablock
     * cx_datbuf = a buffer for the data we are sending, none for a request, eight maximum.
     * cx_varbyt = number of bytes sent or requested
     * cx_myvarblk = the variable block to put the reply in (the other end sends a message back with this block no)
     * cx_myvaroff = the variable offset to put the reply in (the other end sends a message back with this block no)
     *
     * With MSG_REQ we send all of that info off and then the other end replies with a MSG_RSP including the variable block and offset
     * to tell us where to deposit the data, kind of like a "push" of the data. We then (blindly) store it where the MSG_RSP asked us to.
     * In the code below we are asking the GPIO board for the raw ADC data and then store it in outpc.gpioadc[] which are then available for
     * use in the code and are also sent to the tuning software as part of the realtime data pack.
     */

    unsigned int ix, off, dest;
    unsigned char num, tmp_data[8];

    if (can_tx_num >= NO_CANTXMSG_POLLMAX) {
        return; /* Queue too full - don't broadcast now */
    }

    // load ring buffer - send request for data
    if ((flash4.can_poll == 1) && (flash4.enable_poll & 0x03)) {
        // Get remote ADC data (GPIO, MS2/Extra slave, Generic board with ADC polling enabled)
        for (ix=0 ; ix<2 ; ix++) { // loop to make two 8 byte transfer for all 8 words
            if (flash4.enable_poll & (ix+1)) {
                off = (unsigned short)(&outpc.gpioadc[0]) - (unsigned short)(&outpc) + (ix*8); // this is offset of where to store it
                (void)can_build_msg_req(flash4.can_poll_id[ix], flash4.poll_tables[ix], flash4.poll_offset[ix], 7, off, 8);
            }
        }
    }
    if ((flash4.can_poll == 1) && (flash4.enable_poll & 0x04)) {
        // Get remote PWM data from Generic board
        off = (unsigned short)(&outpc.gpiopwmin[0]) - (unsigned short)(&outpc); // this is offset of where to store it
        (void)can_build_msg_req(flash4.can_poll_id[2], flash4.poll_tables[2], flash4.poll_offset[2], 7, off, 8);
    }
    if ((flash4.can_poll == 1) && (flash4.enable_poll & 0x08) && ((flash4.ports_dir & 0x0F) < 7)) {
        // Get remote ports data from Generic board
        if ((flash4.ports_dir & 0x0F) == 0) {
            // 3 inputs
            dest = flash4.poll_offset[3];  // fetch raw port from user defined offset
            num = 3;    // 3 bytes to be returned
            ix = 0;
        } else if ((flash4.ports_dir & 0x0F) == 1) {
            // 2 inputs
            dest = flash4.poll_offset[3] + 1;  // fetch raw port from user defined offset
            num = 2;    // 2 bytes to be returned
            ix = 1;
        } else {
            // 1 input
            dest = flash4.poll_offset[3] + 2;  // fetch raw port from user defined offset
            num = 1;    // 1 bytes to be returned
            ix = 2;
        }

        off = (unsigned short)(&outpc.gpioport[ix]) - (unsigned short)(&outpc); // this is offset of where to store it
        (void)can_build_msg_req(flash4.can_poll_id[3], flash4.poll_tables[3], dest, 7, off, num);

    }
    if ((flash4.can_poll == 1) && (flash4.enable_poll & 0x08) && (flash4.ports_dir & 0x0F)) {
        // Update PWM idle if used
        if (flash5.pwmidle_port) {
            outpc.gpioport[flash5.pwmidle_port-1] = (unsigned char)outpc.iacstep;
        }
        // Set remote ports data on Generic board
        tmp_data[0] = *(unsigned char *)outpc.gpioport;
        if ((flash4.ports_dir & 0x0F) == 1) {
            // 1 output
            num = 1;    // 1 bytes to be sent
        } else if ((flash4.ports_dir & 0x0F) == 3) {
            // 2 outputs
            num = 2;    // 2 bytes to be sent
            tmp_data[1] = *((unsigned char *)outpc.gpioport + 1);
        } else {
            // 3 outputs
            num = 3;    // 3 bytes to be sent
            tmp_data[1] = *((unsigned char *)outpc.gpioport + 1);
            tmp_data[2] = *((unsigned char *)outpc.gpioport + 2);
        }

        (void)can_build_msg(MSG_CMD, flash4.can_poll_id[3], flash4.poll_tables[3], flash4.poll_offset[3], num,
            (unsigned char *)tmp_data, 0);
    }
}

void send_can11bit(unsigned int id, unsigned char *data, unsigned char bytes) {
    can_tx_msg *this_msg;
    unsigned char maskint_tmp, maskint_tmp2;

    MASK_INTERRUPTS;
    if (can_tx_out < NO_CANTXMSG) {
        this_msg = &can_tx_buf[can_tx_in];
        /* Store 11bit ID into Freescale raw format */
        this_msg->id = (unsigned long)id << 21;

        /* Store data and length */
        *(unsigned int*)&this_msg->data[0] = *(unsigned int*)&data[0];
        *(unsigned int*)&this_msg->data[2] = *(unsigned int*)&data[2];
        *(unsigned int*)&this_msg->data[4] = *(unsigned int*)&data[4];
        *(unsigned int*)&this_msg->data[6] = *(unsigned int*)&data[6];
        this_msg->sz = bytes;
        CAN_INC_TXRING;
    } else {
        /* fail silently */
    } 
    RESTORE_INTERRUPTS;
}

void send_can29bit(unsigned long id, unsigned char *data, unsigned char bytes) {
    /* Sends 29bit CAN message header and chosen data, bypassing Al-CAN
        Beware of sending messages that correspond to Al-CAN messages
        as there is no error trapping.
    */
    unsigned long a, b;
    unsigned int l;
    can_tx_msg *this_msg;
    unsigned char maskint_tmp, maskint_tmp2;

    MASK_INTERRUPTS;
    if (can_tx_out < NO_CANTXMSG) {
        l = bytes; /* To workaround ICE. */
        this_msg = &can_tx_buf[can_tx_in];

        /* Store 29bit ID into Freescale raw format */
        a = (id << 1) & 0x0007ffff;
        b = (id << 3) & 0xffe00000;
        this_msg->id = a | b | 0x00180000;

        /* Store data and length */

        *(unsigned int*)&this_msg->data[0] = *(unsigned int*)&data[0];
        *(unsigned int*)&this_msg->data[2] = *(unsigned int*)&data[2];
        *(unsigned int*)&this_msg->data[4] = *(unsigned int*)&data[4];
        *(unsigned int*)&this_msg->data[6] = *(unsigned int*)&data[6];
        this_msg->sz = l;

        CAN_INC_TXRING;
    } else {
        /* fail silently */
    }
    RESTORE_INTERRUPTS;
}

/* The following function is derived from code written by 'stevep' and donated to MS2/Extra / MS3 */
void can_broadcast(void)
{
    /* Broadcast selected CAN messages using STD CAN*/

    // Send Message Variables
    unsigned int id, val;
    unsigned char data[8];

    if (can_tx_num >= NO_CANTXMSG_POLLMAX) {
        return; /* Queue too full - don't broadcast now */
    }

    DISABLE_INTERRUPTS;
    val = (unsigned int)lmms;
    ENABLE_INTERRUPTS;
    if ((val - can_bcast_last) > flash4.can_bcast_int) {
        can_bcast_last = val; // rollover safe
    } else {
        return;
    }
    
    if (flash4.can_bcast1 & 0x02) {
        id = Engine_RPM; //0x280 - Motorsteuergerat 640 - engine control unit RPM is 4:1 ratio = outpc.rpm*4
        val = outpc.rpm * 4;

        data[0] = 0x00;
        data[1] = 0x00;
        data[2] = (unsigned char)(val & 0xff); //byte 3 = RPM, L
        data[3] = (unsigned char)(val >> 8);   //byte 4 = RPM, H
        data[4] = 0x00;
        data[5] = 0x00;
        data[6] = 0x00;
        data[7] = 0x00;
        send_can11bit(id, data, 8);
    }

    if (flash4.can_bcast1 & 0x04) {
        /* id definition says 1:1 ?? */
        id = Engine_RPM; //0x280 - Motorsteuergerat 640 - engine control unit RPM is 1:1 ratio = outpc.rpm*1
        val = outpc.rpm * 1;

        data[0] = 0x00;
        data[1] = 0x00;
        data[2] = (unsigned char)(val & 0xff); //byte 3 = RPM, L
        data[3] = (unsigned char)(val >> 8);   //byte 4 = RPM, H
        data[4] = 0x00;
        data[5] = 0x00;
        data[6] = 0x00;
        data[7] = 0x00;
        send_can11bit(id, data, 8);
    }

    if (flash4.can_bcast1 & 0x08) {
        long t1, t2;
        id = Engine_Temp;//     0x289 // 996 - Motorsteuerger�t 649 - Engine Temp /y=46.14+1.67*x where x is degrees C
        // quadratic to match guage position curve y = -.0336*x*x + 7.7986*x + -225.2571
        val = (((outpc.clt - 320) * 5) / 9)/10;
        if (val > 74) {
            t1 = (-336L * val) * val;
            t2 = 77986L * val;
            val = (unsigned int)((t1 + t2 -2252571) / 10000);
        }
        else {
            val = (5447 + (154 * val)) / 100;
        }

        data[0] = 0x00;
        data[1] = 0x00;
        data[2] = (unsigned char)val;
        data[3] = 0x00;
        data[4] = 0x00;
        data[5] = 0x00;
        data[6] = 0x00;
        data[7] = 0x00;
        send_can11bit(id, data, 8);
    }

    if (flash4.can_bcast1 & 0x10) { // from Peter Florance
	    id = Engine_RPM316; //0x316 BMW E46 - engine control unit RPM is 6.42:1 ratio = outpc.rpm*6.42
        val = (unsigned int)((outpc.rpm * 642UL) / 100);        

        data[0] = 0x00;
        data[1] = 0x00;
        data[2] = (unsigned char)(val & 0xff); //byte 3 = RPM, L
        data[3] = (unsigned char)(val >> 8);   //byte 4 = RPM, H
        data[4] = 0x00;
        data[5] = 0x00;
        data[6] = 0x00;
        data[7] = 0x00;
        send_can11bit(id, data, 8);
    }

    if (flash4.can_bcast1 & 0x20) { // from Peter Florance
        id = Engine_Temp329;//     0x329 
//        val = (((outpc.clt - 320) * 5) / 9)/10;
//	    val = (int)(((val + 48)*4)/3);
        val = (1088 + (outpc.clt << 1)) / 27;        

        data[0] = 0x00;
        data[1] = (unsigned char)val;
        data[2] = 0x00;
        data[3] = 0x00;
        data[4] = 0x00;
        data[5] = 0x00;
        data[6] = 0x00;
        data[7] = 0x00;
        send_can11bit(id, data, 8);
    }

    if ((flash4.can_bcast1 & 0x40)
        && (((flash4.can_bcast2 & 0x01) == 0) || (flagbyte6 & FLAGBYTE6_CAN1ST))) { // and 1st message sent (if enabled)
        /* Alfa/Fiat/Lancia dash coolant, RPM. Submitted by 'acab'
         fuel consumption
         0x561 8 00 00 00 cc xx xx rr 00
         cc = scaled coolant in degC
         xx = fuel consumption 0-132 L/hour
         rr = RPM/32 */
        int valclt, valrpm, valflow;
        id = 0x561;

        val = (outpc.clt - 320) / 18;
        valclt = val + 40;
        valrpm = outpc.rpm/32;

        /* Only works for 2sq alt */
        valflow = ((((outpc.pw1 - outpc.deadtime1) * (unsigned long)outpc.rpm) / 1000UL)
                * flash10.staged_pri_size) / 1000UL; /* scaling ?*/

        data[0] = 0x00;
        data[1] = 0x00;
        data[2] = 0x00;
        data[3] = (unsigned char)valclt;   // Coolant temp
        data[4] = 0x12; /* valflow will go here, but endianism? */
        data[5] = 0x34; /* here */
        data[6] = (unsigned char)valrpm;   // RPM 
        data[7] = 0x00;
        send_can11bit(id, data, 8);
    }
/* additional submissions by 'acab'
    0x361 | 8 | 00 xx 00 00 00 00 00 00
    xx= torque 0-99.96 % / 1bit = 0.392 %

    0x361 | 8 | 00 00 xx xx 00 00 00 00
    xx xx = rpm 0-10240 rpm / 1bit = 1 rpm

    0x361 | 8 | 00 00 00 00 00 00 00 xx
    xx= gas pedal position 0-99,96 % / 1bit = 0,392 % (may be same as throttle position)

    0x361 | 8 | 00 00 00 00 xx 00 00 00
    xx= throttle position 0- 99,96 % / 1bit = 0,392 %

    Initialisation packet, send only one time after ignition:
    0x041 | 7 | 06 00 00 00 00 00 00
*/
    if ((flash4.can_bcast1 & 0x80) 
        && (((flash4.can_bcast2 & 0x01) == 0) || (flagbyte6 & FLAGBYTE6_CAN1ST))) { // and 1st message sent (if enabled)
        int tps, torque;
        id = 0x361;

        if (outpc.tps < 0) {
            tps = 0;
        } else if (outpc.tps > 1000) {
            tps = 255;
        } else {
            tps = (outpc.tps *255UL) / 1000;
        }

        torque = calc_duty(global_base_pw1); // assume duty is a reasonable measure of torque

        data[0] = 0x00;
        data[1] = (unsigned char)torque;
        data[2] = outpc.rpm >> 8;
        data[3] = outpc.rpm & 0xff;
        data[4] = (unsigned char)tps;
        data[5] = 0x00;
        data[6] = 0x00;
        data[7] = (unsigned char)tps;
        send_can11bit(id, data, 8);
    }

    if ((flash4.can_bcast2 & 0x01) && (outpc.seconds) && (!(flagbyte6 & FLAGBYTE6_CAN1ST))) {
        flagbyte6 |= FLAGBYTE6_CAN1ST;
        id = 0x041;

        data[0] = 0x06;
        data[1] = 0x00;
        data[2] = 0x00;
        data[3] = 0x00;
        data[4] = 0x00;
        data[5] = 0x00;
        data[6] = 0x00;
        send_can11bit(id, data, 7);
    }

    if (flash4.can_bcast2 & 0x80) {
        id = pg12_ptr->can_bcast_user_id;
        data[0] = pg12_ptr->can_bcast_user_d[0];
        data[1] = pg12_ptr->can_bcast_user_d[1];
        data[2] = pg12_ptr->can_bcast_user_d[2];
        data[3] = pg12_ptr->can_bcast_user_d[3];
        data[4] = pg12_ptr->can_bcast_user_d[4];
        data[5] = pg12_ptr->can_bcast_user_d[5];
        data[6] = pg12_ptr->can_bcast_user_d[6];
        data[7] = pg12_ptr->can_bcast_user_d[7];
        send_can11bit(id, data, 8);
    }
}

void can_bcast_outpc_cont()
{
    /* This function gets called multiple times per mainloop pass from serial() */
    unsigned int b, t, t1;
    unsigned char op, go;

    go = 0;
    if (can_outpc_bcast_ptr > 31) {
    /*     can_outpc_gp00_int = bits, U08, 488, [1:3], "Off", "1Hz", "2Hz", "5Hz", "10Hz", "20Hz", "50Hz", "INVALID" */
        op = (flash8.can_outpc_gp[0] & 0x0f) >> 1;
        t1 = can_outpc_int[op];

        /* MS2 uses 8 bit value only */
        t = (unsigned int)lmms;

        if ((t - can_boc_tim_all) > t1) {
            can_boc_tim_all = t;
            can_outpc_bcast_ptr = 0;
            go = 1;
        }

    } else {
        go = 1;
    }

#define CAN_NUM_PER_PASS 5
    if (go) {
        for (b = 0; b < CAN_NUM_PER_PASS ; b++) { /* Handle some (was 16) in each pass to avoid bloating looptime */
            /* Make sure we do not put too many messages into the queue */
            if (can_tx_num >= NO_CANTXMSG_POLLMAX) {
                b = CAN_NUM_PER_PASS; /* bail on loop */
            } else {
                /* On MS2 have less RAM available and less message groups.
                    can_outpc_bcast_ptr counts 0-31 (keeps timer array smaller)
                    real group number 0-63
                */
                op = flash8.can_outpc_gp[can_outpc_bcast_ptr] & 0x01;
                if (op) {
                    can_bcast_outpc(can_outpc_ix[can_outpc_bcast_ptr]); /* send the message */

                }
                can_outpc_bcast_ptr++;
                if (can_outpc_bcast_ptr > 31) {
                    break;
                }
            }
        }
    }
}

void can_bcast_outpc(unsigned int gp)
{
    /* This function gets called to grab a pre-defined group of data and put
        it into the CAN message queue.
        Note that originally this data is not aligned with outpc, it is
        re-arranged for more logic 8 byte boundaries.
        We do not want to break predefined CAN templates developed for 3rd party
        dashes etc  !!! Leave this data format here as it is !!!*/
    unsigned int id;
    unsigned char data[8];
    unsigned char dataLen;

    id = flash8.can_outpc_msg + gp;
    dataLen = 0x08;

    /* This isn't a particularly elegant way of achieving this, but should
       achieve goal of not changing even if outpc is re-arranged.
       Alternative more elegant solution could be use a const array of bytes
       to grab, but maintenance could be tricky and there could be some hoops
       to jump through to put it into FAR space. */

    if (gp == 0) {
        *(unsigned int*)&data[0] = outpc.seconds;
        *(unsigned int*)&data[2] = (outpc.pw1 * 2UL) / 3;
        *(unsigned int*)&data[4] = (outpc.pw2 * 2UL) / 3;
        *(unsigned int*)&data[6] = outpc.rpm;

    } else if (gp == 1) {
        *(int*)&data[0] = outpc.adv_deg;
        data[2] = outpc.squirt;
        data[3] = outpc.engine;
        data[4] = outpc.afrtgt1;
        data[5] = outpc.afrtgt2;
        data[6] = outpc.wbo2_en1;
        data[7] = outpc.wbo2_en2;

    } else if (gp == 2) {
        *(int*)&data[0] = outpc.baro;
        *(int*)&data[2] = outpc.map;
        *(int*)&data[4] = outpc.mat;
        *(int*)&data[6] = outpc.clt;

    } else if (gp == 3) {
        *(int*)&data[0] = outpc.tps;
        *(int*)&data[2] = outpc.batt;
        *(int*)&data[4] = outpc.ego1;
        *(int*)&data[6] = outpc.ego2;

    } else if (gp == 4) {
        *(int*)&data[0] = outpc.knock;
        *(int*)&data[2] = outpc.egocor1;
        *(int*)&data[4] = outpc.egocor2;
        *(int*)&data[6] = outpc.aircor;

    } else if (gp == 5) {
        *(int*)&data[0] = outpc.warmcor;
        *(int*)&data[2] = outpc.tpsaccel;
        *(int*)&data[4] = outpc.tpsfuelcut;
        *(int*)&data[6] = outpc.barocor;

    } else if (gp == 6) {
        *(int*)&data[0] = outpc.gammae;
        *(int*)&data[2] = outpc.vecurr1;
        *(int*)&data[4] = outpc.vecurr2;
        *(int*)&data[6] = outpc.iacstep;

    } else if (gp == 7) {
        *(int*)&data[0] = outpc.cold_adv_deg;
        *(int*)&data[2] = outpc.tpsdot;
        *(int*)&data[4] = outpc.mapdot;
        *(int*)&data[6] = outpc.rpmdot;

    } else if (gp == 8) {
        *(int*)&data[0] = outpc.mafload;
        *(int*)&data[2] = outpc.fuelload;
        *(int*)&data[4] = outpc.fuelcor;
        *(int*)&data[6] = outpc.maf;

    } else if (gp == 9) {
        *(int*)&data[0] = outpc.egoV1;
        *(int*)&data[2] = outpc.egoV2;
        *(unsigned int*)&data[4] = outpc.coil_dur;
        *(unsigned int*)&data[6] = outpc.dwell_trl;

    } else if (gp == 10) {
        data[0] = outpc.status1;
        data[1] = outpc.status2;
        data[2] = outpc.status3;
        data[3] = outpc.status4;
        *(int*)&data[4] = outpc.istatus5;
        data[6] = 0;
        data[7] = 0;

    } else if (gp == 11) {
        *(int*)&data[0] = outpc.fuelload2;
        *(int*)&data[2] = outpc.ignload;
        *(int*)&data[4] = outpc.ignload2;
        *(int*)&data[6] = outpc.airtemp;

    } else if (gp == 12) {
        DISABLE_INTERRUPTS;
        *(long*)&data[0] = outpc.wallfuel1;
        *(long*)&data[2] = outpc.wallfuel2;
        ENABLE_INTERRUPTS;

    } else if (gp == 13) {
        *(int*)&data[0] = outpc.gpioadc[0];
        *(int*)&data[2] = outpc.gpioadc[1];
        *(int*)&data[4] = outpc.gpioadc[2];
        *(int*)&data[6] = outpc.gpioadc[3];

    } else if (gp == 14) {
        *(int*)&data[0] = outpc.gpioadc[4];
        *(int*)&data[2] = outpc.gpioadc[5];
        *(int*)&data[4] = outpc.gpioadc[6];
        *(int*)&data[6] = outpc.gpioadc[7];

    } else if (gp == 15) {
        *(int*)&data[0] = outpc.adc6; /* sensors9 in MS3 */
        *(int*)&data[2] = outpc.adc7; /* sensors10 in MS3 */
        *(int*)&data[4] = 0;
        *(int*)&data[6] = 0;

    } else if (gp == 17) {
        *(int*)&data[0] = outpc.boost_targ;
        *(int*)&data[2] = 0;
        data[4] = outpc.boostduty;
        data[5] = 0;
        *(unsigned int*)&data[6] = outpc.maf_volts;

    } else if (gp == 18) {
        *(int*)&data[0] = (outpc.pw1 * 2UL) / 3;
        *(int*)&data[2] = (outpc.pw2 * 2UL) / 3;
        *(int*)&data[4] = (outpc.pw3 * 2UL) / 3;
        *(int*)&data[6] = (outpc.pw4 * 2UL) / 3;

    } else if (gp == 26) {
        data[0] = 0;
        data[1] = 0;
        *(unsigned int*)&data[2] = 0;
        *(int*)&data[4] = outpc.n2o_addfuel;
        *(int*)&data[6] = outpc.nitrous_retard;

    } else if (gp == 27) {
        *(int*)&data[0] = outpc.gpiopwmin[0];
        *(int*)&data[2] = outpc.gpiopwmin[1];
        *(int*)&data[4] = outpc.gpiopwmin[2];
        *(int*)&data[6] = outpc.gpiopwmin[3];

    } else if (gp == 28) {
        *(unsigned int*)&data[0] = outpc.cl_idle_targ_rpm;
        *(int*)&data[2] = outpc.tpsadc;
        *(int*)&data[4] = outpc.eaeload;
        *(int*)&data[6] = outpc.afrload;

    } else if (gp == 29) {
        *(unsigned int*)&data[0] = outpc.EAEfcor1;
        *(unsigned int*)&data[2] = outpc.EAEfcor2;
        *(int*)&data[4] = 0;
        *(int*)&data[6] = 0;

    } else if (gp == 43) {
        data[0] = outpc.synccnt;
        data[1] = outpc.syncreason;
        *(unsigned int*)&data[2] = 0;
        data[4] = 0;
        data[5] = 0;
        data[6] = 0;
        data[7] = outpc.timing_err;


    } else if (gp == 46) {
        data[0] = 0;
        data[1] = 0;
        data[2] = 0;
        data[3] = 0;
        *(int*)&data[4] = outpc.inj_adv1; /* not quite the same as MS3 */
        *(int*)&data[6] = outpc.inj_adv2; /* not quite the same as MS3 */

    } else if (gp == 47) {
        *(int*)&data[0] = outpc.fuel_pct;
        *(int*)&data[2] = 0;
        *(unsigned int*)&data[4] = 0;
        *(unsigned int*)&data[6] = 0;

    } else if (gp == 51) {
        data[0] = outpc.portam; /* Port A on MS3 */
        data[1] = outpc.portbde; /* Port B on MS3 */
        data[2] = outpc.portbde; /* Port B on MS3 */
        data[3] = 0;
        data[4] = outpc.portam; /* Port MJ on MS3 */
        data[5] = 0;
        data[6] = outpc.portt; /* PortT on MS3 */
        data[7] = 0;

    } else if (gp == 52) {
        data[0] = outpc.gpioport[0]; /* canin1_8 on MS3 */
        data[1] = outpc.gpioport[1]; /* canout1_8 on MS3 */
        data[2] = outpc.gpioport[2]; /* canout9_16 on MS3 */
        data[3] = outpc.knk_rtd;
        *(int*)&data[4] = 0;
        *(int*)&data[6] = 0;

    } else if (gp == 55) {
        *(unsigned int*)&data[0] = outpc.looptime;
        *(int*)&data[2] = 0;
        *(int*)&data[4] = 0;
        data[6] = 0;
        data[7] = 0;

    } else if (gp == 57) {
        *(int*)&data[0] = outpc.base_advance;
        *(int*)&data[2] = outpc.idle_cor_advance;
        *(int*)&data[4] = outpc.mat_retard;
        *(int*)&data[6] = outpc.flex_advance;

    } else if (gp == 58) {
        *(int*)&data[0] = outpc.adv1;
        *(int*)&data[2] = outpc.adv2;
        *(int*)&data[4] = outpc.adv3;
        *(int*)&data[6] = 0;

    } else if (gp == 59) {
        *(int*)&data[0] = outpc.revlim_retard;
        *(int*)&data[2] = 0;
        *(int*)&data[4] = outpc.ext_retard;
        *(int*)&data[6] = outpc.deadtime1;

    } else {
        /* Should be an impossible case */
        dataLen = 0;
    }
    if (dataLen) {
        send_can11bit(id, data, dataLen);
    }

}

void can_do_tx()
{
    /* Take a message from our queue and put it into the CPU TX buffer if space */
    /* Interrupts MUST be masked by calling code */
    unsigned long id;
    unsigned char action;
    unsigned char *d;
    can_tx_msg *this_msg;

    this_msg = &can_tx_buf[can_tx_out]; /* grab a pointer */
    id = this_msg->id;

    if (can_tx_num) {
        can_tx_num--; /* Declare that we sent a packet */
    }
    can_tx_out++; /* Ring buffer pointer */
    if (can_tx_out >= NO_CANTXMSG) {
        can_tx_out = 0;
    }

    if (id) {
        CANTBSEL = CANTFLG; /* Select the free TX buffer */
        /* Tx buffer holds raw Freescale format ID registers */
        *(unsigned long*)&CAN_TB0_IDR0 = id;
        this_msg->id = 0; /* Mark as zero to say we've handled it */
        CAN_TB0_DLR = this_msg->sz;
        action = this_msg->action;

        d = (unsigned char*)&CAN_TB0_DSR0;
        *(unsigned int*)&d[0] = *(unsigned int*)&this_msg->data[0];
        *(unsigned int*)&d[2] = *(unsigned int*)&this_msg->data[2];
        *(unsigned int*)&d[4] = *(unsigned int*)&this_msg->data[4];
        *(unsigned int*)&d[6] = *(unsigned int*)&this_msg->data[6];

        CAN_TB0_TBPR = 0x02; /* Arbitrary message priority */

        CANTFLG = CANTBSEL; /* Send it off */

        if (action == 1) { /* check for any passthrough write messages */
            if ((flagbyte3 & flagbyte3_sndcandat) && cp_targ) {
                int num;
                unsigned int r;

                num = cp_targ - cp_cnt;
                if (num > 8) {
                    num = 8;
                } else {
                    /* final block, prevent sending any more*/
                    flagbyte14 |= FLAGBYTE14_SERIAL_OK; // serial code to return ack code that all bytes were stuck into pipe
                    flagbyte3 &= ~flagbyte3_sndcandat;
                    cp_targ = 0;
                }

                r = can_snddata(cp_table, cp_id, cp_offset + cp_cnt, num, (unsigned int)&srlbuf[9] + cp_cnt);

                if (r) {
                    /* flag up the error so serial.c can act*/
                    flagbyte14 |= FLAGBYTE14_CP_ERR;
                }
                cp_cnt += num;
            }
        } else if (action >= 10) { /* OUTMSG send */
            can_build_outmsg(action - 10);
        }

        if (CANRFLG & 0x0c) {
            if (CANRFLG & 0x04) {
                can_error |= CAN_ERROR_TXWRN;
            }
            if (CANRFLG & 0x08) {
                can_error |= CAN_ERROR_TXERR;
            }
            can_error_cnt++;
            if (can_error_cnt == 0) {
                can_error_cnt = 0xff;
            }
        }
    }
}

unsigned int can_build_msg(unsigned char msg, unsigned char to, unsigned char tab, unsigned int off,
                             unsigned char by, unsigned char *dat, unsigned char action) {
    /* Build a 29bit CAN message in processor native format */
    unsigned long id;
    can_tx_msg *this_msg;
    unsigned int ret;
    unsigned char maskint_tmp, maskint_tmp2;

#define CALC_ID_ASM

    MASK_INTERRUPTS;
    if (can_tx_out < NO_CANTXMSG) {
#ifdef CALC_ID_ASM
        unsigned int idh, idl;
        __asm__ __volatile__ (
            "ldd %1\n"
            "ldy #32\n"
            "emul\n"
            "orab   #0x18\n"
            "orab   %2\n"
            :"=d"(idh)
            :"m"(off), "m"(msg)
            :"y","x"
        );

        __asm__ __volatile__ (
            "ldaa %1\n"
            "lsla\n"
            "lsla\n"
            "lsla\n"
            "lsla\n"
            "oraa   %2\n"
            "ldab   %3\n"
            "lslb\n"
            "lslb\n"
            "lslb\n"
            "lslb\n"
            "bcc    no_bit4\n"
            "orab   #0x08\n"
            "no_bit4:"
            :"=d"(idl)
            :"m"(flash4.mycan_id), "m"(to), "m"(tab)
            :"y","x"
        );

        id = ((unsigned long)idh << 16) | idl;
#else
        /* This C implementation looks cleaner but takes 11us instead of 1us */
        id = 0;
        id |= (unsigned long)off << 21;
        id |= (unsigned long)msg << 16;
        id |= (unsigned long)flash4.mycan_id << 12;
        id |= (unsigned long)to << 8;
        id |= (tab & 0x0f) << 4;
        id |= (tab & 0x10) >> 1;
        id |= 0x180000; /* SRR and IDE bits */
#endif
        this_msg = &can_tx_buf[can_tx_in]; /* grab a pointer */
        this_msg->id = id;
        this_msg->sz = by;
        this_msg->action = action;
        *(unsigned int*)&this_msg->data[0] = *(unsigned int*)&dat[0];
        *(unsigned int*)&this_msg->data[2] = *(unsigned int*)&dat[2];
        *(unsigned int*)&this_msg->data[4] = *(unsigned int*)&dat[4];
        *(unsigned int*)&this_msg->data[6] = *(unsigned int*)&dat[6];
        CAN_INC_TXRING;
        ret = 0;
    } else {
        ret = 1;
    }
    RESTORE_INTERRUPTS;
    return ret;
}

unsigned int can_build_msg_req(unsigned char to, unsigned char tab, unsigned int off,
                     unsigned char rem_table,
                     unsigned int rem_off, unsigned char rem_by) {
    /* Build a MSQ_REQ message */
    /* Must be called with interrupts off */
    unsigned char tmp_data[8];
    unsigned int ret;

    if (tab < 32) {
        tmp_data[0] = rem_table; /* Send back to table x */
        tmp_data[1] = rem_off >> 3; /* offset */
        tmp_data[2] = ((rem_off & 0x07) << 5) | rem_by; /* offset, # bytes */
        ret = can_build_msg(MSG_REQ, to, tab, off, 3, (unsigned char *)&tmp_data, 0);
    } else {
        tmp_data[0] = MSG_REQX;
        tmp_data[1] = rem_table; /* Send back to table x */
        tmp_data[2] = rem_off >> 3; /* offset */
        tmp_data[3] = ((rem_off & 0x07) << 5) | rem_by; /* offset, # bytes */
        tmp_data[4] = tab; /* Large table number */
        ret = can_build_msg(MSG_XTND, to, tab, off, 5, (unsigned char *)&tmp_data, 0);
    }
    return ret;
}

void chk_crc(void)
{
    unsigned long crc = 0;
    unsigned char tmp_data[8];
    /* if required, calc crc of ram page */
    /* local CRC handled in serial.c now */
    if (flagbyte6 & FLAGBYTE6_CRC_CAN) {
        flagbyte6 &= ~FLAGBYTE6_CRC_CAN;
// only check ram copy, irrespective of page number

        if (crc_idx < 4) {
            unsigned char save_PPAGE;
            /* check CRC of flash page */
            save_PPAGE = PPAGE;
            PPAGE = 0x3c;
            crc = crc32buf(0, (unsigned int)tables[crc_idx].addrFlash, tables[crc_idx].n_bytes);    // incrc, buf, size
            PPAGE = save_PPAGE;
        } else {
            crc = crc32buf(0, (unsigned int)&ram_data, 0x400);    // incrc, buf, size
        }
        *(unsigned long*)&tmp_data[0] = crc;

        can_build_msg(MSG_RSP, canbuf[5], canbuf[4], 0, 4, (unsigned char*)tmp_data, 0);
    }
}

void can_build_outmsg(unsigned char msg_no)
{
    unsigned char var_byt;
    unsigned int p, kx, lx, cv, cur_size;
    outmsg *this_outmsg;
    outmsg_stat *this_outmsgstat;
    unsigned char tmp_data[8];

    this_outmsg = (outmsg*)&flash12.outmsgs[msg_no];
    this_outmsgstat = &cur_outmsg_stat[msg_no];
    cv = this_outmsgstat->count;

    var_byt = 0;
    for (kx = cv; kx < OUTMSG_SIZE; kx++) {
        cur_size = this_outmsg->size[kx];
        if ((cur_size != 0) && ((var_byt + cur_size) <= 8)) {
            p = (unsigned int)&outpc + this_outmsg->offset[cv];
            for (lx = 0; lx < cur_size; lx++) {
                tmp_data[var_byt] = *(unsigned char *)(p + lx);
                var_byt++;
            }
            cv++;
        } else {
            break;
        }
    }

    this_outmsgstat->count = cv;

    if (var_byt) {
        can_build_msg(OUTMSG_RSP, this_outmsgstat->id, this_outmsgstat->tab, this_outmsgstat->off, var_byt, (unsigned char*)tmp_data, 10 + msg_no);

        this_outmsgstat->off += var_byt;
    }
}

void can_dashbcast(void)
{
    unsigned int can_snd_interval, t, id;
    unsigned char tmp_data[8], opta;

    opta = flash12.dashbcast_opta;
    if (opta & 0x1) { /* Enabled */

        can_snd_interval = (unsigned int)lmms - dashbcast_sndclk;

        if (opta & 0x2) { /* Advanced */
            t = opta & 0x30; /* 10, 20, 50, 100Hz */
            if (t == 0) {
                t = 781;
            } else if (t == 0x10) {
                t = 390;
            } else if (t == 0x20) {
                t = 156;
            } else {
                t = 78;
            }
            id = flash12.dashbcast_id;
        } else {
            t = 390; /* default 20Hz */
            id = 1512;
        }

        if (can_snd_interval >= t) {
            dashbcast_sndclk = (unsigned int)lmms;

            /* packet 0 */
            *(unsigned int*)&tmp_data[0] = outpc.map;
            *(unsigned int*)&tmp_data[2] = outpc.rpm;
            *(unsigned int*)&tmp_data[4] = outpc.clt;
            *(unsigned int*)&tmp_data[6] = outpc.tps;
            send_can11bit(id + 0, tmp_data, 8);

            /* packet 1 */
            *(unsigned int*)&tmp_data[0] = outpc.pw1;
            *(unsigned int*)&tmp_data[2] = outpc.pw2;
            *(unsigned int*)&tmp_data[4] = outpc.mat;
            *(unsigned int*)&tmp_data[6] = outpc.adv_deg;
            send_can11bit(id + 1, tmp_data, 8);

            /* packet 2 */
            tmp_data[0] = outpc.afrtgt1;
            tmp_data[1] = outpc.ego1;
            *(unsigned int*)&tmp_data[2] = outpc.egocor1;
            *(unsigned int*)&tmp_data[4] = 0; /* not present */
            *(unsigned int*)&tmp_data[6] = outpc.pw1; /* same as pw1 */
            send_can11bit(id + 2, tmp_data, 8);

            /* packet 3 */
            *(unsigned int*)&tmp_data[0] = outpc.batt;
            *(unsigned int*)&tmp_data[2] = outpc.gpioadc[0];
            *(unsigned int*)&tmp_data[4] = outpc.gpioadc[1];
            *(unsigned int*)&tmp_data[6] = outpc.knk_rtd;
            send_can11bit(id + 3, tmp_data, 8);

            /* packet 4 not present on MS2 */
        }
    }
}
