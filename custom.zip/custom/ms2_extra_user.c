/* $Id: ms2_extra_user.c,v 1.5 2016/01/14 00:11:22 jsmcortina Exp $
 * Copyright 2006, 2007, 2008, 2009, 2010, 2011, 2012, 2013
 * James Murray and Kenneth Culver
 *
 * This file is a part of MS2/Extra.
 *
 * You should have received a copy of the code LICENSE along with this source,
 * ask on the www.msextra.com forum if you did not.
 *
 */
#include "ms2_extra.h"

void user_defined() {
/* 'user defined'
 *
 * So here is a place to put your code. The three variables are there ready
 * for you.
 * If you want to get data out to tuning software you can use outpc.user0 which is set
 * aside specially  (or outpc.status4 or outpc.istatus5 which are both free at time of
 * writing this note.)
 * Then those gauges can be enabled in Megatune or Tunerstudio.
 *
 * Other uses:
 * Make custom comparisons to turn outputs on/off. One way to simplify this somewhat
 * could be to use this code to change the value in status4 and then let the
 * existing "outputs" code that you configure in the tuning software actually
 * enable the output and turn it on or off - that might save a lot of customisation
 * and digging around in the code. Once you have status4 changing value, you are
 * nearly done.
 */

/* As of 2016-01-13 the 'user' variables are commented out in ms2_extra_vars.h
   you can uncomment them (then make clean) and use them, but beware of potential
   stack overflows.
    The variables are initialised to zero in ms2_extra_init.c
 */

#ifdef USER_DEF_ON
    if (flash10.user_conf & 0x01) { // is our user defined feature enabled
        //user_ulong = ????;  variables for your use
        //user_uint = ????;
        //user_uchar = ????;

        // flash10.user_conf   } These are the data 
        // flash10.user_value1 } you can prog to
        // flash10.user_value2 } flash from tuning software


        /*  if (user_uchar > 4) {
            outpc.user0++;
        } else {
            outpc.user0--;
        }
        */
    }
#endif
    return;
}
