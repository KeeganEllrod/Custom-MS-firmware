/* $Id: ms2_extra_vars.h,v 1.80 2019/02/28 16:34:26 jsmcortina Exp $
 * Copyright 2006, 2007, 2008, 2009, 2010, 2011, 2012, 2013
 * James Murray and Kenneth Culver
 *
 * This file is a part of MS2/Extra.
 *
 * You should have received a copy of the code LICENSE along with this source,
 * ask on the www.msextra.com forum if you did not.
 *
 */

/* This header should be included by ms2_extra.h
 * It is parsed to auto-generated ms2_extra_main_vars.h and others
 */

/* Note that if you were thinking of adding variable in here, you could be out
   of luck - all of the RAM in MS2/Extra is allocated. If you add additional 
   variables you are likely to trip a stack overflow. */

extern const int cltfactor_table[1024] LOOKUP_ATTR; // caution ms2_extra_can.c forces a pageswap to this page
extern const int matfactor_table[1024] LOOKUP_ATTR;
extern const unsigned char egofactor_table[1024] LOOKUP_ATTR;
extern const unsigned int maffactor_table[1024] LOOKUP_ATTR;

#define NO_TBLES        16 /* locally held */
#define NO_CANTBLES     32 /* protocol spec */
#define NO_EXFMAPS      16
#define NO_EXFRPMS      16
#define NO_FMAPS        12
#define NO_SMAPS        12
#define NO_FRPMS        12
#define NO_SRPMS        12
#define NO_ARPMS  6
#define NO_ATPSS  6
#define NO_INJ          2
#define NO_TEMPS        10
#define NO_MAT_TEMPS    6
#define NO_BARS         9
#define NO_MATS         9
#define NO_MAFMATS       6
#define NO_TPS_DOTS   4
#define NO_MAP_DOTS   4
#define NO_KNKRPMS  6
#define NPORT    7
#define NO_COILCHG_PTS  6
#define EGODT  78        /* 78 .128 ms tics = 10 ms */
#define END_SYNCH  3
#define MAXNUMTEETH 120

#define SER_TOUT  5

#define MSG_CMD 0
#define MSG_REQ 1
#define MSG_RSP 2
#define MSG_XSUB        3
#define MSG_BURN        4
#define OUTMSG_REQ  5
#define OUTMSG_RSP  6
#define MSG_XTND    7
// define xtended msgs from 8 on
#define MSG_FWD     8
#define MSG_CRC     9
#define MSG_REQX 12 /* like REQ but for tables > 31 */
#define MSG_BURNACK 14 /* ACK from remote that a Burn completed */
#define MSG_PROT 0x80 /* new extended CAN command for getting the protocol version number */
#define MSG_WCR 0x81 /* new extended CAN command for sending the CRC32 after a series of CMD messages */
#define MSG_SPND 0x82 /* new extended CAN command for suspending and resuming CAN polling to a device */

#define MAX_CANBOARDS 16
#define NO_CANTXMSG 8 /* May need tweaking */
#define NO_CANTXMSG_POLLMAX 6 /* Maximum slots to be used for polling / broadcast */
#define CANTFLG_MASK 1 /* Use a single TX buffer only, otherwise hardware re-arranges packet order */

 #define MONVER (*(unsigned int *) 0xFEFE)

extern const page4_data flash4 EEPROM_ATTR;
extern const page5_data flash5 EEPROM_ATTR;
extern const page10_data flash10 EEPROM_ATTR;
extern const page8_data flash8 EEPROM_ATTR;
extern const page9_data flash9 EEPROM_ATTR;
extern const page11_data flash11 EEPROM_ATTR;
extern const page12_data flash12 EEPROM_ATTR;
extern const unsigned char IACCoilA[8];
extern const unsigned char IACCoilB[8];

extern char ram_data[1024];
extern page4_data *pg4_ptr;
extern page5_data *pg5_ptr;
extern page10_data *pg10_ptr;
extern page8_data *pg8_ptr;
extern page9_data *pg9_ptr;
extern page11_data *pg11_ptr;   
extern page12_data *pg12_ptr;   

/* Coil bits for an ign event */

#define         TRIGA           0
#define         TRIGB           1
#define         TRIGC           2
#define         TRIGD           3
#define         TRIGE           4
#define         TRIGF           5
#define         TRIGG           6
#define         TRIGH           7

# define time32 time.time_32_bits
# define time16_high time.time_16_bits[0]
# define time16_low time.time_16_bits[1]

#define NUM_TRIGS 10
extern ign_event dwell_events_a[NUM_TRIGS];
extern ign_event spark_events_a[NUM_TRIGS];
extern fuel_event fuel1_events_a[5];    
extern fuel_event fuel2_events_a[5];    
extern fuel_event fuel3_events_a[3];    
extern fuel_event fuel4_events_a[3];    
extern ign_event dwell_events_b[NUM_TRIGS];
extern ign_event spark_events_b[NUM_TRIGS];
extern fuel_event fuel1_events_b[5];    
extern fuel_event fuel2_events_b[5];    
extern fuel_event fuel3_events_b[3];    
extern fuel_event fuel4_events_b[3];    
extern ign_event *dwell_events;
extern ign_event *spark_events;
extern fuel_event *fuel1_events;        
extern fuel_event *fuel2_events;        
extern fuel_event *fuel3_events;        
extern fuel_event *fuel4_events;        
extern ign_event next_spark;
extern ign_event next_dwell;
extern fuel_event next_fuel1_event;     
extern fuel_event next_fuel2_event;     
extern fuel_event next_fuel3_event;     
extern fuel_event next_fuel4_event;     
extern ign_event next_dwl_trl;
extern ign_event next_spk_trl;
extern ign_time dwl_time_ovflo_trl;
extern ign_time spk_time_ovflo_trl;
extern ign_queue spkq[2], dwellq[2];
extern unsigned char wheeldec_ovflo;
#define OVFLO_ROT_SPK 0x4
#define OVFLO_ROT_DWL 0x8
extern unsigned char next_fuel;
extern unsigned int inj1_count, inj2_count, inj3_count, inj4_count;
extern unsigned char trigger_teeth[NUM_TRIGS];
extern int trig_angs[NUM_TRIGS];
extern int trig_ang;
extern map_event next_map_start_event, map_start_event[NUM_TRIGS];
extern unsigned int map_start_countdown, map_window_countdown, map_window_set;
extern unsigned int map_temp, mafraw, map_temps[4];
extern unsigned char map_temps_cnt, map_deadman;
extern long MAFCoef;
extern unsigned int mafload_no_air;

extern unsigned char coilsel;
extern unsigned char dwellsel;
extern unsigned char rotaryspksel;
extern unsigned char rotarydwlsel;

#define STATUS1_NEEDBURN    1   // need burn
#define STATUS1_LOSTDATA    2  // lost data
#define status1_conferr     4    // config error
#define STATUS1_SYNCOK      8
#define STATUS1_SYNCLATCH 0x10
#define status1_ftblsw   0x20
#define status1_stblsw   0x40
#define STATUS1_SYNCFULL 0x80

#define status2_nitrous1                0x01    // nitrous stage1
#define status2_nitrous2                0x02    // nitrous stage2
#define status2_revlim                  0x04   //hard limiter on
#define status2_launch                  0x08   // launch active
#define status2_flatshift  0x10   // flatshift active
#define STATUS2_SPKCUT 0x20 // doing spk cut
#define STATUS2_OVERBOOST_ACTIVE 0x40
#define status2_pwmidle_closedloop      0x80

#define STATUS3_CUT_FUEL 1
#define STATUS3_DONELOG 2 // set when trigger or tooth log is complete
#define STATUS3_MAPERROR 4
#define STATUS3_TESTMODE 8 // only for indication
#define STATUS3_REVLIMSFT 0x20
#define STATUS3_BIKESHIFT 0x40

// outpc.status 4,5 are used for ease of getting data values into Megatune

// sensor variables
extern int /*last_tps,*/last_map,tpsdot_ltch,mapdot_ltch;
// fuel variables
extern unsigned int pwcalc1,pwcalc2,pwcalc3,pwcalc4,pw_open1,pw_open2,pw_open3,pw_open4,PrimeP,ase_value,ase_cycles,pwcalc_eae1,pwcalc_eae2, req_pw1, req_pw2, req_pw3, req_pw4;
extern unsigned char pwm1_on,pwm2_on;
extern unsigned int RevLimRpm1, RevLimRpm2;
// ignition variables
extern unsigned char SPK,CHG, pulse_no,ign_state,ign_setpin,
  IgnOCpinstate,PulseTol;
extern long charge_time,coil_dur_set;
extern unsigned int coil_dur;
extern unsigned long IgnTimerComp,dtpred,dtpred_last,dtpred_last2,dtpred_last3;
extern unsigned int NoiseFilterMin;
// IAC variables
extern unsigned char motor_time_ms;
extern int IACmotor_pos,last_iacclt,tble_motor_pos;
extern unsigned char idle_wait_timer;
extern unsigned char pwmidle_reset;
extern unsigned int pwmidle_timer;
extern unsigned char boost_ctl_duty;
extern char IAC_moving, IdleCtl, motor_step;
extern int IACmotor_last;
// General variables
extern unsigned int TC_ovflow;
extern unsigned long lmms,t_enable_IC,t_enable_IC2,Rpm_Coeff,ltch_lmms,ltch_lmms2,rcv_timeout;
extern unsigned int asecount, adc_lmms;
extern unsigned char flocker,tpsaclk,egocount,igncount,altcount,next_adc,first_adc,   
        txmode, burn_idx, crc_idx, synch,
        egopstat[2], FSensStat,knk_clk,knk_clk_test,knk_stat,knk_count,mms,millisec;
extern unsigned char rxmode, srl_err_cnt;
extern unsigned int burnstat;
extern unsigned int boost_ctl_timer;
#define SYNC_SYNCED     0x1
#define SYNC_FIRST      0x2
#define SYNC_RPMCALC    0x4
#define SYNC_SEMI       0x8
#define SYNC_SEMI2      0x10
#define SYNC_WCOP       0x20    //  wasted cop for missing + 2nd trig startup
#define SYNC_WCOP2      0x40    //  forced wasted cop

extern unsigned char seq_inj_ctrl;
extern unsigned int hybrid_rpm, hybrid_hyst;
#define SEQ_STD_INJ     0x01
#define SEQ_USE_TC2     0x02
#define SEQ_USE_TC4     0x04
#define SEQ_HYBRID      0x08
#define SEQ_MASK_INJ1   0x10
#define SEQ_MASK_INJ2   0x20
#define SEQ_MASK_INJ3   0x40
#define SEQ_MASK_INJ4   0x80

extern long ego1errm1[2],ego2errm1[2];
extern unsigned int  FSens_Pd;
extern unsigned char flex_count;
extern unsigned long flex_accum;
extern unsigned char flex_err_cnt;
extern int eth_pct_accum;

/* Clocks:
        - igncount: counts up each tach pulse, cleared when hit Divider pulses
               (and injection occurs).
        - asecount: counts up each time igncount = 0 (each Divider pulses).
        - egocount: counts up each tach pulse, cleared when hits EgoCountCmp
        - tpsaclk: counts every .1 sec
        - altcount: flips 0,1,0,1... on each injection, resulting in firing alternate
                injector banks if Alternate option.
*/
extern unsigned int txcnt,txgoal,rxoffset;
extern char bad_ego_flag;
extern int knk_tble_adv;
extern unsigned long WF1, WF2;
extern unsigned long AWA1, AWA2, SOA1, SOA2;
extern unsigned long tooth_diff_last_2, tooth_diff_last_1, tooth_diff_last, tooth_diff_this;
extern ign_time tooth_diff_rpm, tooth_diff_rpm_last;
extern unsigned char no_triggers;
extern unsigned char no_teeth;
extern unsigned char tooth_no, tooth_no_rpm;
extern unsigned char last_tooth;
extern unsigned char mid_last_tooth;

extern int cycle_deg;

//had to add these when main_init broken off
extern unsigned int tcrank_done;
unsigned long tcrank_done_lmms;

// CAN variables
extern unsigned long cansendclk;
extern unsigned int canrxad, canrxgoal;
extern unsigned int cp_targ, cp_cnt, cp_offset, cp_time;
extern unsigned char cp_id, cp_table, can_scanid;
extern unsigned int can_bcast_last;
extern unsigned char can_err_cnt[16], can_getid;
outmsg_stat cur_outmsg_stat[OUTMSG_NB];
extern unsigned int can_outpc_bcast_ptr;
extern unsigned int can_boc_tim_all;
extern volatile unsigned char can_rcv_in, can_rcv_proc, can_tx_in, can_tx_out, can_tx_num;
extern can_tx_msg can_tx_buf[NO_CANTXMSG]; /* Transmit buffer */
#define CAN_DEAD_THRESH 5
extern volatile unsigned char can_error, can_error_cnt;
#define CAN_ERROR_RXOVR 1 /* RX overrun */
#define CAN_ERROR_RXWRN 2 /* RX warning from hardware */
#define CAN_ERROR_RXERR 4 /* RX error from hardware */
#define CAN_ERROR_TXWRN 8 /* TX warning from hardware */
#define CAN_ERROR_TXERR 0x10 /* TX error from hardware */
#define CAN_ERROR_PASS 0x20 /* failure in passthrough */
#define CAN_ERROR_OOR 0x40 /* out of range request received */
#define CAN_ERROR_PASS2 0x80 /* timeout in passthrough */

/* Std CAN prototype and identifiers */
#define Ignition_Status 0x271 //Audi
#define SteerCSM_Status 0x2C1 //Audi
#define CentElec_Status 0x531 //Audi
#define CentConv_Status 0x591 //Audi
#define DrivDoor_Status 0x381 //Audi
#define PassDoor_Status 0x3B5 //Audi
#define RRDoor_Status   0x4BD //Audi
#define LRDoor_Status   0x4B9 //Audi
#define MultiFnc_Status 0x5C3 //Audi
#define FIS1_TEXT_line1 0x265 //Audi
#define FIS1_TEXT_line2 0x263 //Audi
#define AT_Line2    0x540 //Audi
#define VIN_IDENTIF    0x65F //Audi

#define ABS_Status      0x1A0 // 996 - ABS              416 - ESP/ABS/Brakes
#define Engine_RPM    0x280 // 996 - Motorsteuerger�t 640 - engine control unit RPM 1:1 ratio
#define Engine_Temp     0x289 // 996 - Motorsteuerger�t 649 - Engine Temp /y=46.14+1.67*x where x is degrees C
#define Vehicle_Speed    0x2A8 // 996 - Motorsteuerger�t 680 - engine control unit Speed (78270+(47907*kmh))/1000
#define AT_Line1    0x440 // 996 - Motorsteuerger�t 1088- Tiptronic Gear Position
#define TempoStat_ctl   0x510 // 996 - Cluster out     1296 - Instrument Cluster Tempostat control
#define Engine_RPM316   0x316 // Siemens BMW 
#define Engine_Temp329  0x329 // Siemens BMW

// pointers for spare port pins
extern volatile unsigned char *pPTMpin2, *pPTMpin3, *pPTMpin4,*pPTMpin5, *pPTTpin[8], *pPTApin0, *pPTEpin[2];
extern volatile unsigned char *boostport, *port_testio, *port_iacen, *port_iac1, *port_iac2;
extern unsigned char pin_iacen, pin_iac1, pin_iac2, pol_iacen, pol_iac1, pol_iac2, iac_dty, iac_holddty;
extern unsigned char boostpin, pin_testio;
extern unsigned char dummyReg,lst_pval[NPORT];
extern volatile unsigned short *mafport;
extern volatile unsigned char *port_ac_out, *port_ac_in, pin_ac_out, pin_ac_in, pin_match_ac_in;

// allocate space in ram for flash burner core
extern volatile unsigned char RamBurnPgm[36];

// vars added for MS2/Extra
extern unsigned char page;  // which flash data page is presently in ram
extern unsigned char num_spk; // calculated number of spark outputs
extern unsigned char conf_err; // set if configuration error
extern unsigned int mltimestamp; // time the mainloop
extern unsigned int EAEdivider;
extern unsigned char mmsDiv, boost_ctl_clock;

// these were static in sci isr, asm needs them as global (same thing)
//extern int vfy_fail,;
extern unsigned char CANid, next_txmode;

/* NOTE! When updating these defines, be sure to check ms2extrah.inc as well */

extern volatile unsigned char flagbyte0;
#define FLAGBYTE0_MAFLOG  1    // logging MAF
#define FLAGBYTE0_MAFLOGARM 2 // MAF logger armed
#define FLAGBYTE0_MAPLOG  4    // logging MAP
#define FLAGBYTE0_ENGLOG 8 // PTT, PORTB, PORTA logger
#define FLAGBYTE0_MAPLOGARM 0x10 // MAP logger armed
#define FLAGBYTE0_COMPLOG  0x20 // logging crank + cam teeth (composite loger)
#define FLAGBYTE0_TTHLOG  0x40 // logging teeth
#define FLAGBYTE0_TRGLOG  0x80 // logging triggers

extern volatile unsigned char flagbyte1;
#define flagbyte1_trig2active 1
#define flagbyte1_tstmode  2   // test mode enable - set to 1 turns off normal functions
#define flagbyte1_ovfclose 4   // nearly going to overflow
#define flagbyte1_polarity 8 // polarity check on (reduces tests in ISR)
#define flagbyte1_noisefilter 0x10 // noise filter on (reduces tests in ISR)
#define flagbyte1_igntrig 0x20 // ignition trigger LED feature on
#define FLAGBYTE1_ODDFIRECYL 0x40 // oddfire or oddcyl for spkmode4
#define flagbyte1_trig2statl 0x80  // 2nd trigger state in previous ISR (used by 6g72)

extern volatile unsigned char flagbyte2;
#define flagbyte2_twintrig 1   // for quick checking
#define flagbyte2_twintrignow 2   // event happened just now
#define flagbyte2_crank_ok 4   // ok to go to crank mode (rock crawler / hei bypass)
#define flagbyte2_tfi_ps 8   // Push Start TFI mode enabled
#define flagbyte2_tc0stat 0x10   // Status of crank tach input when 2nd trigger (CAS4/2)
#define flagbyte2_runidle 0x20
#define flagbyte2_EAElag 0x40
#define flagbyte2_MV2 0x80   // return MS2 base style data to keep MV2 happy

extern volatile unsigned char flagbyte3;

#define flagbyte3_kill_srl  2    // from MS2 2.87
#define flagbyte3_can_reset 4    // from MS2 2.87
#define flagbyte3_getcandat 8    // from MS2 2.87
#define flagbyte3_sndcandat 0x10 // from MS2 2.87
#define flagbyte3_runboost  0x20
#define flagbyte3_toothinit 0x40 // set to 1 once we've reached the tooth
#define flagbyte3_samplemap 0x80

extern volatile unsigned char flagbyte4;
#define flagbyte4_first_edis 1 // have we sent the multi-spark SAW word
#define flagbyte4_transition_done 2
#define flagbyte4_staging_on 4
#define flagbyte4_tach2 8        // entered ISR on 2nd tach signal (used locally in timer ISR)
#define FLAGBYTE4_CAMPOL     0x10
#define FLAGBYTE4_POLLOK     0x20
#define flagbyte4_oddspk     0x40  // tells code to "join" sparks A & B, but allowing them to have their own dwell timers
#define flagbyte4_idleadvreset 0x80

extern volatile unsigned char flagbyte5;
#define FLAGBYTE5_CRK_DOUBLE 0x01 // crank - single or double edged
#define FLAGBYTE5_CRK_BOTH   0x02 // crank - triggering on both edges
#define FLAGBYTE5_CAM        0x04 // cam in use
#define FLAGBYTE5_CAM_DOUBLE 0x08 // cam - single or double edged
#define FLAGBYTE5_CAM_BOTH   0x10 // cam - triggering on both edges
#define FLAGBYTE5_CAM_NOISE  0x20 // cam - noise filter on
#define FLAGBYTE5_CAM_POLARITY 0x40 // cam - noise filter on
#define FLAGBYTE5_LOG_CLR    0x80 // tooth log buffer needs clearing

extern volatile unsigned char flagbyte6;
#define FLAGBYTE6_DONEINIT      0x01 // DONE INIT
#define FLAGBYTE6_USE_MAF       0x02
#define FLAGBYTE6_USE_MAF_ONLY  0x04
#define FLAGBYTE6_CRC           0x08
#define FLAGBYTE6_CRC_CAN       0x10
#define FLAGBYTE6_PAGECOPY      0x20
#define FLAGBYTE6_CAN1ST        0x40

extern volatile unsigned char flagbyte11;
#define FLAGBYTE11_DLI4         0x01
#define FLAGBYTE11_DLI6         0x02
//#define FLAGBYTE11_FC           0x04
//#define FLAGBYTE11_FD           0x08
#define FLAGBYTE11_RX8          0x10
#define FLAGBYTE11_JS10         0x20
#define FLAGBYTE11_MAP_AVG_RDY  0x40
#define FLAGBYTE11_MAP_AVG_TRIG 0x80

extern volatile unsigned char flagbyte14;
#define FLAGBYTE14_SERIAL_TL      0x01
#define FLAGBYTE14_SERIAL_FWD     0x02
#define FLAGBYTE14_FUELFLOW_CALC  0x04
#define FLAGBYTE14_CP_ERR         0x08
#define FLAGBYTE14_SERIAL_PROCESS 0x10
#define FLAGBYTE14_SERIAL_SEND    0x20
//#define FLAGBYTE14_SERIAL_BURN    0x40
#define FLAGBYTE14_SERIAL_OK      0x80

extern volatile unsigned char flagbyte15;
#define FLAGBYTE15_DPCNT        0x01
#define FLAGBYTE15_CANSUSP      0x02
#define FLAGBYTE15_CANRX        0x04
#define FLAGBYTE15_DONEPRIME    0x08
#define FLAGBYTE15_FIRSTRPM     0x10 // got the first rpm calc period
#define FLAGBYTE15_MAPWINDOW    0x20 // in MAP window
#define FLAGBYTE15_DB_WRAP      0x40 // debug buffer has wrapped
#define FLAGBYTE15_ONESEC       0x80

extern volatile unsigned char flagbyte20;
#define FLAGBYTE20_50MS    1     // use bits of this byte
#define FLAGBYTE20_TO      2     // tacho out divider
#define FLAGBYTE20_FOUNDFIRST 4
#define FLAGBYTE20_SPKCUTTMP 8
#define FLAGBYTE20_REVLIMFC 0x10
#define FLAGBYTE20_OVERRUNFC 0x20
#define FLAGBYTE20_LAUNCHFC  0x40
#define FLAGBYTE20_USE_MAP  0x80  // MAP sensor in use

extern volatile unsigned char flagbyte22;
#define FLAGBYTE22_REMOTEBURN 0x01
#define FLAGBYTE22_REMOTEBURNSEND 0x02
#define FLAGBYTE22_FLEX 0x04
#define FLAGBYTE22_SHUTDOWNACTIVE 0x10
#define FLAGBYTE22_SHUTDOWNLOCKOUT 0x20
#define FLAGBYTE22_SHUTDOWNSPKACTIVE 0x40
#define FLAGBYTE22_NEW_TOOTH 0x80

//extern unsigned char scidiag[];      // this is for debug only and should be removed in future

extern unsigned long stall_timeout; // save doing long div each 0.128ms
extern unsigned char last_fsensdat;
extern unsigned short FPdcounter, FPdcounter2;
extern unsigned char fc_counter, adc_ctr;
extern unsigned int lowres, lowres_ctr, tacho_targ; // 0.128ms period counters (like MS1) for tacho
extern unsigned int staged_num_events; /* number of events into staging trasition */
extern unsigned long pw_staged1, pw_staged2, pw_staged3, pw_staged4; /* staged pulsewidths */
// not used extern unsigned int spk_mult; // save doing some long divs in ISR
//tooth / trigger logger
extern unsigned int log_offset;
//dwell exec software 0.128ms timers
extern unsigned char dwl[6], rdwl[2], maxdwl, testcnt;
extern unsigned int swtimer, swtimer_TC5_last;
extern unsigned int deg_per_tooth[MAXNUMTEETH]; // deg*10 AHEAD of tooth-1 i.e. runs 0->, teeth are 1->
extern unsigned char pwmd1, pwmd2, trig2cnt, bl_timer, resetholdoff, n2o_act_timer, n2o2_act_timer;
extern unsigned int inj1cntdown, inj2cntdown, injtime, injtime_EAElagcomp;
extern unsigned char InjPWMTim1, InjPWMTim2, InjPWMPd1, InjPWMPd2, InjPWMDty1, InjPWMDty2;
extern unsigned int mapsample_time, tpssample_time; //.128 ms ticks
extern unsigned char running_seconds;
extern unsigned char fc_off_time;
extern unsigned long tmp_pw1,tmp_pw2,tmp_pw3,tmp_pw4, ticks_per_deg, global_base_pw1;
extern unsigned char tmpdwellsel, tmpcoilsel, tmp_coil;
extern unsigned char tooth_init;
#define WHEEL_NUM_TEETH 20    // minimal to allow all teeth to be grabbed in mainloop exec time
extern unsigned char fuel_cntr, EAElagcomp_squirts, EAElag_squirting;
extern unsigned long dtpred_adder;
extern unsigned char syncerr;
extern unsigned int smallest_tooth_crk, smallest_tooth_cam, false_mask_crk, false_mask_cam, false_period_crk_tix, false_period_cam_tix;
extern unsigned int TC0_last, TC_trig2_last, TC_trig2_last2, TC5_last;
extern unsigned long TC5_32bits, TC5_trig_firstedge;
extern unsigned char idle_advance_timer;
extern unsigned long IC_last; // for triglog2
extern int gl_afrtgt1, gl_afrtgt2;
extern unsigned char num_cyl, divider;
extern unsigned int dwell_us, dwell_us2, dizzy_scaler[NUM_TRIGS], trigret_scaler;
extern unsigned long dwell_long;
extern unsigned char dwellsel_next;

extern unsigned char no_inj, no_squirts;
extern unsigned char spkmode;
extern unsigned char ls1_ls, ls1_sl, ls1_ls_last, ls1_sl_last;
extern unsigned char last_edge, last_edge2;
#define RPMDOT_N 15
extern unsigned int rpmdot_data[RPMDOT_N][2];
extern unsigned int tps_ring[8];
extern unsigned char tps_ring_cnt;
#define TPSDOT_N 10
int tpsdot_data[TPSDOT_N][2];

extern unsigned int remotePWMfreq;
extern unsigned char remotePWMscale;

extern unsigned int srl_timeout;
extern unsigned char ac_idleup_adder;
extern unsigned int map_cnt, map_temp_cnt, maf_cnt, maf_temp_cnt;
extern unsigned long map_sum, map_temp_sum, maf_sum, maf_temp_sum;
extern int flash_adv_offset;
extern unsigned int pwm_idle_clk, idle_max_on[4], idle_max_off[4];
extern unsigned char pwm_idle_stat, idle_dith_cnt;

extern variables outpc;
extern unsigned char canbuf[17];
#define SRLDATASIZE 256
#define SRLHDRSIZE 13
extern char srlbuf[SRLDATASIZE + SRLHDRSIZE]; // 3 byte header + command + 256 + CRC32
#define SRLVER 2
extern datax datax1;
extern unsigned int mapadc_thresh;
extern unsigned char mapmin_tooth, mapmin_tooth_temp;
extern unsigned int db_ptr;

#define MAPSAMPLE_OPT_USE_AVG 0x4

// ignition definitions to swap timer interrupts TC2/TC4/TC5/TC6/TC7 if MS2 vs. Microsquirt // added TC7 and TC4/TC6 (for uS module)
// NB, additional space excludes these from ms2_extra_main_vars.h
#ifndef MICROSQUIRT
# define TC_ign TC7    // was TC2
# define TFLG_ign 0x80 // was 0x04
# define TC_trig2 TC5
# define TFLG_trig2 0x20
# define TC_rotINJ3 TC2
# define TFLG_rotINJ3 0x04
# define TC_rotINJ4 TC4
# define TFLG_rotINJ4 0x10
# define TC_dwl TC6
# define TFLG_dwl 0x40
#else
# define TC_ign TC5
# define TFLG_ign 0x20
# define TC_trig2 TC2
# define TFLG_trig2 0x04
# define TC_rotINJ3 TC6
# define TFLG_rotINJ3 0x40
# define TC_rotINJ4 TC7
# define TFLG_rotINJ4 0x80
# define TC_dwl TC4
# define TFLG_dwl 0x10
#endif

extern unsigned char maplog_cnt, maplog_max;
extern unsigned char testmode_glob, iactest_glob, mmsDiv_testio, clk_testio;
extern unsigned int testmode_cnt;
extern unsigned char nextcyl_cnt, skipdwell[NUM_TRIGS], skipinj, skipinj_revlim;
extern unsigned char rand_ptr, spkcut_thresh, spkcut_thresh_tmp;

extern volatile unsigned char *port_shift_cut_in, *port_shift_cut_out;
extern volatile unsigned char pin_shift_cut_in, pin_shift_cut_match, pin_shift_cut_out;
extern unsigned char shift_cut_phase, shift_cut_timer;

extern long lsum_ign, lsum_rot, lsum_fuel1, lsum_fuel2;
extern unsigned int dashbcast_sndclk;
extern unsigned char sync_holdoff;
#define SYNC_HOLDOFF_TIME 10 /* 1 second */
extern unsigned int sync_holdoff_rpm;

/* this next group were local globals in misc.c */
extern long boost_ctl_last_error;
extern long boost_ctl_last_pv[2];
extern char boost_PID_enabled;
extern int boost_ctl_duty_100;
extern int boost_sensitivity_old;

/* this next group were local globals in idle.c */
extern long PV_last[2];
extern int pwmidle_stepsize, pwmidle_numsteps;
extern int IACmotor_100, IACmotor_pos_tmp, idleadj_last;
extern int rpm_last;
extern unsigned int pwmidle_max_rpm_last;
extern unsigned int pwmidle_targ_stepsize, pwmidle_targ_numsteps, pwmidle_targ_last, targ_rpm;
extern char valve_closed, last_direction;
extern char last_acbutton_state;
extern int ac_idleup_cl_targetadder, idle_voltage_comp;
extern unsigned char pwmidle_shift_timer;
extern unsigned int ac_idleup_timer;
extern unsigned char ac_time_since_last_on;
#define PWMIDLE_RESET_PID         0x1 
#define PWMIDLE_RESET_JUSTLIFTED  0x2 
#define PWMIDLE_RESET_INIT        0x4 
#define PWMIDLE_RESET_JUSTCRANKED 0x8 
#define PWMIDLE_RESET_CALCNEWTARG 0x10 
#define PWMIDLE_RESET_DPADDED     0x20
#define PWMIDLE_RESET_INGEAR      0x40

/* For fuel metering pulses. */
extern unsigned long injpw_accum;
extern unsigned char injpw_timer;
extern volatile unsigned char *port_injpw;
extern unsigned char pin_injpw;
extern unsigned int injpw_thresh;

/* this next group were local globals in ign.c */
extern unsigned long dtpred_adder;

/* this next group were local globals in ego.c */
extern unsigned long ego_last_run;
extern long PID_scale_factor;
extern long egocor_100[2];

#define LOCALFLAGS_RUNFUEL 0x1

/* 'user defined'                                                           *  
 * Here are some variables defined to help the new programmer get started   *
 * search for 'user defined' in ms2_extra_user.c for more notes             *
 *                                                                          */
//#define USER_DEF_ON 1
#ifdef USER_DEF_ON
//extern unsigned long user_ulong;
//extern unsigned int user_uint;
//extern unsigned char user_uchar;
#endif
/* end user defined section                                                 */

