/* $Id: ms2_extra_init.c,v 1.204 2019/06/05 10:05:04 jsmcortina Exp $
 * Copyright 2006, 2007, 2008, 2009, 2010, 2011, 2012, 2013
 * James Murray and Kenneth Culver
 *
 * This file is a part of MS2/Extra.
 *
 * You should have received a copy of the code LICENSE along with this source,
 * ask on the www.msextra.com forum if you did not.
 *
 * main_init
    Origin: Al Grippo
    Moderate: Adapt for MS2/Extra. James Murray / Kenneth Culver / Jean Belanger
    Majority: Al Grippo / James Murray / Kenneth Culver / Jean Belanger

 * set_prime_ASE
    Origin: Al Grippo
    Major: James Murray / Kenneth Culver
    Majority: Al Grippo / James Murray / Kenneth Culver
 */


#include "ms2_extra.h"

void set_prime_ASE(void)
{
    PrimeP = (unsigned short)CW_table(outpc.clt,(int *)flash5.CWPrime, (int *)flash5.temp_table_p5);  // msx10
    ase_value = (unsigned short)CW_table(outpc.clt,(int *)flash5.CWAWEV, (int *)flash5.temp_table_p5);     // %
    ase_cycles = (unsigned short)CW_table(outpc.clt,(int *)flash5.CWAWC, (int *)flash5.temp_table_p5);       // cycles
}

void set_EAE_lagcomp(void)
{
    EAEdivider = divider * 100;
}

void main_init(void)
{
    int ix;
    unsigned char adctest, gpio1adctest, tmp_opt, pt5ip = 0, map_algo = 0;

    PORTE &= ~0x10;            // turn off fuel pump
    DDRM |= 0xFC;    // port M - all outputs, full drive by default

    // initalize PLL - reset default is Oscillator clock
    // 8 MHz oscillator, PLL freq = 48 MHz, 24 MHz bus,
    //  divide by 16 for timer of 2/3 usec tic
    PLLCTL &= 0xBF;     // Turn off PLL so can change freq
    SYNR = 0x02;        // set PLL/ Bus freq to 48/ 24 MHz
    REFDV = 0x00;
    PLLCTL |= 0x40;     // Turn on PLL
    // wait for PLL lock
    while (!(CRGFLG & 0x08));
    CLKSEL = 0x80;      // select PLL as clock

    // wait for clock transition to finish
    for (ix = 0; ix < 60; ix++);

    // open flash programming capability
    Flash_Init();

    if((int)RamBurnPgm & 0x0001)	{   // odd address - cpy to even one
        (void)memcpy((void *)RamBurnPgm,NoOp,1);         // cpy noop to 1st location
        (void)memcpy((void *)&RamBurnPgm[1],SpSub,32);   // cpy flashburn core pgm to ram
    } else {
        (void)memcpy((void *)RamBurnPgm,SpSub,32);       // cpy flashburn core pgm to ram
    }

    page = 0; // on boot no pages in ram
    pg4_ptr = (page4_data *)&flash4;
    pg5_ptr = (page5_data *)&flash5;
    pg10_ptr = (page10_data *)&flash10;
    pg8_ptr = (page8_data *)&flash8;
    pg9_ptr = (page9_data *)&flash9;
    pg11_ptr = (page11_data *)&flash11;
    pg12_ptr = (page12_data *)&flash12;

    conf_err = 0; // no config errors yet
    flagbyte0 = 0; // must do these before ign_reset as it sets various bits
    flagbyte1 = 0;
    flagbyte2 = 0;
    flagbyte3 = 0;
    flagbyte4 = 0;
    flagbyte5 = 0;
    flagbyte6 = 0;
    flagbyte11 = 0;
    flagbyte14 = 0;
    flagbyte15 = 0;
    resetholdoff = 0;
    sync_holdoff = 0;

    // set up i/o ports
    //    - port M2 is fast idle solenoid
    //    - port M3 is inj led
    //    - port M4 is accel led
    //    - port M5 is warmup led
    //    - port E0 is flex fuel sensor input
    //    - port E4 is fuel pump
    //    - port P5 is bootload pin (input)
    //    - port T6 is IAC Coil A
    //    - port T7 is IAC Coil B
    //    - port B4 is IAC Enable
    //    - port A0 isn't Knock Enable
    //    - port AD6 can be spark 5 (JS5)
    //    - port AD7 can be spark 6 (JS4)
    DDRM |= 0xFC;    // port M - all outputs, full drive by default
    DDRE |= 0x10;	   // port E4 - output, E0 is input
#ifdef MICROSQUIRT
    DDRT = 0x7a; // injector and ign as outputs, two tach inputs. Simpler hardware, less choices. (PT7 left as input for now)
#else
    DDRT = 0xC0;    // port T6-7 - outputs
#endif
    DDRB |= 0x10;    // port B4 - output
    IRQCR &= ~0x40;	// remove External IRQ pins from interrupt logic
    // can be input (flex fuel) or output (misc port)  // check for clashes in a minute
    if ((flash4.FlexFuel & 0x0f) == 0x3) { // on and PA0
        DDRA &= 0xfe;    // port A0 - input
    } else {
        DDRA |= 0x01;    // port A0 - output
    }
    //  Set pointers to real port addresses
    for(ix = 0; ix < 8; ix++)  {
        pPTTpin[ix] = pPTT;
    }
    pPTMpin2 = pPTM;
    pPTMpin3 = pPTM;
    pPTMpin4 = pPTM;
    pPTMpin5 = pPTM;
    pPTApin0 = pPORTA;

	if (flash8.seq_inj & 0x04) {
		seq_inj_ctrl = 0;
	} else {
		seq_inj_ctrl = SEQ_STD_INJ;
	}

    // reset those pointers to pins which are to be used as alternate outputs
#ifdef MICROSQUIRT
    if (!(seq_inj_ctrl & SEQ_STD_INJ) && (flash4.spr_port[4] || flash4.spr_port[5] || ((flash5.tacho_opt & 0x0f) == 1) || ((flash5.tacho_opt & 0x0f) == 2) )) {
		// Conflict with additional injector channels and spare ports or tacho output 
        conf_err = 45;
    }
#endif

    for(ix = 0;ix < NPORT; ix++)  {
        if (flash4.spr_port[ix])  {
            // pin output from normal function goes to dummy reg in ram
            if (ix == 0) {
                pPTMpin2 = &dummyReg;
            } else if (ix == 1) {
                pPTMpin3 = &dummyReg;
            } else if (ix == 2) {
                pPTMpin4 = &dummyReg;
            } else if (ix == 3) {
                pPTMpin5 = &dummyReg;
            } else if (ix < 6) {
#ifndef MICROSQUIRT
                /* Workaround for MT bug, reverse IAC1 and IAC2 */
                /* But only on MS2. Microsquirt module is correct */
                if (ix == 4) {
                    pPTTpin[7] = &dummyReg;
                } else if (ix == 5) {
                    pPTTpin[6] = &dummyReg;
#else
                if (ix == 4) {
                    pPTTpin[6] = &dummyReg;
                } else if (ix == 5) {
                    pPTTpin[7] = &dummyReg;
                    DDRT |= 0x80;
#endif
                } else {
                    pPTTpin[ix + 2] = &dummyReg;
                }
            } else {
                pPTApin0 = &dummyReg;
            }
            set_spr_port((char)ix, flash4.init_val[ix]);
            lst_pval[ix] = flash4.init_val[ix];
        }
    }

    // initialise num_cyl variable.
    if (flash4.EngStroke & 1) {
        num_cyl = (flash4.no_cyl & 0x1f) << 1;     // two stroke so double it
    } else {
        num_cyl = (flash4.no_cyl & 0x1f);
    }

    spkmode = flash4.spk_mode & 0x3f; // by setting here prevents spurious changes while running and allows mask here

    //calculate number of spark outputs once at startup and store in ram
    if ((spkmode == 2) || (spkmode == 3)) { // basic trigger, trigger return
//        if (flash4.ICIgnOption & 0x8) {
//            num_spk = 2; // oddfire
//        } else {
            num_spk = 1;
//        }
     } else if (spkmode == 31) { // Fuel only
         num_spk = 0;
    } else if (spkmode == 14) { // Twin trigger
        num_spk = 2;
    } else {
        //How many spark outputs? Check for special cases first.
        if (flash4.no_cyl == 1) {
            num_spk = 1;

        } else if (flash4.no_cyl == 2) {
            if (flash4.EngStroke & 1) { // 2 stroke
                if (((flash4.spk_mode3 & 0xe0) != 0) || (flash4.ICIgnOption & 0x08)) {
                    num_spk = 2; // fires every 180deg or odd
                } else {
                    num_spk = 1; // fires every 360deg
                }
            } else { // 4 stroke
                if ((flash4.ICIgnOption & 8) == 0) { // even
                    if ((flash4.spk_mode3 & 0xe0) == 0x80) { // COP
                        num_spk = 2;
                    } else {
                        num_spk = 1; // will be wasted
                    }
                } else { // odd
                    num_spk = 2; // always two outputs whatever the user said
                }
            }

        } else if (flash4.no_cyl == 3) {
            if ((flash4.spk_mode3 & 0xe0) == 0x80) { // COP
                num_spk = 3;
            } else {
                num_spk = 1;
            }

        } else { // regular engines
            switch (flash4.spk_mode3 & 0xc0 ) {
                case 0x40:
                    if (flash4.spk_mode3 & 0x20) {
                        num_spk = num_cyl; // wasted COP
                    } else {
                        num_spk = num_cyl >> 1;
                    }
                    break;
                case 0x80:
                    num_spk = num_cyl;
                    break;
                case 0xc0:
                    num_spk = 2;
                    break;
                case 0:
                default:
                    num_spk = 1;
                    break;
            }
        }
    }

    if ((num_cyl > 2)
        && ((flash4.ICIgnOption & 0x08) /* oddfire > 2 cyl */
            || (num_cyl & 1))) { /* odd num cyls > 2 */
        flagbyte1 |= FLAGBYTE1_ODDFIRECYL;
        if ((flash4.spk_mode3 & 0xe0) == 0x60) { /* wasted COP */
            conf_err = 64;
        }
    }
#ifdef MICROSQUIRT
    if (num_spk > 4) {
        conf_err = 30;
    }
#endif

    /* rotary settings and some sparkbits */
    if (((flash4.EngStroke & 0x03) == 0x03)) {
        num_spk <<= 1;
        if (num_cyl == 4) { // 2 rotor
            if ((flash4.spk_mode3 & 0xe0) == 0x40) {  // Rotary wasted spark means FC/FD leading
                num_spk = 3;
            } 
        } else {
            conf_err = 60;
        }
        if ((flash4.spk_mode3 & 0xe0) == 0x80) { // COP means RX8 style leading
            flagbyte11 |= FLAGBYTE11_RX8;
        }

    } else if (flash4.spk_conf2 & 0x80) { // toyota DLI
        if (((flash4.spk_mode3 & 0xe0) != 0x40) || ((flash4.ICIgnOption & 0x8) == 0x8)) {
            /* not wasted spark or is oddfire */
            conf_err = 56;
        }
        if (num_cyl == 4) {
            flagbyte11 |= FLAGBYTE11_DLI4;
        } else if (num_cyl == 6) {
            flagbyte11 |= FLAGBYTE11_DLI6;
        } else {
            conf_err = 56;
        }
    }

    if (spkmode < 2) { /* EDIS */
        /* ALWAYS use JS10, irrespective of output pin choice. */
        flagbyte11 |= FLAGBYTE11_JS10;
    } else {
        /* set up other spark quickbits (needed before firing) */
#ifdef MICROSQUIRT
        if ((flash4.spk_config_spka & 0x1) && (num_spk == 1)) {
#else
            if ((flash4.spk_config_spka & 0x1) || (num_spk > 3)) {
#endif
            flagbyte11 &= ~FLAGBYTE11_JS10;
        } else {
            flagbyte11 |= FLAGBYTE11_JS10;
        }
    }

  // Turn off all spark outputs right away
#ifdef MICROSQUIRT
  FIRE_ALL_US;
#else
  FIRE_ALL;
#endif

    if (!(flagbyte11 & FLAGBYTE11_JS10)) { // not using JS10, so are using D14 or WLED
#ifdef MICROSQUIRT
        if (pPTMpin5 == &dummyReg) {
            conf_err = 57;
        } else {
           pPTMpin5 = &dummyReg; //WLED
        }
#else
        if (pPTMpin3 == &dummyReg) {
            conf_err = 57;
        } else {
           pPTMpin3 = &dummyReg; //D14
        }
#endif
    } else {
        pPTTpin[5] = &dummyReg; //JS10 / IGN1
    }

    if (num_spk >=2) {
#ifndef MICROSQUIRT
        if (pPTMpin4 == &dummyReg) {
            conf_err = 57;
        } else {
            pPTMpin4 = &dummyReg; // D16
        }
#else
        pPTTpin[4] = &dummyReg; //IGN2
#endif
    }

    if (num_spk >=3) {
        if (pPTMpin5 == &dummyReg) {
            conf_err = 57;
        } else {
            pPTMpin5 = &dummyReg; // D15 same on MS2 and uS
        }
    }

    if (num_spk >=4) {
#ifndef MICROSQUIRT
        if (pPTApin0 == &dummyReg) {
            conf_err = 57;
        } else {
            pPTApin0 = &dummyReg; //PA0
        }
#else
        if (pPTMpin4 == &dummyReg) {
            conf_err = 57;
        } else {
            pPTMpin4 = &dummyReg; // ALED
        }
#endif
    }

    memset((unsigned char*)&outpc, 0, sizeof(outpc)); /* set all to zero unless set specifically later */
    memset((unsigned char*)&datax1, 0, sizeof(datax1)); /* same */

    if ((spkmode == 2) && (flash4.spk_conf2 & SPK_CONF2_GMBYPASS)) {
#ifdef MICROSQUIRT
        // Grab SPKB as HEI bypass - Microsquirt
        pPTTpin[4] = &dummyReg;
#else
        // Grab end LED D16 as HEI bypass - MS2
        pPTMpin4 = &dummyReg;
#endif
    }

    // these two test bytes get populated bit by bit as features use them, checking as
    // they go that nobody else set that bit first. If so then ERROR
    adctest = 0;
    gpio1adctest = 0;

    if (num_spk >= 5) {
        DDRAD |= 0x40; // enable pin AD06 as digital output
        adctest |= 0x40;
    }

    if (num_spk >= 6) {
        DDRAD |= 0x80; // enable pin AD07 as digital output
        adctest |= 0x80;
    }

    if (num_spk > 6) {
        conf_err = 37; // too many spark outputs
    }
	
	if (((spkmode < 4) || (spkmode == 31)) && (flash8.seq_inj & 0x03)) {
		// Sequential/Semi-sequential cannot be used with EDIS, EDIS Multispk, Basic trigger or Trigger return or Fuel only
		conf_err = 55;
	}

// knock input pins
    if (flash4.knk_option & 0x03) {
		if (flash4.knkport & 0x08) {
			// Remote knock input: initialize input to 0
			outpc.gpioport[2] &= ~(1 << (flash4.knkport & 0x07));
		} else {
			// Local knock input pin
	        if (flash4.knkport & 0x01) { // option AD6/JS5
	            if (adctest & 0x40) {
	                conf_err = 4;
	            } else {
	                adctest |= 0x40;
                    if (flash4.knk_option & 0x80) {
	                    ATD0DIEN &= ~0x40;
                    } else {
	                    DDRAD &= ~0x40; // ensure pin AD06 is input
	                    ATD0DIEN |= 0x40;
	                    if ((flash4.knk_option & 0x60) != 0x20) {     // pullup/down
	                        PERAD |= 0x40;
	                        if (flash4.knk_option & 0x40) { // choose polarity
	                            if (flash4.knk_option & 0x20) {
	                                PPSAD |= 0x40;
	                            }
	                        } else { // same as knock
	                            if (!(flash4.knk_option & 0x10)) {
	                                PPSAD |= 0x40;
	                            }
	                        }
	                    }
                    }
	            }
	        } else { // default AD7/JS4
	            if (adctest & 0x80) {
	                conf_err = 4;
	            } else {
	                adctest |= 0x80;
                    if (flash4.knk_option & 0x80) {
	                    ATD0DIEN &= ~0x80;
                    } else {
	                    DDRAD &= ~0x80; // enable pin AD06 as digital input
	                    ATD0DIEN |= 0x80;
	                    if ((flash4.knk_option & 0x60) != 0x20) {     // pullup/down
	                        PERAD |= 0x80;
	                        if (flash4.knk_option & 0x40) { // choose polarity
	                            if (flash4.knk_option & 0x20) {
	                                PPSAD |= 0x80;
	                            }
	                        } else { // same as knock
	                            if (!(flash4.knk_option & 0x10)) {
	                                PPSAD |= 0x80;
	                            }
	                        }
	                    }
                    }
	            }
	        }
		}
    }

    // check for output clashes with code
    if ((flash4.FlexFuel & 0x0f) == 0x3) { // on and PA0
        if (pPTApin0 == &dummyReg) {  // alternate pin is PA0, check for clash
            conf_err = 5;
        } else {
            pPTApin0 = &dummyReg;
        }
    }

    // adc clashes
    if (flash4.BaroOption == 2) {
        if ((flash4.rtbaroport & 0x0f) < 0x7) {
            if (((flash4.rtbaroport & 0x0f) == 0) && (flash4.mapport & 1)) {
                /* not allowed to have MAP and Baro using same input */
                conf_err = 2;
            } else if ( ((adctest & 0x80) && ((flash4.rtbaroport & 0x0f) == 7))
                    || ((adctest & 0x40) && ((flash4.rtbaroport & 0x0f) == 6)) ) {
                conf_err = 2;
            } else {
                if ((flash4.rtbaroport & 0x0f) == 6) {
                    adctest |= 0x40;
                } else if ((flash4.rtbaroport & 0x0f) == 7) {
                    adctest |= 0x80;
                }
            }
        } else {
            if (gpio1adctest & (1<<(flash4.rtbaroport & 0x7))) {
                conf_err = 2;
            } else {
                gpio1adctest |= (1<<(flash4.rtbaroport & 0x7));
            }
        }
    }

    if(((flash4.EgoOption & 0x07) == 2) || ((flash4.EgoOption & 0x07) == 4))  {
        if ((flash4.ego2port & 0x0f) < 0x7) {
            if ( ((adctest & 0x80) && ((flash4.ego2port & 0x0f) == 7))
                    || ((adctest & 0x40) && ((flash4.ego2port & 0x0f) == 6)) ){
                conf_err = 2;
            } else {
                if ((flash4.ego2port & 0x0f) == 6) {
                    adctest |= 0x40;
                } else if ((flash4.ego2port & 0x0f) == 7) {
                    adctest |= 0x80;
                }
            }

        } else {
            if (gpio1adctest & (1<<(flash4.ego2port & 0x7))) {
                conf_err = 2;
            } else {
                gpio1adctest |= (1<<(flash4.ego2port & 0x7));
            }
        }
    }

    /* see if none of our algos use MAP */
    if (((flash4.FuelAlgorithm & 0xF) != 1) && ((flash4.FuelAlgorithm & 0xF0) != 0x10) && // not SD
        ((flash4.FuelAlgorithm & 0xF) != 2) && ((flash4.FuelAlgorithm & 0xF0) != 0x20) && // not %baro
        (((flash4.FuelAlgorithm & 0xF) != 3) || (((flash4.FuelAlgorithm & 0xF) == 3) && (!(flash4.loadopts & LOADOPTS_LOADMULT)))) &&
        // not alpha-n or is alpha-n but multiply MAP off
        (((flash4.FuelAlgorithm & 0xF0) != 0x30) || (((flash4.FuelAlgorithm & 0xF0) == 0x30) && (!(flash4.loadopts & LOADOPTS_LOADMULT)))) &&
        ((flash4.FuelAlgorithm & 0xF) != 6) && ((flash4.FuelAlgorithm & 0xF0) != 0x60) && // not ITB
        ((flash4.IgnAlgorithm & 0xF) != 1) && ((flash4.IgnAlgorithm & 0xF0) != 0x10) && // repeat for spark load etc.
        ((flash4.IgnAlgorithm & 0xF) != 2) && ((flash4.IgnAlgorithm & 0xF0) != 0x20) &&
        (((flash4.IgnAlgorithm & 0xF) != 3)  || (((flash4.IgnAlgorithm & 0xF) == 3) && (!(flash4.loadopts & LOADOPTS_LOADMULT)))) &&
        (((flash4.IgnAlgorithm & 0xF0) != 0x30)  || (((flash4.IgnAlgorithm & 0xF0) == 0x30) && (!(flash4.loadopts & LOADOPTS_LOADMULT)))) &&
        ((flash4.IgnAlgorithm & 0xF) != 6) && ((flash4.IgnAlgorithm & 0xF0) != 0x60) &&
        ((flash4.extra_load_opts & 0xF) != 1) && ((flash4.extra_load_opts & 0xF0) != 0x10) && 
        ((flash4.extra_load_opts & 0xF) != 2) && ((flash4.extra_load_opts & 0xF0) != 0x20) &&
        (((flash4.extra_load_opts & 0xF) != 3) || (((flash4.extra_load_opts & 0xF) == 3) && (!(flash4.loadopts & LOADOPTS_LOADMULT)))) &&
        (((flash4.extra_load_opts & 0xF0) != 0x30) || (((flash4.extra_load_opts & 0xF0) == 0x30) && (!(flash4.loadopts & LOADOPTS_LOADMULT)))) && 
        ((flash4.extra_load_opts & 0xF) != 6) && ((flash4.extra_load_opts & 0xF0) != 0x60))  {

        map_algo = 0; // nothing using MAP
    } else {
        map_algo = 1;
    }

    mafload_no_air = 100;
    mafport = (unsigned short*)&dummyReg;
    /* set up MAF input for use or logging */
    if (flash4.MAFOption & 0x30) {
        unsigned char maftmp;

        flagbyte6 |= FLAGBYTE6_USE_MAF;

        maftmp = flash4.MAFOption & 0x30;

        if (maftmp == 0x10) {
            mafport = (unsigned short*)&ATD0DR7;
            if (adctest & 0x80) {
                conf_err = 47;
            } else {
                adctest |= 0x80;
            }
        } else if (maftmp == 0x20) {
            mafport = (unsigned short*)&ATD0DR6;
            if (adctest & 0x40) {
                conf_err = 47;
            } else {
                adctest |= 0x40;
            }
        } else {
            mafport = (unsigned short*)&ATD0DR0;
        }
        
        /* was 61840750 for CID */
        /* this factor is calculated as follows - only used to generate mafload
        by definition mafload = 101.35 kPa at 100% VE = 1013.5 units.
        Density of air at 20C and 101.35kPa = 1.2041 x 10^-3 g/cc
        airden factor = 100.0% at 20C = 1000 units
        mafload = ((MAFCoef / aircor) * maf) / rpm)
        at 100% VE, flow = size x rpm/120 x 1.2041 x 10^-3 x 100
        maf = 100 x flow  units
        The 120 is converting from rpm to cycles/sec on a 4 stroke
        MAFCoef = k / size

        So, 1013.5 = ((k/size / 1000) x 100 x flow) / rpm
            or k = 1.0135 x 10^6 x size x rpm x 120
                   ---------------------------------
                    100 x size x rpm x 1.2041 x 10^-3
          rpm, size drop out
            k = 1.0135 x 10^6 x 120 / (100 x 1.2041 x 10^-3) 
                = 1010048999
  (not quite the same as Al's figure 1013569893L which appears to use air density as 1.200x10^-3
        */
        MAFCoef = 1010048999L / flash4.enginesize;
        if (flash4.EngStroke & 0x01) {
            /* for 360 deg cycle engines, halve it as MAF will be double */
            MAFCoef >>= 1;
        }
    }

    if ((flash4.FuelAlgorithm & 0xF) == 5) {

        if (!(flagbyte6 & FLAGBYTE6_USE_MAF)) {
            /* MAF enabled but no input defined */
            conf_err = 48;
        }

        /* For reference
            1 = Speed Density - requires MAP
            2 = %baro - requires MAP
            3 = alpha-n - optionally uses MAP
            4 = MAFload - no MAP
            5 = MAF - no MAP
            6 = ITB - requires MAP
        */
        /* see if none of our algos use MAP */
        if (map_algo == 0)  {
            flagbyte6 |= FLAGBYTE6_USE_MAF_ONLY; /* no MAP available, so use MAFload for MAPdot */
        } else if ((flash4.MAFOption & 0x30) == 0x30) {
            /* MAP port used for MAP and MAF -> error (incomplete check) */
                conf_err = 47;
        }

    } else {
        /* MAFload as secondary without MAF as primary */
        if (((flash4.FuelAlgorithm & 0xF0) == 0x40) ||
            ((flash4.IgnAlgorithm & 0xF) == 4) || ((flash4.IgnAlgorithm & 0xF0) == 0x40) ||
            ((flash4.extra_load_opts & 0xF) == 4) || ((flash4.extra_load_opts & 0xF0) == 0x40)) {
            if (!(flagbyte6 & FLAGBYTE6_USE_MAF)) {
                /* MAFload enabled but no input defined */
                conf_err = 48;
            }
        }
    }

    if ((flash4.mapport & 1) == 1) {
        // on - ADC0
        flagbyte20 |= FLAGBYTE20_USE_MAP;
    } else {
        // MAP disabled
        flagbyte20 &= ~FLAGBYTE20_USE_MAP;
    }

    if ((!(flagbyte20 & FLAGBYTE20_USE_MAP)) && (map_algo)) {
            /* MAP off, but algos need it */
        conf_err = 170;
    }

    /* Check MAP sampling angles are sensible */
    {
        int an;
        if (flash4.EngStroke & 0x01) {
            an = 3600;
        } else {
            an = 7200;
        }
        an = an / (flash4.no_cyl & 0x1f);
        if ((flash4.mapsample_angle < 0) || (flash4.mapsample_angle >= an)
            || (flash4.mapsample_window > an)) {
            conf_err = 58;
        }
    }

    /* do port P here as might be used for idle */
    DDRP = 0x00;
    PERP = 0xFF;     // enable pullup resistance for port P

    /* first convert from broken-out idle settings to old number */
    IdleCtl = flash4.IdleCtl & 0x3;
    if (IdleCtl == 2) {
        if (flash4.IdleCtl & 0x08) {
            IdleCtl = 6;
        } else {
            IdleCtl = 4;
        }
    } else if (IdleCtl == 3) {
        if (flash4.IdleCtl & 0x08) {
            IdleCtl = 8;
        } else {
            IdleCtl = 3;
        }
    } // 0,1 unchanged
    /* "moving-only" vs. "always-on" handled via IACcurlim*/

    pin_iacen = 0;
    pin_iac1 = 0;
    pin_iac2 = 0;
    pol_iacen = 0;
    pol_iac1 = 0;
    pol_iac2 = 0;
    /* default ports */
    port_iacen = &PORTB;
    port_iac1 = &PTT;
    port_iac2 = &PTT;
    /* Mark ports as used. */
    if ((IdleCtl == 2) || (IdleCtl == 3) || (IdleCtl == 5) || (IdleCtl == 7) || (IdleCtl == 8)) {
        if ((flash4.IdleCtl & 0xc0) == 0x40) { // optional outputs SPAREADC2,FIDLE,SPAREADC
            pin_iacen = 0x80; // SPAREADC2
            port_iacen = &PTAD;
            DDRAD |= 0x80;
            adctest |= 0x80;
            ATD0DIEN &= ~0x80;
            pol_iacen = 0;

            port_iac1 = &PTM; // FIDLE
            pin_iac1 = 0x04;
            DDRM |= 0x04;
            if (pPTMpin2 == &dummyReg) {
                conf_err = 62;
            } else {
                pPTMpin2 = &dummyReg;
            }
            pol_iac1 = 1; // inverting output

            port_iac2 = &PTAD; // SPAREADC
            pin_iac2 = 0x40;
            adctest |= 0x40;
            ATD0DIEN &= ~0x40;
            DDRAD |= 0x40;
            pol_iac2 = 0;

        } else if ((flash4.IdleCtl & 0xc0) == 0x80) { // optional outputs WLED,FIDLE,SPAREADC
            pin_iacen = 0x20; // WLED
            port_iacen = &PTM;
            DDRM |= 0x20;
            if (pPTMpin5 == &dummyReg) {
                conf_err = 62;
            } else {
                pPTMpin5 = &dummyReg;
            }
            pol_iacen = 1; // inverting

            port_iac1 = &PTM; // FIDLE
            pin_iac1 = 0x04;
            DDRM |= 0x04;
            if (pPTMpin2 == &dummyReg) {
                conf_err = 62;
            } else {
                pPTMpin2 = &dummyReg;
            }
            pol_iac1 = 1; // inverting

            port_iac2 = &PTAD; // SPAREADC
            pin_iac2 = 0x40;
            adctest |= 0x40;
            ATD0DIEN &= ~0x40;
            DDRAD |= 0x40;
            pol_iac2 = 0;

        } else if ((flash4.IdleCtl & 0xc0) == 0xc0) { // optional outputs BOOT/none,FIDLE,SPAREADC
            if (((*(unsigned int*)0xffd6) == 0xf976) || 1) {
                /* can't re-use bootloader input because current monitor checks it on each serial interrupt.
                    No enable output. Wire enable to ground. */
                pin_iacen = 0;
                port_iacen = &dummyReg;
            } else {
                /* in future might be able to use BOOT */
                pin_iacen = 0x20;
                port_iacen = &PTP;
                DDRP |= 0x20;
                PWME &= ~0x20;
            }

            port_iac1 = &PTM; // FIDLE
            pin_iac1 = 0x04;
            DDRM |= 0x04;
            if (pPTMpin2 == &dummyReg) {
                conf_err = 62;
            } else {
                pPTMpin2 = &dummyReg;
            }
            pol_iac1 = 1; // inverting output

            port_iac2 = &PTAD; // SPAREADC
            pin_iac2 = 0x40;
            adctest |= 0x40;
            ATD0DIEN &= ~0x40;
            DDRAD |= 0x40;
            pol_iac2 = 0;

        } else { /* MS2 default: IACEN, PT6, PT7 */
            if ((pPTTpin[7] == &dummyReg) || (pPTTpin[6] == &dummyReg)) {
                conf_err = 61;
            } else {
                pPTTpin[6] = &dummyReg;
                pPTTpin[7] = &dummyReg;
                DDRT |= 0xc0;
                pin_iacen = 0x10;
                pin_iac1 = 0x40;
                pin_iac2 = 0x80;
            }
        }
        if (pol_iacen) {
            iac_holddty = flash4.IACcurlim & 0x03;
        } else {
            /* normal case in logical 0 on output turns on power, so Always on gives 0 here */
            iac_holddty = 2 - (flash4.IACcurlim & 0x03);
        }

    } else if ((IdleCtl == 1)
            || (((IdleCtl == 4) || (IdleCtl == 6)) && ((flash5.pwmidle_port & 0x03) == 0))) {
        if (pPTMpin2 == &dummyReg) {
            conf_err = 62;
        } else {
            pPTMpin2 = &dummyReg;
        }
    }

    //check for tacho out conflicts
    if (flash5.tacho_opt & 0x80) {
        tmp_opt = flash5.tacho_opt & 0x0f;
        if (tmp_opt == 0) {
            if (pPTTpin[5] == &dummyReg) {
                conf_err = 6;
            } else {
                pPTTpin[5] = &dummyReg;
            }
        } else if (tmp_opt == 1) {
            if (pPTTpin[7] == &dummyReg) {
                conf_err = 6;
            } else {
                pPTTpin[7] = &dummyReg;
                DDRT |= 0x80;
            }
        } else if (tmp_opt == 2) {
            if (pPTTpin[6] == &dummyReg) {
                conf_err = 6;
            } else {
                pPTTpin[6] = &dummyReg;
            }
        } else if (tmp_opt == 3) {
            if (pPTApin0 == &dummyReg) {
                conf_err = 6;
            } else {
                pPTApin0 = &dummyReg;
            }
        } else if (tmp_opt == 4) {
            if (pPTMpin2 == &dummyReg) {
                conf_err = 6;
            } else {
                pPTMpin2 = &dummyReg;
            }
        } else if (tmp_opt == 5) {
            if (pPTMpin3 == &dummyReg) {
                conf_err = 6;
            } else {
                pPTMpin3 = &dummyReg;
            }
        } else if (tmp_opt == 6) {
            if (pPTMpin4 == &dummyReg) {
                conf_err = 6;
            } else {
                pPTMpin4 = &dummyReg;
            }
        } else if (tmp_opt == 7) {
            if (pPTMpin5 == &dummyReg) {
                conf_err = 6;
            } else {
                pPTMpin5 = &dummyReg;
            }
        } else if (tmp_opt == 8) {
            if (adctest & 0x40) {
                conf_err = 6;
            } else {
                DDRAD |= 0x40;
                adctest |= 0x40;
            }
        } else if (tmp_opt == 9) {
            if (adctest & 0x80) {
                conf_err = 6;
            } else {
                DDRAD |= 0x80;
                adctest |= 0x80;
            }
        }
    }

    if (flash5.boost_ctl_settings & BOOST_CTL_ON) {
		if (flash5.boost_ctl_settings & BOOST_CTL_REMOTE) {
			// Check that the remote port used is configured as an output
			if ((flash4.can_poll != 3) || !(flash4.enable_poll & 0x08) || !(flash4.ports_dir & (0x01<<((flash5.boost_ctl_pins>>4) - 1))) || !(flash4.ports_dir & (0x01<<((flash5.boost_ctl_pins>>4) + 3)))) {
                conf_err = 27;
			}
		} else {
	        if ((flash5.boost_ctl_pins & 0x0f) == 1) {
	            if (pPTTpin[7] == &dummyReg) {
	                conf_err = 27;
	            } else {
	                pPTTpin[7] = &dummyReg;
	                boostport = pPTT;
	                boostpin = 0x80;
                    DDRT |= 0x80;
	            }
	        } else if ((flash5.boost_ctl_pins & 0x0f) == 2) {
	            if (pPTTpin[6] == &dummyReg) {
	                conf_err = 27;
	            } else {
	                pPTTpin[6] = &dummyReg;
	                boostport = pPTT;
	                boostpin = 0x40;
	            }
	        } else if ((flash5.boost_ctl_pins & 0x0f) == 4) {
	            if (pPTApin0 == &dummyReg) {
	                conf_err = 27;
	            } else {
	                pPTApin0 = &dummyReg;
	                boostport = pPORTA;
	                boostpin = 0x01;
	            }
	        } else if ((flash5.boost_ctl_pins & 0x0f) == 8) {
	            if (pPTMpin2 == &dummyReg) {
	                conf_err = 27;
	            } else {
	                pPTMpin2 = &dummyReg;
	                boostport = pPTM;
	                boostpin = 0x04;
	            }
	        } else if ((flash5.boost_ctl_pins & 0x0f) == 9) {
	            if (pPTMpin3 == &dummyReg) {
	                conf_err = 27;
	            } else {
	                pPTMpin3 = &dummyReg;
	                boostport = pPTM;
	                boostpin = 0x08;
	            }
	        } else if ((flash5.boost_ctl_pins & 0x0f) == 10) {
	            if (pPTMpin4 == &dummyReg) {
	                conf_err = 27;
	            } else {
	                pPTMpin4 = &dummyReg;
	                boostport = pPTM;
	                boostpin = 0x10;
	            }
	        } else if ((flash5.boost_ctl_pins & 0x0f) == 11) {
	            if (pPTMpin5 == &dummyReg) {
	                conf_err = 27;
	            } else {
	                pPTMpin5 = &dummyReg;
	                boostport = pPTM;
	                boostpin = 0x20;
	            }
            } else if ((flash5.boost_ctl_pins & 0x0f) == 0) {
                /* no action */
	        } else {
	            conf_err = 27;
	        }
		}
    }

    //nitrous outputs on IACs or FIDLE+D15
    if ((flash10.N2Oopt & 0x04) && !(flash10.N2Oopt_pins & 0x80)) { // nitrous stage 1 output local
        if (flash10.N2Oopt_pins & 0x10) { // on FIDLE
            if (pPTMpin2 == &dummyReg) {
                conf_err = 39;
            } else {
                pPTMpin2 = &dummyReg;
            }
        } else { // on IAC1
            if (pPTTpin[7] == &dummyReg) {
                conf_err = 28;
            } else {
                pPTTpin[7] = &dummyReg;
                DDRT |= 0x80;
            }
        }
        if (flash10.N2Oopt & 0x08) { // stage 2
            if (flash10.N2Oopt_pins & 0x10) { // on D15
                if (pPTMpin5 == &dummyReg) {
                    conf_err = 40;
                } else {
                    pPTMpin5 = &dummyReg;
                }
            } else {  // on IAC2
                if (pPTTpin[6] == &dummyReg) {
                    conf_err = 28;
                } else {
                    pPTTpin[6] = &dummyReg;
                }
            }
        }
    }

    //check for launch in conflicts
    if (flash10.launch_opt & 0x40) {
        tmp_opt = flash10.launch_opt & 0x0f;
        // do similar checking to above, but xref against inputs and set pue, ddr if req'd
        /* 0 PE0
           1 PE1
           2 JS10 PT5
           3 PA0
           4 AD6
           5 AD7
         */
        if (tmp_opt == 0) {
            if (pPTEpin[0] == &dummyReg) {
                conf_err = 7;
            } else {
                pPTEpin[0] = &dummyReg;
            }
        } else if (tmp_opt == 1) {
            if (pPTEpin[1] == &dummyReg) {
                conf_err = 7;
            } else {
                pPTEpin[1] = &dummyReg;
            }
        } else if (tmp_opt == 2) {
            if (pPTTpin[5] == &dummyReg) {
                conf_err = 7;
            } else {
                pPTTpin[5] = &dummyReg;
                DDRT &= ~0x20;
                pt5ip = 1;
                PERT |= 0x20;
                PPST &= ~0x20;
                //need to configure as input and disable interrupt
            }
        } else if (tmp_opt == 3) {
            if (pPTApin0 == &dummyReg) {
                conf_err = 7;
            } else {
                pPTApin0 = &dummyReg;
                DDRA &= ~0x01; /* configure as input. Pullup enabled later */
            }
        } else if (tmp_opt == 4) {
            if (adctest & 0x40) {
                conf_err = 7;
            } else {
                adctest |= 0x40;
                ATD0DIEN |= 0x40;
                DDRAD &= ~0x40;
                PPSAD &= ~0x40; // use pull UP
                PERAD |= 0x40; // enable a pull
            }
        } else if (tmp_opt == 5) {
            if (adctest & 0x80) {
                conf_err = 7;
            } else {
                adctest |= 0x80;
                ATD0DIEN |= 0x80;
                DDRAD &= ~0x80;
                PPSAD &= ~0x80; // use pull UP
                PERAD |= 0x80; // enable a pull
            }
        } else {
			if ((!(flash4.can_poll & 1)) || !(flash4.enable_poll & 0x08) || (flash4.ports_dir & 0x04) || (flash4.ports_dir & 0x40)) {
                conf_err = 7;
            }
		}
    }

    if ((flash10.N2Oopt & 0x04) && !(flash10.N2Oopt_pins & 0x08)) { //local inputs
        tmp_opt = flash10.N2Oopt_pins & 0x07;

        /* 0 PE0
           1 PE1
           2 JS10 PT5
           3 PA0
           4 AD6
           5 AD7
         */
        if (tmp_opt == 0) {
            if (pPTEpin[0] == &dummyReg) {
                conf_err = 7;
            } else {
                pPTEpin[0] = &dummyReg;
            }
        } else if (tmp_opt == 1) {
            if (pPTEpin[1] == &dummyReg) {
                conf_err = 7;
            } else {
                pPTEpin[1] = &dummyReg;
            }
        } else if (tmp_opt == 2) {
            if (pPTTpin[5] == &dummyReg) {
                conf_err = 7;
            } else {
                pPTTpin[5] = &dummyReg;
                DDRT &= ~0x20;
                pt5ip = 1;
                PERT |= 0x20;
                PPST &= ~0x20;
                //need to configure as input and disable interrupt
            }
        } else if (tmp_opt == 3) {
            if (pPTApin0 == &dummyReg) {
                conf_err = 7;
            } else {
                pPTApin0 = &dummyReg;
                DDRA &= ~0x01; /* configure as input. Pullup enabled later*/
            }
        } else if (tmp_opt == 4) {
            if (adctest & 0x40) {
                conf_err = 7;
            } else {
                adctest |= 0x40;
                ATD0DIEN |= 0x40;
                DDRAD &= ~0x40;
                PPSAD &= ~0x40; // use pull UP
                PERAD |= 0x40; // enable a pull
            }
        } else if (tmp_opt == 5) {
            if (adctest & 0x80) {
                conf_err = 7;
            } else {
                adctest |= 0x80;
                ATD0DIEN |= 0x80;
                DDRAD &= ~0x80;
                PPSAD &= ~0x80; // use pull UP
                PERAD |= 0x80; // enable a pull
            }
        }
    }

    // check for valid cylinder counts
    if ((num_cyl == 7) || (num_cyl == 9) || (num_cyl == 11) || (num_cyl > 13)) {
        conf_err = 8; // might work in fuel-only though
    }

//    if ((flash4.ICIgnOption & 0xa) == 0xa) {
//        conf_err = 9; // trigret and oddfire not allowed
//    }

    if (flash10.staged & 0x7) {
        if (!flash10.staged_pri_size || !flash10.staged_sec_size) {
            conf_err = 10;
        }

        if ((flash10.staged & 0x7) != 5) {
            if ((flash10.staged & 0x07) == ((flash10.staged & 0x38) >> 3)) {
                conf_err = 11;
            }

            if (flash10.staged_param_1 == 0) {
                conf_err = 12;
            }

            if ((flash10.staged & 0x38) && (!flash10.staged_param_2)) {
                conf_err = 13;
            }

            if ((flash10.staged & 0x40) && (!flash10.staged_transition_events)) {
                conf_err = 14;
            }
        }

        if (flash4.Alternate & 0x1) {
            conf_err = 15;
        }
        if ((flash4.dual_tble_optn & 1) && !(flash8.seq_inj & 0x04)) {
            conf_err = 26;
        }
        if ((flash8.seq_inj & 0x07) == 3) {
            conf_err = 42;
        }
    }

    if ((flash4.dual_tble_optn & 1) && ((flash4.FuelAlgorithm & 0xF0) ||
                (flash4.IgnAlgorithm & 0xF0))) {
        conf_err = 16;
    }

    if ((spkmode == 2) || (spkmode == 3)) {
        if (flash4.adv_offset < 0) {
            conf_err = 31;
        }
    } else if (spkmode != 4) {
        if ((flash4.adv_offset > 200) || (flash4.adv_offset < -200)) {
            conf_err = 46;
        }
    }

    // see if we can enable ignition trigger led without conflict
    if ((pPTMpin5 != &dummyReg) && (flash4.feature4_0 & 0x2) && (spkmode == 3) ) {
        pPTMpin5 = &dummyReg;
        flagbyte1 |= flagbyte1_igntrig;
    }

    // turn off fidle solenoid, leds
    *pPTMpin2 &= ~0x04;
    *pPTMpin3 &= ~0x08;
    *pPTMpin4 &= ~0x10;
    *pPTMpin5 &= ~0x20;
    *pPTTpin[6] &= ~0xC0;      // turn off IAC coils
    *port_iac1 &= ~pin_iac1;
    *port_iac2 &= ~pin_iac2;

    if ((IdleCtl == 3) && ((flash4.IACcurlim & 3) == 0)) {
        if (pol_iacen) {
            *port_iacen &= ~pin_iacen;  // inverted disable current to motor(set bit= 0)
            iac_dty = 0;
        } else {
            *port_iacen |= pin_iacen;   // disable current to motor (set bit= 1)
            iac_dty = 2;
        }
    } else {    //  IdleCtl = 3, 5 or no stepper motor (set bit = 0)
        if (pol_iacen) {
            *port_iacen |= pin_iacen;   // inverted enable current to motor always(set bit= 1)
            iac_dty = 2;
        } else {
            *port_iacen &= ~pin_iacen;  // enable current to motor always(set bit= 0)
            iac_dty = 0;
        }
    }

    // set all unused (even unbonded) ports to   with pullups
    DDRA &= 0x01;
    DDRB &= 0x10;
    DDRE &= 0x10;
    PUCR |= 0x13;    // enable pullups for ports E, B and A
    DDRJ &= 0x3F;
    PERJ |= 0xC0;    // enable pullup resistance for port J6,7
    DDRS &= 0xF3;
    PERS |= 0x0C;    // enable pullup resistance for port S2,3

    // set up CRG RTI Interrupt for .128 ms clock. CRG from 8MHz oscillator.
    mms = 0;        // .128 ms tics
    millisec = 0;   // 1.024 ms clock (8 tics) for adcs
    lmms = 0;
    cansendclk = 7812;
    ltch_lmms = 0;
    RTICTL = 0x10;   // load timeout register for .128 ms (smallest possible)
    CRGINT |= 0x80;  // enable interrupt
    CRGFLG = 0x80;   // clear interrupt flag (0 writes have no effect)
    COPCTL = 0x44; // Enable long C.O.P. timeout 2^20 ~0.125s

    sci_baud();
    SCI0CR1 = 0x00;
    SCI0CR2 = 0x24;   // TIE=0,RIE = 1; TE=0,RE =1
    txcnt = 0;
    rxmode = 0;
    txmode = 0;
    txgoal = 0;
    rcv_timeout = 0xFFFFFFFF;

    smallest_tooth_crk = 0;
    smallest_tooth_cam = 0;
    false_mask_crk = 0;
    false_mask_cam = 0;
    false_period_crk_tix = 0;
    false_period_cam_tix = 0;
    mapadc_thresh = 0;

    tooth_init = 0;
    ign_wheel_init();

/* From MS3 needs fully applying ROTARY
    if (((flash4.EngStroke & 0x03) == 0x03) && (cycle_deg == 7200)) {
        conf_err = 44;      // rotary doesn't need 720deg i.e. cam speed reset
    }

    if (((flash4.EngStroke & 0x03) == 0x03) && (num_cyl > 2) &&
        ((flash4.hardware & 0x7) != 0x2)) {
        conf_err = 122;
    }
*/
	if (no_triggers > NUM_TRIGS) {
		conf_err = 43;
	}

	if ((flash8.seq_inj & 0x03) == 1) {
		// Sequential/Semi-sequential
		// Check how many injectors would be needed ideally
		if (no_triggers > 4) {
			if (no_triggers == 5) {
				// 5 cyl: 5 triggers, 1 injector, 5 squirts
				no_inj = 1;
				no_squirts = 5;
			} else if (no_triggers == 10) {
				// 10 cyl: 10 triggers, 2 injectors, 5 squirts (not currently supported)
				no_inj = 2;
				no_squirts = 5;
			} else {
				// 6 cyl: 6 triggers, 3 injectors, 2 squirts
				// 8 cyl: 8 triggers, 4 injectors, 2 squirts (not currently supported)
				// 12 cyl: 6 triggers, 3 injectors, 2 squirts
				no_inj = no_triggers >> 1;
				no_squirts = 2;
			}
		} else {
			// 1 cyl: 1 trigger, 1 injector, 1 squirt
			// 2 cyl: 1 trigger, 1 injector, 1 squirt
			// 2 cyl: 2 triggers, 2 injectors, 1 squirt
			// 3 cyl: 3 triggers, 3 injectors, 1 squirt
			// 4 cyl: 2 triggers, 2 injectors, 1 squirt
			// 4 cyl: 4 triggers, 4 injectors, 1 squirt
			// 8 cyl: 4 triggers, 4 injectors, 1 squirt
			no_inj = no_triggers;
			no_squirts = 1;
		}

		// Check what needs to be changed with the real number of injectors
		if ((no_inj > 2) && !(flash8.seq_inj & 0x04)) {
			if (no_triggers == 6) {
				// 6 cyl: 6 triggers, 2 injectors, 3 squirts
				// 12 cyl: 6 triggers, 2 injectors, 3 squirts
				no_inj = 2;
				no_squirts = 3;
			} else {
				// 3 cyl: 3 triggers, 1 injectors, 3 squirts
				// 4 cyl: 4 triggers, 2 injectors, 2 squirts
				// 8 cyl: 4 triggers, 2 injectors, 2 squirts
				// 8 cyl: 8 triggers, 2 injectors, 4 squirts (not currently supported)
				no_inj >>= 1;
				no_squirts = no_triggers / no_inj;
			}
		}
		
		// Adjust number of injectors and squirts if staging activated
		if (flash10.staged & 0x07) {
			if (no_inj == 1) {
				// 1 cyl: 1 trigger, 2 injectors, 1 squirt
				// 2 cyl: 1 trigger, 2 injectors, 1 squirt
				// 3 cyl: 3 triggers, 2 injectors, 3 squirts
				// 5 cyl: 5 triggers, 2 injectors 5 squirts
				no_inj = 2;
			} else if (no_inj == 2){
				if (flash8.seq_inj & 0x04) {
					// 2 cyl: 2 triggers, 4 injectors, 1 squirt
					// 4 cyl: 2 triggers, 4 injectors, 1 squirt
					// 10 cyl: 5 triggers, 4 injectors, 5 squirts (not currently supported)
					no_inj = 4;
				} else {
					// 4 cyl: 4 triggers, 2 injectors, 4 squirts
					// 6 cyl: 6 triggers, 2 injectors, 6 squirts (not currently supported)
					// 8 cyl: 4 triggers, 2 injectors, 4 squirts
					// 8 cyl: 8 triggers, 2 injectors, 8 squirts (not currently supported)
					// 12 cyl: 6 triggers, 2 injectors, 6 squirts (not currenlty supported)
					no_squirts <<= 1;
				}
			} else if (no_inj == 3) {
				// 3 cyl: 3 triggers, 2 injectors, 3 squirts
				// 6 cyl: 6 triggers, 4 injectors, 3 squirts
				// 12 cyl: 6 triggers, 4 injectors, 3 squirts
				no_inj = no_triggers / 3;
				no_squirts = 3;
			} else {
				// 4 cyl: 4 triggers, 4 injectors, 2 squirt
				// 8 cyl: 8 triggers, 4 injectors, 4 squirts (not currently supported)
				no_squirts <<= 1;
			}
		}
		
		if ((no_inj > 4) || ((no_squirts > 3) && (no_inj > 2)) || (no_squirts > 5)) {
			conf_err = 44;
		}

		if (flash10.staged & 0x07) {
			// Keep only number of primary injectors
			no_inj >>= 1;
		}

        if (spkmode == 54) { // HD32-2
            no_squirts = 1; // force SEQ fuelling
        }

	} else if ((flash8.seq_inj & 0x03) == 3) {
		no_inj = 2;
	} else {
		no_inj = 1;
	}

#ifdef MICROSQUIRT
    if (no_inj >= 3) {
        if (pPTTpin[6] == &dummyReg) {
            conf_err = 45;
        } else {
            pPTTpin[6] = &dummyReg;
            DDRT |= 0x40;
        }
    }
    if (no_inj >= 4) {
        if (pPTTpin[7] == &dummyReg) {
            conf_err = 45;
        } else {
            pPTTpin[7] = &dummyReg;
            DDRT |= 0x80;
        }
    }
#else
    if (no_inj >= 3) {
        if (pPTTpin[2] == &dummyReg) {
            conf_err = 45;
        } else {
            pPTTpin[2] = &dummyReg;
            DDRT |= 0x04;
        }
    }
    if (no_inj >= 4) {
        if (pPTTpin[4] == &dummyReg) {
            conf_err = 45;
        } else {
            pPTTpin[4] = &dummyReg;
            DDRT |= 0x10;
        }
    }
#endif

    //  Initialize timers:
    // Megasquirt timer uses
    //   Note: Inj OC and PWM are Nanded.
    //    -when turn on inj1 i/o, also enable pwm1 @ 100 % duty &
    //      set pwm1 timer = 0 (.1 ms units).
    //    -When pwm1 timer = InjPWMTim, set duty cycle to InjPWMDty.
    //    -when done injecting, turn off inj1 i/o and pwm1.
    //   TC0: Input capture (tach) - no pullup (default) for MSII
    //   TC1: Output compare for injector output and timing - bank 1
    //   TC2: PWM2 for injector bank 1 / Rotary dwell timer / Output compare for injector output and timing - bank 3
    //   TC3: Output compare for injector output and timing - bank 2
    //   TC4: PWM4 for injector bank 2 / Rotary Spark / Output compare for injector output and timing - bank 4
    //   TC5: Output compare for EDIS output / 2nd trigger input
    //   TC6: Dwell timer
    //   TC7: Timer for bit bash spark output

    // Microquirt timer uses
    //   No PWM used.
    //   TC0: Input capture (tach) - no pullup (default) for MSII
    //   TC1: Output compare for injector output - bank 1
    //   TC2: 2nd trigger input
    //   TC3: Output compare for injector output - bank 2
    //   TC4: Dwell timer  / pin used for bit bashed spark B
    //   TC5: Output compare for EDIS output / spark timer / pin used for bit bashed spark A
    //   TC6: Rotary dwell timer / Output compare for injector output and timing - bank 3
    //   TC7: Rotary Spark / Output compare for injector output and timing - bank 4

    //SPK,CHG only used by EDIS. Want to get rid of them
    if (flash4.ICIgnOption & 0x10) {
        SPK = 0;
    } else {
        SPK = 1;
    }                               // 0=spk low, but inverted logic
    CHG = 1 - SPK;                  // after transistor
    TIOS |= 0xFE; // Timer ch 0 = IC, ch 1-5 = OC & PWM,
    // ch 6,7 = I/O output
    // Set prescaler to 16. This divides bus clk (= PLLCLK/2 = 24 MHz)
    //   by 16. This gives 1.5 MHz timer, 1 tic = 2/3 us.
    TSCR2 = 0x84;    // setup timer, enable overflow int
	if (seq_inj_ctrl & SEQ_STD_INJ) {
	    TCTL2 |= 0x88;   // bit OM1,3 = 1. OC output line high or
	    // low iaw OL1,3 (not toggle or disable)
	    // Only set up for OC directly controlling output pin when not in wasted spk
	    // mode.
	} else {
#ifndef MICROSQUIRT
	    TCTL2 |= 0xA8;   // bit OM1,2,3 = 1. OC output line high or
	    TCTL1 |= 0x02;   // bit OM4 = 1. OC output line high or
	    // low iaw OL1,2,3,4 (not toggle or disable)
	    // Only set up for OC directly controlling output pin when not in wasted spk
	    // mode.
#else
	    TCTL2 |= 0x88;   // bit OM1,3 = 1. OC output line high or
	    TCTL1 |= 0xA0;   // bit OM6,7 = 1. OC output line high or
	    // low iaw OL1,3,6,7 (not toggle or disable)
	    // Only set up for OC directly controlling output pin when not in wasted spk
	    // mode.
#endif
	}

    flagbyte5 &= ~(FLAGBYTE5_CAM_NOISE | FLAGBYTE5_CAM_POLARITY | FLAGBYTE5_CAM_BOTH | FLAGBYTE5_CRK_BOTH); // ensure all off to start

    if (flagbyte5 & FLAGBYTE5_CAM) {
        if ((flagbyte5 & FLAGBYTE5_CAM_DOUBLE) == 0) { // disabled if double (presently only rising and falling)
            if (flash4.secondtrigopts & 0x01) { // noise filter
                flagbyte5 |= FLAGBYTE5_CAM_BOTH;
                flagbyte5 |= FLAGBYTE5_CAM_NOISE;
            } else /*if (flash4.secondtrigopts & 0x08)*/ { //cam polarity check now always on if possible
                flagbyte5 |= FLAGBYTE5_CAM_POLARITY;
            }
        } else {
            flagbyte5 |= FLAGBYTE5_CAM_BOTH;
        }
#ifndef MICROSQUIRT
        TCTL1 &= 0xf3; // not OC
        DDRT &= ~TFLG_trig2; // ensure PTT5 = input (already done above)
#else
        TCTL2 &= 0xcf; // not OC
#endif
        TIOS &= ~TFLG_trig2; // set as input capture
        TIE |= TFLG_trig2; //enable IC interrupts
#ifndef MICROSQUIRT
    } else if (pt5ip == 0) { // only if not an input
        DDRT |= TFLG_trig2; // set PTT5 as output
#endif
    }

    if (spkmode < 2) { // EDIS only
        TCTL1 |= 0x08;
        TCTL1 = (TCTL1 & 0xFB) | (SPK << 2);  // set OC o/p in OL5
        CFORC |= 0x20;           // force output in OL5 onto OC pin
        IgnOCpinstate = SPK;
    } else if ((spkmode == 4) && (flash4.spk_config & 0x08)) { // trigger wheel and 2nd trig, set active IC edges
        unsigned char ctmp;
        ctmp = flash4.spk_config & 0x30;
        if (ctmp & 0x10) {
            flagbyte4 |= FLAGBYTE4_CAMPOL;
        }
#ifndef MICROSQUIRT
        ctmp = ctmp >>2;
        if (flagbyte5 & FLAGBYTE5_CAM_NOISE) {
            ctmp = 0xc;
        }
        TCTL3 = (TCTL3 & 0xf3) | ctmp;
#else
        if (flagbyte5 & FLAGBYTE5_CAM_NOISE) {
            ctmp = 0x30;
        }
        TCTL4 = (TCTL4 & 0xcf) | ctmp;
#endif
    } else if ( flagbyte5 & FLAGBYTE5_CAM ) { // other modes that use the cam
        unsigned char pol;
        if (spkmode == 14) {
            flagbyte2 |= flagbyte2_twintrig; // set this quick flag
        }
        pol = flash4.ICIgnOption & 0x01;
        if (flash4.spk_mode3 & 0x04) {
            pol ^= 0x01;
        }
        if (pol) {
            flagbyte4 |= FLAGBYTE4_CAMPOL;
        }
#ifndef MICROSQUIRT
        TCTL3 = TCTL3 & 0xf3;
        if (flagbyte5 & FLAGBYTE5_CAM_BOTH) {
            TCTL3 |= 0x0c;
        } else {
            if (pol) { // 2nd is same polarity as primary trigger input
                TCTL3 |= 0x04;
            } else {
                TCTL3 |= 0x08;
            }
        }
#else
        TCTL4 = TCTL4 & 0xcf;
        if (flagbyte5 & FLAGBYTE5_CAM_BOTH) {
            TCTL4 |= 0x30;
        } else {
            if (pol) { // 2nd is same polarity as primary trigger input
                TCTL4 |= 0x10;
            } else {
                TCTL4 |= 0x20;
            }
        }
#endif
    } else { // not using cam
#ifndef MICROSQUIRT
        TCTL3 &= 0xf3; //TC5 disconnected from IC logic
#else
        TCTL4 &= 0xcf; //TC2 disconnected from IC logic
#endif
    }

    // the single/double edge trigger flags are set in ign_wheel based on the mode

    // Presently, if the wheel already uses both edges, then we cannot enable the noise filter

    if ( flagbyte5 & FLAGBYTE5_CRK_DOUBLE ) { // crank is double edge triggered
        flagbyte1 &= ~flagbyte1_noisefilter;  // disable noise filter
        flagbyte5 |= FLAGBYTE5_CRK_BOTH;
        TCTL4 |= 0x03;
    } else if (flash4.NoiseFilterOpts & 0x01) {
        flagbyte1 |= flagbyte1_noisefilter; // permit noise filter
        flagbyte5 |= FLAGBYTE5_CRK_BOTH;
        TCTL4 |= 0x03;
    } else {
        flagbyte1 &= ~flagbyte1_noisefilter; // disable noise filter
        TCTL4 &= ~0x03;
        if (flash4.ICIgnOption & 0x01) {
            TCTL4 |= 0x01;
        } else {
            TCTL4 |= 0x02;
        }
        flagbyte1 |= flagbyte1_polarity; // always do polarity check if possible
    }

    OC7M = 0; // don't want to use OC7 feature
#ifndef MICROSQUIRT
	if (seq_inj_ctrl & SEQ_STD_INJ) {
	    // Set up injector PWMs - PWM2, 4
	    MODRR = 0x14;     // Make Port T pins 2,4 be PWM
	    PWME = 0;         // disable pwms initially
	    PWMPOL = 0x14;    // polarity = 1, => go hi when start
	    PWMCLK = 0x14;    // select scaled clocks SB, SA
	    PWMPRCLK = 0x00;  // prescale A,B clocks = bus = 24 MHz
	    PWMSCLA = 0x0C;   // pwm clk = SA clk/(2*SCLA) = 24MHz/24 = 1 us clk
	    PWMSCLB = 0x0C;   // pwm clk = SB clk/(2*SCLB) = 24MHz/24 = 1 us clk
	    PWMCAE = 0x00;    // standard left align pulse: -----
	    //                           |     |______
	    //                             duty
	    //                           <---period--->
	    PWMPER2 = flash4.InjPWMPd;   // set PWM period (us)
	    if (flash4.ICIgnOption & 0x20) {
	        PWMPER4 = flash4.InjPWMPd2;   // set PWM period (us)
	    } else {
	        PWMPER4 = flash4.InjPWMPd;   // set PWM period (us)
	    }
	}
#endif
    ign_reset();

    flagbyte4 |= flagbyte4_first_edis;

    IAC_moving = 0;
    motor_step = -1;
    pwmidle_reset = PWMIDLE_RESET_INIT;

    if ((IdleCtl == 2) || (IdleCtl == 3) ||	(IdleCtl == 5) || (IdleCtl == 7) || (IdleCtl == 8)) {
        if (flash4.IdleCtl & 0x20) { // home open
            outpc.iacstep = flash4.iacfullopen - flash4.IACStart;  // set current motor step position (should be negative)
            IACmotor_pos = flash4.iacfullopen; // target position
        } else {
            outpc.iacstep = flash4.IACStart;      // set current motor step position
            IACmotor_pos = 0; // target position
        }
        (void)move_IACmotor();
    }

    last_iacclt = -3200;

    // set up ADC processing
    // ATD0
    //    - AN0 is MAP
    //    - AN1 is MAT
    //    - AN2 is CLT
    //    - AN3 is TPS
    //    - AN4 is BAT
    //    - AN5 is EGO1 (NB or WB)
    //    - AN6 is Spare or BARO or KNOCK or spark(BaroOption =2) or EGO2 (EgoOption = 2 or 4)
    //    - AN7 is Spare or KNOCK or spark
    // Set up ADCs so they continuously convert, then read result registers
    //  every millisecond
    next_adc = 0;	   	// specifies next adc channel to be read
    ATD0CTL2 = 0x40;  // leave interrupt disabled, set fast flag clear
    ATD0CTL3 = 0x00;  // do 8 conversions/ sequence
    ATD0CTL4 = 0x65;  // 10-bit resoln, 16 tic cnvsn (max accuracy),
    // prescaler divide by 18 => 0.6us tic x 18 tics. (So complete sequence < 0.128ms)
    ATD0CTL5 = 0xB0;  // right justified,unsigned, continuous conversion,
    // sample 8 channels starting with AN0
    ATD0CTL2 |= 0x80;  // turn on ADC0
    // wait for ADC engine charge-up or P/S ramp-up
    for(ix = 0; ix < 160; ix++)  {
        while(!(ATD0STAT0 >> 7));	 // wait til conversion complete
        ATD0STAT0 = 0x80;
    }

    // get all adc values
    first_adc = 1;
    get_adc(0,7);
    first_adc = 0;
    if(flash4.BaroOption < 2) {
        if ((flash4.BaroOption == 1) && (outpc.map < flash4.baro_upper) && (outpc.map > flash4.baro_lower)) {
            outpc.baro = outpc.map;    // If within range use the initial sensor value
        } else {
            if ((flash4.baro_default > 600) && (flash4.baro_default < 1050)) { // hardcoded limits
                outpc.baro = flash4.baro_default;    // Use entered value if it seems sensible kPa x 10
            } else {
                outpc.baro = 1000;         // failsafe 100 kPa
            }
        }
    }
    adc_lmms = lmms;
    // Initialize variables
    /* outpc and datax1 zeroed earlier */
    flocker = 0;
    pwcalc1 = 0;    // us
	req_pw1 = 0;
    pwcalc2 = 0;    // us
	req_pw2 = 0;
	pwcalc3 = 0;
	req_pw3 = 0;
	pwcalc4 = 0;
	req_pw4 = 0;
    inj1_count = 0;
    inj2_count = 0;
    inj3_count = 0;
    inj4_count = 0;
    coil_dur = flash4.crank_dwell;   // msx10
    coil_dur_set = coil_dur * 100;    // us
    outpc.coil_dur = (int)(coil_dur_set / 100);   // msx10
    PulseTol = flash4.CrnkTol;
    outpc.fuelload = 1000;  // kPa x 10
    outpc.ignload = 1000;
//    last_tps = outpc.tps; // % x 10
    last_map = outpc.map;       // kPa x 10
    outpc.afrtgt1 = 147;  // afr x 10
    outpc.afrtgt2 = outpc.afrtgt1;
    outpc.aircor = 100;
    outpc.vecurr1 = 100;
    outpc.vecurr2 = outpc.vecurr1;
    outpc.barocor = 100;
    outpc.warmcor = 100;
    outpc.wbo2_en1 = 1;
    outpc.wbo2_en2 = 1;
    outpc.egocor1 = 1000;
    outpc.egocor2 = 1000;
    outpc.tpsfuelcut = 100;
    outpc.gammae = 100;
    outpc.tpsaccel = 0;
    tcrank_done = 0xFFFF;
    FSensStat = 0;
    FSens_Pd = 0;
    FPdcounter = 0;
    FPdcounter2 = 0;
    flex_count = 0;
    flex_accum = 0;
    last_fsensdat = 0;
    eth_pct_accum = 100 << 4; /* seed with 10% as typical value */
    outpc.fuelcor = 100;        // %
    outpc.flex_advance = 0;               // degx10
    outpc.fuelcor = 100;    // %
    bad_ego_flag = 0;
    idle_advance_timer = 0;
    if (flash4.EAEOption) {
        WF1 = 0;
        WF2 = 0;
        AWA1 = 0;
        AWA2 = 0;
        SOA1 = 0;
        SOA2 = 0;
    }

    if (flash4.EAEOption == 3) {
        set_EAE_lagcomp();
        injtime_EAElagcomp = 0;
    }
    TC_ovflow = 0;

    injtime = 0;
    inj1cntdown = 0;
    inj2cntdown = 0;
	seq_inj_ctrl &= ~SEQ_HYBRID;	// Hybrid mode is off (dual pulses) // not needed since already set to 0
	hybrid_rpm = flash8.hybrid_rpm;
	hybrid_hyst = flash8.hybrid_hyst;

    stack_watch_init();

    /* Initialize CAN comms */
    // can_reset flag set above when flagbyte3 cleared
	CANid = flash4.mycan_id;
    CanInit();
    for (ix = 0 ; ix < 15 ; ix++) {
        can_err_cnt[ix] = 0;
    }

    // make IC highest priority interrupt
    HPRIO = 0xEE;

    // enable global interrupts
    ENABLE_INTERRUPTS;

    if (MONVER >= 0x210) {
        /* Updated monitor version, can perform checking */

#if 1 /* normally 1 */
#ifdef MSPNP2
        if ((MONVER < 0x250) || (MONVER > 0x25f)) {
            conf_err = 68;
            goto SKIP_INIT;
        }
#elif defined(MICROSQUIRTMODULE)
        if ((MONVER < 0x230) || (MONVER > 0x23f)) {
            conf_err = 68;
            goto SKIP_INIT;
        }
#elif defined(MICROSQUIRT)
        if ((MONVER < 0x210) || (MONVER > 0x21f)) {
            conf_err = 68;
            goto SKIP_INIT;
        }
#else // MS2
        if ((MONVER < 0x220) || (MONVER > 0x22f)) {
            conf_err = 68;
            goto SKIP_INIT;
        }
#endif
#else
        if (MONVER == 999) { /* dummy */
            goto SKIP_INIT;
        }
#endif
    }

    // Prime Pulse - shoot 1 prime pulse of length PrimeP ms x 10
    set_prime_ASE();

    if (flash5.boost_ctl_settings & BOOST_CTL_ON) {
        boost_ctl_init();
    }

    if ((IdleCtl == 4) || (IdleCtl == 6)) {
        idle_ctl_init();
    }

    ego_init();

    if (PrimeP) {
        // Turn on fuel pump
        PORTE |= 0x10;
    }
    /* Actual priming called from mainloop to allow delay */        

    stall_timeout = 18750/num_cyl; // calculate stall timeout once
    fc_counter = 0xff;
    adc_ctr = 0;
    lowres = 0;
    lowres_ctr = 0;
    tacho_targ = 0;
    spkcut_thresh = 0;

    if (flash10.staged & 0x7) {
        setup_staging();
    }
    if ( (spkmode == 2) && (flash4.spk_conf2 & 0x2)
            && ((flash4.dwellmode & 3) == 1) ) {
        // if basic trigger, TFI, fixed duty then must be push start (not actually used!)
        flagbyte2 |= flagbyte2_tfi_ps;
    }

    wheeldec_ovflo = 0;
    bl_timer = 0;
    n2o_act_timer = 0;
    n2o2_act_timer = 0;
    fc_off_time = 0xfe;

    if (flash4.RevLimOption & 0x8) {
        RevLimRpm2 = flash4.RevLimNormal2;
        RevLimRpm1 = flash4.RevLimNormal2 - flash4.RevLimNormal2_hyst;
    } else {
        RevLimRpm1 = flash4.RevLimTPSbypassRPM - flash4.RevLimNormal2_hyst;
        RevLimRpm2 = flash4.RevLimTPSbypassRPM;
    }

// check spare ports are set
    for(ix = 0;ix < NPORT; ix++)  {
        if(flash4.spr_port[ix])  {
            set_spr_port((char)ix, flash4.init_val[ix]);
        }
    }

	// Initialize the remote PWM parameters
	if (flash4.FlexFuel & 0x09) { // on and CANPWMIN 
		long tmp_freq;
		// Flexfuel is enabled and using a remote port
		tmp_freq = (long)flash4.remotePWMfreq * 1000000L / flash4.remotePWMprescale;
		remotePWMscale = 0;
		while (tmp_freq > 65535) {
			tmp_freq >>= 1;
			remotePWMscale++;
		}
		remotePWMfreq = (int)tmp_freq;
		outpc.gpiopwmin[(flash4.FlexFuel & 0x06) >>1] = 0;
	}

    // Shifter
/*
#0      shift_cut_in = bits,   U08, 503,[0:3], "PE0/JS7", "PE1", "JS10", "JS11", "JS5", "JS4", "INVALID" "INVALID", "Remote Port3 Bit 0", "Remote Port3 Bit 1", "Remote Port3 Bit 2", "Remote Port3 Bit 3", "Remote Port3 Bit 4", "Remote Port3 Bit 5", "Remote Port3 Bit 6", "Remote Port3 Bit 7"
#1      shift_cut_in = bits,   U08, 503,[0:3], "Flex", "INVALID", "INVALID", "INVALID", "SpareADC", "INVALID", "INVALID" "INVALID", "Remote Port3 Bit 0", "Remote Port3 Bit 1", "Remote Port3 Bit 2", "Remote Port3 Bit 3", "Remote Port3 Bit 4", "Remote Port3 Bit 5", "Remote Port3 Bit 6", "Remote Port3 Bit 7"
#2      shift_cut_in = bits,   U08, 503,[0:3], "Flex", "PE1", "INVALID", "PA0", "SpareADC", "SPAREADC2", "INVALID" "INVALID", "Remote Port3 Bit 0", "Remote Port3 Bit 1", "Remote Port3 Bit 2", "Remote Port3 Bit 3", "Remote Port3 Bit 4", "Remote Port3 Bit 5", "Remote Port3 Bit 6", "Remote Port3 Bit 7"
*/
    port_shift_cut_in = &dummyReg;
    pin_shift_cut_in = 0;
    pin_shift_cut_match = 0xff;
    port_shift_cut_out = (volatile unsigned char *) &dummyReg;
    pin_shift_cut_out = 0;

    if (flash12.shift_cut_on & 0x01) {
        pin_shift_cut_match = 0;
        tmp_opt = flash12.shift_cut_in & 0x0f;
        if (tmp_opt == 0) {
            if (pPTEpin[0] == &dummyReg) {
                conf_err = 81;
            } else {
                pPTEpin[0] = &dummyReg;
                port_shift_cut_in = &PORTE;
                pin_shift_cut_in = 1;
            }
        } else if (tmp_opt == 1) {
            if (pPTEpin[1] == &dummyReg) {
                conf_err = 81;
            } else {
                pPTEpin[1] = &dummyReg;
                port_shift_cut_in = &PORTE;
                pin_shift_cut_in = 2;
            }
        } else if (tmp_opt == 2) {
            if (pPTTpin[5] == &dummyReg) {
                conf_err = 81;
            } else {
                pPTTpin[5] = &dummyReg;
                port_shift_cut_in = &PORTT;
                pin_shift_cut_in = 0x20;
                DDRT &= 0x20;
            }
        } else if (tmp_opt == 3) {
            if (pPTApin0 == &dummyReg) {
                conf_err = 81;
            } else {
                pPTApin0 = &dummyReg;
                DDRA &= ~0x01;
                PUCR |= 0x01; // pullup enable
                port_shift_cut_in = &PORTA;
                pin_shift_cut_in = 1;
            }
        } else if (tmp_opt == 4) {
            if (adctest & 0x40) {
                conf_err = 81;
            } else {
                adctest |= 0x40;
                ATD0DIEN |= 0x40;
                DDRAD &= ~0x40;
                PPSAD &= ~0x40; // use pull UP
                PERAD |= 0x40; // enable a pull
                port_shift_cut_in = &PTAD;
                pin_shift_cut_in = 0x40;
            }
        } else if (tmp_opt == 5) {
            if (adctest & 0x80) {
                conf_err = 81;
            } else {
                adctest |= 0x80;
                ATD0DIEN |= 0x80;
                DDRAD &= ~0x80;
                PPSAD &= ~0x80; // use pull UP
                PERAD |= 0x80; // enable a pull
                port_shift_cut_in = &PTAD;
                pin_shift_cut_in = 0x80;
            }

        } else if (tmp_opt >= 8) {
            port_shift_cut_in = &outpc.gpioport[2];
            pin_shift_cut_in = 1 << (tmp_opt - 8);
        } else {
            /* do nothing */
        }
        shift_cut_phase = 0;

/*
#0      shift_cut_out     = bits,     U08,     504, [0:3], "IGN (JS10)", "IAC1", "IAC2", "JS11", "FIDLE", "D14", "D16", "D15", "AD06/JS5", "AD07/JS4", "INVALID", "INVALID", "INVALID", "INVALID", "INVALID", "Off"
#1      shift_cut_out     = bits,     U08,     504, [0:3], "IGN", "INVALID", "INVALID", "INVALID", "FIDLE", "TACHOUT", "ALED", "WLED", "INVALID", "INVALID", "INVALID", "INVALID", "INVALID", "INVALID", "INVALID", "Off"
#2      shift_cut_out     = bits,     U08,     504, [0:3], "IGN", "PT7", "PT6", "PA0", "FIDLE", "TACHOUT", "ALED", "WLED", "INVALID", "INVALID", "INVALID", "INVALID", "INVALID", "INVALID", "INVALID", "Off"
*/

        // now check for solenoid output
        tmp_opt = (flash12.shift_cut_out & 0x0f);
        if (tmp_opt == 0) {
            if (pPTTpin[5] == &dummyReg) {
                conf_err = 82;
            } else {
                pPTTpin[5] = &dummyReg;
                port_shift_cut_out = &PORTT;
                pin_shift_cut_out = 0x20;
                DDRT |= 0x20;
            }
        } else if (tmp_opt == 1) {
            if (pPTTpin[7] == &dummyReg) {
                conf_err = 82;
            } else {
                pPTTpin[7] = &dummyReg;
                port_shift_cut_out = &PORTT;
                pin_shift_cut_out = 0x80;
                DDRT |= 0x80;
            }
        } else if (tmp_opt == 2) {
            if (pPTTpin[6] == &dummyReg) {
                conf_err = 82;
            } else {
                pPTTpin[6] = &dummyReg;
                port_shift_cut_out = &PORTT;
                pin_shift_cut_out = 0x40;
                DDRT |= 0x40;
            }
        } else if (tmp_opt == 3) {
            if (pPTApin0 == &dummyReg) {
                conf_err = 82;
            } else {
                pPTApin0 = &dummyReg;
                port_ac_out = &PORTA;
                port_shift_cut_out = &PORTA;
                pin_shift_cut_out = 0x01;
                DDRA |= 0x01;
            }
        } else if (tmp_opt == 4) {
            if (pPTMpin2 == &dummyReg) {
                conf_err = 82;
            } else {
                pPTMpin2 = &dummyReg;
                port_shift_cut_out = &PORTM;
                pin_shift_cut_out = 0x04;
                DDRM |= 0x04;
            }
        } else if (tmp_opt == 5) {
            if (pPTMpin3 == &dummyReg) {
                conf_err = 82;
            } else {
                pPTMpin3 = &dummyReg;
                port_shift_cut_out = &PORTM;
                pin_shift_cut_out = 0x08;
                DDRM |= 0x08;
            }
        } else if (tmp_opt == 6) {
            if (pPTMpin4 == &dummyReg) {
                conf_err = 82;
            } else {
                pPTMpin4 = &dummyReg;
                port_shift_cut_out = &PORTM;
                pin_shift_cut_out = 0x10;
                DDRM |= 0x10;
            }
        } else if (tmp_opt == 7) {
            if (pPTMpin5 == &dummyReg) {
                conf_err = 82;
            } else {
                pPTMpin5 = &dummyReg;
                port_shift_cut_out = &PORTM;
                pin_shift_cut_out = 0x20;
                DDRM |= 0x20;
            }
        } else if (tmp_opt == 8) {
            if (adctest & 0x40) {
                conf_err = 82;
            } else {
                port_shift_cut_out = &PTAD;
                pin_shift_cut_out = 0x40;
                DDRAD |= 0x40; // enable pin AD06 as digital output
                adctest |= 0x40;
            }
        } else if (tmp_opt == 9) {
            if (adctest & 0x80) {
                conf_err = 82;
            } else {
                port_shift_cut_out = &PTAD;
                pin_shift_cut_out = 0x80;
                DDRAD |= 0x80; // enable pin AD07 as digital output
                adctest |= 0x80;
            }
        } else {
            /* no action */
        }

    }

    /* A/C idle-up */
    /* Note, only partial config error checking here. */
    if (flash12.idle_up_options & IDLE_UP_OPTIONS_ON) {
        pin_match_ac_in = 0;
        tmp_opt = flash12.idle_up_options & 0x0f;
        if (tmp_opt == 0) {
            port_ac_in = &PORTE;
            pin_ac_in = 1;
            if (pPTEpin[0] == &dummyReg) {
                conf_err = 59;
            } else {
                // PE0 always input with pullup
                pPTEpin[0] = &dummyReg;
            }
        } else if (tmp_opt == 1) {
            port_ac_in = &PORTE;
            pin_ac_in = 2;
            if (pPTEpin[1] == &dummyReg) {
                conf_err = 59;
            } else {
                // PE1 always input with pullup
                pPTEpin[1] = &dummyReg;
            }
        } else if (tmp_opt == 2) {
            port_ac_in = &PORTT;
            pin_ac_in = 0x20;
            DDRT &= 0x20;
        } else if (tmp_opt == 3) {
            port_ac_in = &PORTA;
            pin_ac_in = 1;
            DDRA &= ~0x01;
            if (pPTApin0 == &dummyReg) {
                conf_err = 59;
            } else {
                DDRA &= 0xfe;    // port A0 - input
                PUCR |= 0x01; // pullup enable
                pPTApin0 = &dummyReg;
            }
        } else if (tmp_opt == 4) {
            if (adctest & 0x40) {
                conf_err = 59;
            } else {
                adctest |= 0x40;
                ATD0DIEN |= 0x40;
                DDRAD &= ~0x40;
                PPSAD &= ~0x40; // use pull UP
                PERAD |= 0x40; // enable a pull
            }
            port_ac_in = &PTAD;
            pin_ac_in = 0x40;
        } else if (tmp_opt == 5) {
            if (adctest & 0x80) {
                conf_err = 59;
            } else {
                adctest |= 0x80;
                ATD0DIEN |= 0x80;
                DDRAD &= ~0x80;
                PPSAD &= ~0x80; // use pull UP
                PERAD |= 0x80; // enable a pull
            }
            port_ac_in = &PTAD;
            pin_ac_in = 0x80;
        } else if (tmp_opt >= 8) {
            port_ac_in = &outpc.gpioport[2];
            pin_ac_in = 1 << (tmp_opt - 8);
        } else {
            port_ac_in = &dummyReg;
            pin_ac_in = 0;
            pin_match_ac_in = 0xff;
        }

        if ((pin_ac_in) && (flash12.idle_up_options & IDLE_UP_OPTIONS_INV)) { // active high
            pin_match_ac_in = pin_ac_in;
        }

        // now check for control output
        tmp_opt = (flash12.ac_idleup_io_out & 0x1f);
        if (tmp_opt == 0) {
            if (pPTTpin[5] == &dummyReg) {
                conf_err = 73;
            } else {
                port_ac_out = &PORTT;
                pin_ac_out = 0x20;
                DDRT |= 0x20;
                pPTTpin[5] = &dummyReg;
            }
        } else if (tmp_opt == 1) {
            if (pPTTpin[7] == &dummyReg) {
                conf_err = 73;
            } else {
                port_ac_out = &PORTT;
                pin_ac_out = 0x80;
                DDRT |= 0x80;
                pPTTpin[7] = &dummyReg;
            }
        } else if (tmp_opt == 2) {
            if (pPTTpin[6] == &dummyReg) {
                conf_err = 73;
            } else {
                port_ac_out = &PORTT;
                pin_ac_out = 0x40;
                DDRT |= 0x40;
                pPTTpin[6] = &dummyReg;
            }
        } else if (tmp_opt == 3) {
            if (pPTApin0 == &dummyReg) {
                conf_err = 73;
            } else {
                port_ac_out = &PORTA;
                pin_ac_out = 0x01;
                DDRA |= 0x01;
                pPTApin0 = &dummyReg;
            }
        } else if (tmp_opt == 4) {
            if (pPTMpin2 == &dummyReg) {
                conf_err = 73;
            } else {
                port_ac_out = &PORTM;
                pin_ac_out = 0x04;
                DDRM |= 0x04;
                pPTMpin2 = &dummyReg;
            }
        } else if (tmp_opt == 5) {
            if (pPTMpin3 == &dummyReg) {
                conf_err = 73;
            } else {
                port_ac_out = &PORTM;
                pin_ac_out = 0x08;
                DDRM |= 0x08;
                pPTMpin3 = &dummyReg;
            }
        } else if (tmp_opt == 6) {
            if (pPTMpin4 == &dummyReg) {
                conf_err = 73;
            } else {
                port_ac_out = &PORTM;
                pin_ac_out = 0x10;
                DDRM |= 0x10;
                pPTMpin4 = &dummyReg;
            }
        } else if (tmp_opt == 7) {
            if (pPTMpin5 == &dummyReg) {
                conf_err = 73;
            } else {
                port_ac_out = &PORTM;
                pin_ac_out = 0x20;
                DDRM |= 0x20;
                pPTMpin5 = &dummyReg;
            }
        } else if (tmp_opt == 8) {
            if (adctest & 0x40) {
                conf_err = 73;
            } else {
                port_ac_out = &PTAD;
                pin_ac_out = 0x40;
                DDRAD |= 0x40; // enable pin AD06 as digital output
                adctest |= 0x40;
            }
        } else if (tmp_opt == 9) {
            if (adctest & 0x80) {
                conf_err = 73;
            } else {
                port_ac_out = &PTAD;
                pin_ac_out = 0x80;
                DDRAD |= 0x80; // enable pin AD07 as digital output
                adctest |= 0x80;
            }
        } else if ((tmp_opt >= 16) && (tmp_opt < 24)) {
            port_ac_out = &outpc.gpioport[0];
            pin_ac_out = 1 << (tmp_opt - 16);
        } else {
            port_ac_out = (volatile unsigned char *) &dummyReg;
            pin_ac_out = 0;
        }
        /* Make sure the output pin is off, wouldn't want AC on while cranking */
        *port_ac_out &= ~pin_ac_out;
    } else {
        port_ac_out = &dummyReg;
        pin_ac_out = 0;
        port_ac_in = &dummyReg;
        pin_ac_in = 0;
        pin_match_ac_in = 0xff;
    }

    /* Fuel metering pulse output. */
    if ((flash5.injpw_pins & 0x0f) == 1) {
        if (pPTTpin[7] == &dummyReg) {
            conf_err = 65;
        } else {
            pPTTpin[7] = &dummyReg;
            port_injpw = pPTT;
            pin_injpw = 0x80;
            DDRT |= 0x80;
        }
    } else if ((flash5.injpw_pins & 0x0f) == 2) {
        if (pPTTpin[6] == &dummyReg) {
            conf_err = 65;
        } else {
            pPTTpin[6] = &dummyReg;
            port_injpw = pPTT;
            pin_injpw = 0x40;
        }
    } else if ((flash5.injpw_pins & 0x0f) == 4) {
        if (pPTApin0 == &dummyReg) {
            conf_err = 65;
        } else {
            pPTApin0 = &dummyReg;
            port_injpw = pPORTA;
            pin_injpw = 0x01;
        }
    } else if ((flash5.injpw_pins & 0x0f) == 8) {
        if (pPTMpin2 == &dummyReg) {
            conf_err = 65;
        } else {
            pPTMpin2 = &dummyReg;
            port_injpw = pPTM;
            pin_injpw = 0x04;
        }
    } else if ((flash5.injpw_pins & 0x0f) == 9) {
        if (pPTMpin3 == &dummyReg) {
            conf_err = 65;
        } else {
            pPTMpin3 = &dummyReg;
            port_injpw = pPTM;
            pin_injpw = 0x08;
        }
    } else if ((flash5.injpw_pins & 0x0f) == 10) {
        if (pPTMpin4 == &dummyReg) {
            conf_err = 65;
        } else {
            pPTMpin4 = &dummyReg;
            port_injpw = pPTM;
            pin_injpw = 0x10;
        }
    } else if ((flash5.injpw_pins & 0x0f) == 11) {
        if (pPTMpin5 == &dummyReg) {
            conf_err = 65;
        } else {
            pPTMpin5 = &dummyReg;
            port_injpw = pPTM;
            pin_injpw = 0x20;
        }
    } else {
        port_injpw = &dummyReg;
    	pin_injpw = 0;
    }
    injpw_accum = 0;
    injpw_timer = 0;

    map_temps[0] = 0xffff;
    map_temps[1] = 0xffff;
    map_temps[2] = 0xffff;
    map_temps[3] = 0xffff;
    map_temps_cnt = 0;
    mapsample_time = 0;
    tpssample_time = 0;
    datax1.FuelAdj = 0;
    datax1.SpkAdj = 0;
    datax1.IdleAdj = 0;
    datax1.SprAdj = 0;
    idleadj_last = 0;

    map_deadman = 0;
    can_bcast_last = 0;
    tps_ring_cnt = 0;
    srl_err_cnt = 0;
    maplog_cnt = 0;
    maplog_max = 1;
    testmode_glob = 0;
    iactest_glob = 0;
    maxdwl = 255;

    /* Now config error completed, re-enable the ports. */
    if ((IdleCtl == 2) || (IdleCtl == 3) || (IdleCtl == 5) || (IdleCtl == 7) || (IdleCtl == 8)) {
        pPTTpin[6] = pPTT;
        pPTTpin[7] = pPTT;
    } else if ((IdleCtl == 1)
            || (((IdleCtl == 4) || (IdleCtl == 6)) && ((flash5.pwmidle_port & 0x03) == 0))) {
        pPTMpin2 = pPTM;
    }

#ifdef USER_DEF_ON
/* 'user defined'                                                           *  
 * Here are some variables defined to help the new programmer get started   *
 * search for 'user defined' in ms2_extra_main.c for more notes             *
 *                                                                          *
 * Initialisation                                                           */
user_ulong = 0;
user_uint = 0;
user_uchar = 0;
/* end user defined section                                                 */
#endif
    flagbyte6 |= FLAGBYTE6_DONEINIT;
  SKIP_INIT:;
    return;
}
