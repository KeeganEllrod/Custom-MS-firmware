/* $Id: premain.c,v 1.1 2007/05/01 23:09:39 jsmcortina Exp $ */
void __premain() 
{ 
	(*((volatile unsigned char*)(0x0030))) = 0x3d; //PPAGE set to 0x3C
} 

