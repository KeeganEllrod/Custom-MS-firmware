/* $Id: ms2_extra_misc.c,v 1.136 2018/07/23 18:00:57 jsmcortina Exp $
 * Copyright 2006, 2007, 2008, 2009, 2010, 2011, 2012, 2013
 * James Murray and Kenneth Culver
 *
 * This file is a part of MS2/Extra.
 *
 * calc_rpmdot()
    Origin: Al Grippo
    Moderate: James Murray / Kenneth Culver
    Majority: James Murray / Kenneth Culver
 * boost_ctl_init()
    Origin: Kenneth Culver
    Majority: Kenneth Culver
 * boost_ctl()
    Origin: Kenneth Culver
    Moderate: James Murray / Kenneth Culver
    Majority: James Murray / Kenneth Culver
 * get_adc()
    Origin: Al Grippo
    Major:  James Murray / Kenneth Culver
    Majority: James Murray / Kenneth Culver
 * barocor_eq()
    Origin: Al Grippo
    Majority: Al Grippo
 * CW_table()
    Origin: Al Grippo
    Minor: James Murray
    Majority: Al Grippo
 * set_spr_port()
    Trace: Al Grippo
    Major: Rewrite. James Murray
    Majority: James Murray
 * remote_spr_ports()
    Trace: Al Grippo
    Major: Rewrite. James Murray
    Major: Make remote. Jean Belanger
    Majority: James Murray / Jean Belanger
 * Flash_Init()
    Trace: Al Grippo
    Major: Rewrite. James Murray
    Majority: James Murray
 * calc_opentime()
    Origin: Al Grippo
    Major: Jean Belanger
    Majority: Al Grippo / Jean Belanger
 * twoptlookup()
    Origin: James Murray
    Majority: James Murray
 * calc_fuel_req_ang()
    Origin: Jean Belanger
    Majority: Jean Belanger
 * wheel_fill_map_event_array
    Origin: Kenneth Culver
    Moderate: James Murray
    Majority: Kenneth Culver / James Murray
 * calc_ITB_load()
    Origin: Kenneth Culver
    Majority: Kenneth Culver
 * handle_spareports()
    Origin: Al Grippo
    Majority: Al Grippo
 * handle_ovflo()
    Origin: Kenneth Culver
    Majority: Kenneth Culver
 * ck_log_clr()
    Origin: James Murray
    Majority: James Murray
 * long_abs()
    Origin: James Murray
    Majority: James Murray
 * calc_flexfuel()
    Origin: Al Grippo
    Major:  James Murray
    Majority: Al Grippo / James Murray
 * maflookup()
    Origin: James Murray
    Majority: James Murray
 * calc_deadzone_sliding_window()
    Origin: Grant Slender
    Majority: Grant Slender
 * stack_watch_init(), stack_watch()
    Origin: James Murray
    Majority: James Murray
 * do_testmode()
    Origin: James Murray
    Majority: James Murray
 * ckstall(), clear_all()
    Origin: James Murray (was in ASM)
    Majority: James Murray
 * sample_map_tps()
    Origin: Al Grippo
    Major:  James Murray / Kenneth Culver
    Majority: James Murray / Kenneth Culver
 * shifter()
    Origin: James Murray
    Majority: James Murray
 *
 * You should have received a copy of the code LICENSE along with this source,
 * ask on the www.msextra.com forum if you did not.
 */
#include "ms2_extra.h"

void calc_rpmdot()
{
    // rpmdot calc - sliding window squares - variable dataset and max sample rate
    rpmdot_data[0][0] = (unsigned int)lmms; // store actual 16 bit time to first pt in array
    rpmdot_data[0][1] = outpc.rpm/10; // store rpm

    if ((rpmdot_data[0][0] - rpmdot_data[1][0]) > 39) { // minimum 5ms between samples to prevent high rpm jitter and cycletime cost
        int rpmi;
        long rpmdot_sumx, rpmdot_sumx2, rpmdot_sumy, rpmdot_sumxy;
        long toprow, btmrow;
        unsigned long rpmdot_x; // was uint

        rpmdot_sumx = 0;
        rpmdot_sumx2 = 0;
        rpmdot_sumy = 0;
        rpmdot_sumxy = 0;

        rpmi = 0;
        // only use ten datapoints for this. Array defined as larger (used below)
        while ((rpmi < 10) && (rpmdot_sumxy < 10000000)) {
            rpmdot_x = rpmdot_data[0][0] - rpmdot_data[rpmi][0]; // relative time to keep numbers smaller
            rpmdot_sumx += rpmdot_x;
            rpmdot_sumy += rpmdot_data[rpmi][1];
            rpmdot_sumx2 += (rpmdot_x * rpmdot_x); // overflow if rpmdot_x > 65535
            rpmdot_sumxy += (rpmdot_x * rpmdot_data[rpmi][1]);
            rpmi++;
        }

        toprow = rpmdot_sumxy - (rpmdot_sumx * (rpmdot_sumy / rpmi)); // divide sumy to help overflow
        btmrow = rpmdot_sumx2 - (rpmdot_sumx * rpmdot_sumx / rpmi);

        btmrow = btmrow / 10; // allows top row to be 10x less to reduce overflow.
        toprow = (-toprow * 781) / btmrow;
        if (toprow > 32767) {
            toprow = 32767;
        } else if (toprow < -32767) {
            toprow = -32767;
        }

        // very low rpmdot
        if ((toprow > -150) && (toprow < 150)) {
            long tmp_top, tmp_btm;
            // see how it compares to max number of positions
            tmp_btm = rpmdot_data[0][0] - rpmdot_data[RPMDOT_N-1][0];
            tmp_top = (int)rpmdot_data[0][1] - (int)rpmdot_data[RPMDOT_N-1][1];
            tmp_btm = tmp_btm / 10; // allows top row to be 10x less to reduce overflow.
            tmp_top = (tmp_top * 781) / tmp_btm;
            if (tmp_top > 32767) {
                tmp_top = 32767;
            } else if (tmp_top < -32767) {
                tmp_top = -32767;
            }
            // use lesser magnitude of two
            if (long_abs(tmp_top) < long_abs(toprow)) {
                toprow = tmp_top;
            }
        }

        toprow = 50L * (toprow - outpc.rpmdot); // now 50% lag
        if ((toprow > 0) && (toprow < 100)) {
            toprow = 100;
        } else if ((toprow < 0) && (toprow > -100)) {
            toprow = -100;
        }
        outpc.rpmdot += (int)(toprow / 100);

        //shuffle data forwards by one
        for (rpmi = RPMDOT_N - 1; rpmi > 0 ; rpmi--) {
            rpmdot_data[rpmi][0] = rpmdot_data[rpmi - 1][0];
            rpmdot_data[rpmi][1] = rpmdot_data[rpmi - 1][1];
        }
    }
}

void boost_ctl_init(void)
{
    boost_ctl_last_pv[0] = boost_ctl_last_pv[1] = 0;
    boost_ctl_last_error = 0;
    boost_ctl_timer = 0;
    boost_ctl_duty = 0;
    boost_ctl_duty_100 = 0;
    outpc.boostduty = boost_ctl_duty;
    boost_PID_enabled = 0;
    boost_sensitivity_old = flash5.boost_ctl_sensitivity;
}

#define MAX_BOOST 5001
void boost_ctl(void)
{
    int tmp2;
    long tmp1 = 0;

    if (flagbyte3 & flagbyte3_runboost) {
        DISABLE_INTERRUPTS;
        flagbyte3 &= ~flagbyte3_runboost;
        ENABLE_INTERRUPTS;
        if (flash5.boost_ctl_settings & BOOST_CTL_CLOSED_LOOP) {
            /* CLOSED LOOP BOOST */
            int targ_load, boost_deriv;
            int boost_ctl_error;
            long Kp, Ki, Kd, PV, SP;
            int clKp, clKi, clKd, sensitivity, yaxis;
            unsigned char start_duty;

            start_duty = flash5.boost_ctl_openduty;

            if (flash5.boost_ctl_settings & BOOST_CTL_ADVANCED_MODE) {
                clKp = pg5_ptr->boost_ctl_Kp;
                clKi = pg5_ptr->boost_ctl_Ki;
                clKd = pg5_ptr->boost_ctl_Kd;
            } else {
                clKp = 100;
                clKi = 100;
                clKd = 100;
            }

            if (boost_sensitivity_old != pg5_ptr->boost_ctl_sensitivity) {
                boost_PID_enabled = 0;
                boost_sensitivity_old = pg5_ptr->boost_ctl_sensitivity;
            }

            sensitivity = MAX_BOOST - pg5_ptr->boost_ctl_sensitivity;

            targ_load = 0;
            if ((flash4.OverBoostOption & 0x08) && (flash4.FlexFuel & 0x1)) { // flex/boost option
                if (outpc.tps > flash4.flexboosttps) {
                    yaxis = outpc.fuel_pct;
                } else {
                    yaxis = 0;
                    targ_load = outpc.baro;
                }
            } else {
                yaxis = outpc.tps;
            }

            if (!targ_load) {
                targ_load = intrp_2ditable(outpc.rpm, yaxis, 8, 8,
                    &pg5_ptr->boost_ctl_loadtarg_rpm_bins[0],
                    &pg5_ptr->boost_ctl_loadtarg_tps_bins[0],
                    &pg5_ptr->boost_ctl_load_targets[0][0]);
            }

            if (flash5.boost_ctl_pins & BOOST_CTL_PINS_USE_INITIAL) {
                start_duty = intrp_2dctable(outpc.rpm, targ_load, 8, 8,
                        &pg12_ptr->boost_ctl_cl_pwm_rpms1[0],
                        &pg12_ptr->boost_ctl_cl_pwm_targboosts1[0],
                        &pg12_ptr->boost_ctl_cl_pwm_targs1[0][0], 0);
            }

            outpc.boost_targ = targ_load;

#define BOOST_MAP_HYST 50
    	    /* Do not try to control boost unless on top of target */
            {
                unsigned char ret;
                ret = 1;
                if ((outpc.map < (outpc.baro - BOOST_MAP_HYST))
                    || (outpc.engine & ENGINE_CRANK)
                    || (outpc.engine & ENGINE_ASE)) {
                    boost_ctl_duty = flash5.boost_ctl_closeduty;
                } else if (outpc.map >= (targ_load - flash5.boost_ctl_lowerlimit)) {
                    ret = 0;
                } else if (outpc.map >= outpc.baro) {
                    boost_ctl_duty = flash5.boost_ctl_openduty;
                } /* else no change */

                if (ret) {
                    outpc.boostduty = boost_ctl_duty;
                    boost_ctl_last_pv[0] = boost_ctl_last_pv[1] = boost_ctl_last_error = 0;
                    boost_PID_enabled = 0;
                    return;
                }
            }

            //PV = (outpc.fuelload * 10000L) / sensitivity;
			PV = (outpc.map * 10000L) / sensitivity; //this line has been altered to change the target to MAP instead of fuel load. the old line is commented out above.
            SP = (targ_load * 10000L) / sensitivity;

            boost_ctl_error = SP - PV;

            if (!boost_PID_enabled) {
                boost_ctl_last_error = boost_ctl_error;
                boost_ctl_duty = start_duty;
                boost_ctl_duty_100 = (int)boost_ctl_duty * 100;
                boost_PID_enabled = 1;
            }

            boost_deriv = PV - (2*boost_ctl_last_pv[0]) + boost_ctl_last_pv[1];

            Kp = ((long)(boost_ctl_error - boost_ctl_last_error) * clKp);
            Ki = ((((long)boost_ctl_error * flash5.boost_ctl_ms) / 1000) * clKi);
            Kd = ((long)boost_deriv * ((long)clKd*10) / flash5.boost_ctl_ms);

            boost_ctl_last_pv[1] = boost_ctl_last_pv[0];
            boost_ctl_last_pv[0] = PV;

            boost_ctl_last_error = boost_ctl_error;

            tmp1 =  boost_ctl_duty_100 + ((long)(Kp + Ki - Kd) / 10L);

            tmp2 = tmp1 / 100L;

            if (tmp2 < flash5.boost_ctl_closeduty) {
                tmp2 = flash5.boost_ctl_closeduty;
                tmp1 = flash5.boost_ctl_closeduty * 100;
            } else if (tmp2 > flash5.boost_ctl_openduty) {
                tmp2 = flash5.boost_ctl_openduty;
                tmp1 = flash5.boost_ctl_openduty * 100;
            }

            boost_ctl_duty_100 = tmp1;

            boost_ctl_duty = tmp2;
        } else {
            /* OPEN LOOP BOOST
             * lookup duty based on TPS,RPM
             */
            boost_ctl_duty = intrp_2dctable(outpc.rpm, outpc.tps, 8, 8,
                    &pg5_ptr->boost_ctl_pwmtarg_rpm_bins[0],
                    &pg5_ptr->boost_ctl_pwmtarg_tps_bins[0],
                    &pg5_ptr->boost_ctl_pwm_targets[0][0], 0);

        }
        outpc.boostduty = boost_ctl_duty;
    }
}

//get_adc should be placed in 0x3c page along with the clt, mat, ego, maf data tables
void get_adc(char chan1, char chan2)
{
    char chan;
    //long adcval;
    int adcvalv,tmp1,tmp2,tmp3;
    unsigned int tmpadc;

    for (chan = chan1; chan <= chan2; chan++)  {
        //    switch(chan)  {
        // when using switch, gcc puts lookup table around 0x5000 and then linker
        // gets all upset because we are in page 0x3c and jump table isn't. Replace
        // with ifs instead. No functional difference. This is known bug in gcc
        if ((chan == 0) && (flagbyte20 & FLAGBYTE20_USE_MAP)) {
            //removed lag code and first_adc comparison as only called here from init
            __asm__ __volatile__ (
                    "ldd    %1\n"
                    "subd   %2\n"
                    "ldy    %3\n"
                    "emul\n"
                    "ldx    #1023\n"
                    "ediv\n"
                    "tfr    y,d\n"
                    "addd   %2\n"
                    : "=d"(outpc.map)
                    : "m"(flash4.mapmax),
                    "m"(flash4.map0),
                    "m"(ATD0DR0)
                    : "y", "x");

        } else if (chan == 1) {
            //        adcval = (long)flash4.mat0 +
            //          ((long)flash4.matmult * matfactor_table[ATD0DR1]) / 100; // deg F or C x 10
            __asm__ __volatile__ (
                    //                "ldd    %1\n"
                    "asld\n"
                    "tfr    d,x\n"
                    "ldy    %2,x\n"
                    "ldd    %3\n"
                    "emul\n"
                    "ldx    #100\n"
                    "ediv\n"
                    "tfr    y,d\n"
                    "addd   %4\n"
                    : "=d"(tmp1)
                    : "d"(ATD0DR1),
                    "m"(matfactor_table[0]),
                    "m"(flash4.matmult),
                    "m"(flash4.mat0)
                    : "x", "y" );

            if(first_adc)
                outpc.mat = tmp1;
            else {
                //          outpc.mat += (short)((flash4.adcLF * (adcval - outpc.mat)) / 100);
                __asm__ __volatile__ (
                        //                "ldd    %1\n"
                        "subd   %3\n"
                        "tfr    d,y\n"
                        "clra\n"
                        "ldab    %2\n"      // it is a uchar
                        "emuls\n"
                        "ldx     #100\n"
                        "edivs\n"
                        "tfr     y,d\n"
                        "addd    %3\n"
                        : "=d"(outpc.mat)
                        : "d"(tmp1),
                        "m"(flash4.adcLF),
                        "m"(outpc.mat)
                        : "x", "y" );
            }
        } else if (chan == 2) {
            //        adcval = (long)flash4.clt0 +
            //          ((long)flash4.cltmult * cltfactor_table[ATD0DR2]) / 100; // deg F or C x 10
            __asm__ __volatile__ (
                    //                "ldd    %1\n"
                    "asld\n"
                    "tfr    d,x\n"
                    "ldy    %2,x\n"
                    "ldd    %3\n"
                    "emul\n"
                    "ldx    #100\n"
                    "ediv\n"
                    "tfr    y,d\n"
                    "addd   %4\n"
                    : "=d"(tmp1)
                    : "d"(ATD0DR2),
                    "m"(cltfactor_table[0]),
                    "m"(flash4.cltmult),
                    "m"(flash4.clt0)
                    : "x", "y" );
            if(first_adc)
                outpc.clt = tmp1;
            else {
                //          outpc.clt += (short)((flash4.adcLF * (adcval - outpc.clt)) / 100);
                __asm__ __volatile__ (
                        "ldd    %1\n"
                        "subd   %3\n"
                        "tfr    d,y\n"
                        "clra\n"
                        "ldab    %2\n"      // it is a uchar
                        "emuls\n"
                        "ldx     #100\n"
                        "edivs\n"
                        "tfr     y,d\n"
                        "addd    %3\n"
                        : "=d"(outpc.clt)
                        : "m"(tmp1),
                        "m"(flash4.adcLF),
                        "m"(outpc.clt)
                        : "x", "y" );
            }
        } else if (chan == 3) {
            outpc.tpsadc = ATD0DR3;
            //          adcval = (ATD0DR3 - (long)flash4.tps0) * 1000 /
            //          (flash4.tpsmax - flash4.tps0);                           // % x 10
            //          outpc.tps = (short)adcval;
            __asm__ __volatile__ (
                    "ldd    %1\n"
                    "subd   %2\n"
                    "tfr    d,x\n"

                    "ldd    %3\n"
                    "subd   %2\n"
                    "ldy    #1000\n"
                    "emul\n"
                    "ediv\n"
                    : "=y"(tmp1)
                    : "m"(flash4.tpsmax),
                    "m"(flash4.tps0),
                    "m"(ATD0DR3)
                    : "d", "x");

        } else if (chan == 4) {
            //        adcval = (long)flash4.batt0 +
            //          ((long)(flash4.battmax - flash4.batt0) * ATD0DR4) / 1023; // V x 10
            __asm__ __volatile__ (
                    "ldd    %1\n"
                    "subd   %2\n"
                    "ldy    %3\n"
                    "emul\n"
                    "ldx    #1023\n"
                    "ediv\n"
                    "tfr    y,d\n"
                    "addd   %2\n"
                    : "=d"(tmp1)
                    : "m"(flash4.battmax),
                    "m"(flash4.batt0),
                    "m"(ATD0DR4)
                    : "y", "x");
            if(first_adc)
                outpc.batt = tmp1;
            else {
                //        outpc.batt += (short)((flash4.adcLF * (adcval - outpc.batt)) / 100);
                __asm__ __volatile__ (
                        "ldd    %1\n"
                        "subd   %3\n"
                        "tfr    d,y\n"
                        "clra\n"
                        "ldab    %2\n"      // it is a uchar
                        "emuls\n"
                        "ldx     #100\n"
                        "edivs\n"
                        "tfr     y,d\n"
                        "addd    %3\n"
                        : "=d"(outpc.batt)
                        : "m"(tmp1),
                        "m"(flash4.adcLF),
                        "m"(outpc.batt)
                        : "x", "y" );
            }
        } else if (chan == 5) {
            if (flash4.egoport == 0) {
                tmpadc = ATD0DR5;
            } else {
                tmpadc = outpc.gpioadc[flash4.egoport - 1];
            }

            // check if sensor bad (near limits)
            if((tmpadc < 3) || (tmpadc > 1020)) {
                bad_ego_flag |= 0x01;
            } else {
                bad_ego_flag &= ~0x01;
            }
            //          adcval = (long)flash4.ego0 +
            //            ((long)flash4.egomult * egofactor_table[tmpadc]) / 100; // afr x 10
            __asm__ __volatile__ (
                    //                "ldx    %1\n"
                    "ldab   %2,x\n"
                    "clra\n"
                    "ldy    %3\n"
                    "emul\n"
                    "ldx    #100\n"
                    "ediv\n"
                    "tfr    y,d\n"
                    "addd   %4\n"
                    : "=d"(tmp3)
                    : "x"(tmpadc),
                    "m"(egofactor_table[0]),
                    "m"(flash4.egomult),
                    "m"(flash4.ego0)
                    : "y" );

            // next line doesn't compile right because gcc doesn't notice that X got clobbered above
            //          tmp1 = (int)tmpadc;
            __asm__ __volatile__ ("ldd #500\n"
                    "emuls\n"
                    "ldx #1023\n"
                    "edivs\n":
                    "=y" (adcvalv):
                    "y" (tmpadc):    // was tmp1
                    "d","x");

            if (first_adc) {
                outpc.ego1 = tmp3;
                outpc.egoV1 = adcvalv;                          // Vx100
            } else {
                //            outpc.ego1 += (short)((flash4.egoLF * (adcval - outpc.ego1)) / 100);
                __asm__ __volatile__ (
                        "ldd    %1\n"
                        "subd   %3\n"
                        "tfr    d,y\n"
                        "clra\n"
                        "ldab    %2\n"      // it is a uchar
                        "emuls\n"
                        "ldx     #100\n"
                        "edivs\n"
                        "tfr     y,d\n"
                        "addd    %3\n"
                        : "=d"(outpc.ego1)
                        : "m"(tmp3),
                        "m"(flash4.egoLF),
                        "m"(outpc.ego1)
                        : "x", "y" );

                tmp1 = (int)flash4.egoLF;
                tmp2 = adcvalv - outpc.egoV1;
                __asm__ __volatile__ ("emuls\n"
                        "ldx #100\n"
                        "edivs\n":
                        "=y" (adcvalv):
                        "d" (tmp1),
                        "y" (tmp2):
                        "x");
                outpc.egoV1 += adcvalv;      // Vx100
            }
        } else if (chan == 6) {
            outpc.adc6 = ATD0DR6;
        } else if (chan == 7) {
            outpc.adc7 = ATD0DR7;

        }                        // end of switch
    }                            // end of for loop

    // if GPIO slave copy these raw ADCs to a convenient place so master can grab them
    if (CANid) {
        outpc.gpioadc[0] = ATD0DR0;
        outpc.gpioadc[1] = ATD0DR1;
        outpc.gpioadc[2] = ATD0DR2;
        outpc.gpioadc[3] = ATD0DR3;
        outpc.gpioadc[4] = ATD0DR4;
        outpc.gpioadc[5] = ATD0DR5;
        outpc.gpioadc[6] = ATD0DR6;
        outpc.gpioadc[7] = ATD0DR7;
    }

    // now calculate other stuff that uses optional ADC inputs
    if (flash4.BaroOption == 2)  {

        if ((flash4.rtbaroport & 0x0f) == 0) {
            tmpadc = ATD0DR0;
        } else if ((flash4.rtbaroport & 0x0f) == 6) {
            tmpadc = outpc.adc6;
        } else if ((flash4.rtbaroport & 0x0f) == 7) {
            tmpadc = outpc.adc7;
        } else if ((flash4.rtbaroport & 0x0f) > 7) {
            //read for GPIO port copy
            tmpadc = outpc.gpioadc[flash4.rtbaroport & 0x7];
        } else {
            tmpadc = 0;
        }

        //          adcval = (long)flash4.baro0 +
        //            ((long)(flash4.baromax - flash4.baro0) * tmpadc) / 1023; // kPa x 10
        __asm__ __volatile__ (
                "ldd    %1\n"
                "subd   %2\n"
                "ldy    %3\n"
                "emul\n"
                "ldx    #1023\n"
                "ediv\n"
                "tfr    y,d\n"
                "addd   %2\n"
                : "=d"(tmp1)
                : "m"(flash4.baromax),
                "m"(flash4.baro0),
                "m"(tmpadc)
                : "y", "x");

        if(first_adc)
            outpc.baro = tmp1;
        else {
            //            outpc.baro += (short)((flash4.adcLF * (adcval - outpc.baro)) / 100);
            __asm__ __volatile__ (
                    "ldd    %1\n"
                    "subd   %3\n"
                    "tfr    d,y\n"
                    "clra\n"
                    "ldab    %2\n"      // it is a uchar
                    "emuls\n"
                    "ldx     #100\n"
                    "edivs\n"
                    "tfr     y,d\n"
                    "addd    %3\n"
                    : "=d"(outpc.baro)
                    : "m"(tmp1),
                    "m"(flash4.adcLF),
                    "m"(outpc.baro)
                    : "x", "y" );
        }
        if (outpc.baro < flash4.baro_lower) {
            outpc.baro = flash4.baro_lower;
        } else if (outpc.baro > flash4.baro_upper) {
            outpc.baro = flash4.baro_upper;
        }
    }

    if (((flash4.EgoOption & 0x07) == 2) || ((flash4.EgoOption & 0x07) == 4))  {

        if ((flash4.ego2port & 0x0f) == 6) {
            tmpadc = outpc.adc6;
        } else if ((flash4.ego2port & 0x0f) == 7) {
            tmpadc = outpc.adc7;
        } else if ((flash4.ego2port & 0x0f) > 7) {
            //read for GPIO port copy
            tmpadc = outpc.gpioadc[flash4.ego2port & 0x7];
        } else {
            tmpadc = 0;
        }

        // check if sensor bad (near limits)
        if((tmpadc < 3) || (tmpadc > 1020)) {
            bad_ego_flag |= 0x02;
        } else {
            bad_ego_flag &= ~0x02;
        }
        //          adcval = (long)flash4.ego0 +
        //            ((long)flash4.egomult * egofactor_table[tmpadc]) / 100; // afr x 10
        __asm__ __volatile__ (
                //                "ldx    %1\n"
                "ldab   %2,x\n"
                "clra\n"
                "ldy    %3\n"
                "emul\n"
                "ldx    #100\n"
                "ediv\n"
                "tfr    y,d\n"
                "addd   %4\n"
                : "=d"(tmp3)
                : "x"(tmpadc),
                "m"(egofactor_table[0]),
                "m"(flash4.egomult),
                "m"(flash4.ego0)
                : "y" );

        // next line doesn't compile right because gcc doesn't notice that X got clobbered above
        //          tmp1 = (int)tmpadc;
        __asm__ __volatile__ ("ldd #500\n"
                "emuls\n"
                "ldx #1023\n"
                "edivs\n":
                "=y" (adcvalv):
                "y" (tmpadc):    // was tmp1
                "d","x");
        if (first_adc) { // skip the LF for
            outpc.ego2 = tmp3;
            outpc.egoV2 = adcvalv;                              // Vx100
        } else {
            //            outpc.ego2 += (short)((flash4.egoLF * (adcval - outpc.ego2)) / 100);
            __asm__ __volatile__ (
                    "ldd    %1\n"
                    "subd   %3\n"
                    "tfr    d,y\n"
                    "clra\n"
                    "ldab    %2\n"      // it is a uchar
                    "emuls\n"
                    "ldx     #100\n"
                    "edivs\n"
                    "tfr     y,d\n"
                    "addd    %3\n"
                    : "=d"(outpc.ego2)
                    : "m"(tmp3),
                    "m"(flash4.egoLF),
                    "m"(outpc.ego2)
                    : "x", "y" );

            tmp1 = (int)flash4.egoLF;
            tmp2 = adcvalv - outpc.egoV2;
            __asm__ __volatile__ ("emuls\n"
                    "ldx #100\n"
                    "edivs\n":
                    "=y" (adcvalv):
                    "d" (tmp1),
                    "y" (tmp2):
                    "x");
            outpc.egoV2 += adcvalv;      // Vx100
        }
    } else {
        outpc.ego2 = outpc.ego1;
        outpc.egoV2 = outpc.egoV1;
    }


    //was knock. Now use the ADC pin as a digi input if requested

    return;
}

int barocor_eq(int baro)
{
    // returns baro correction in 0.1% (100 is no correction)
    // baro in kPa x 10
    return((int)(flash4.bcor0 * 10 + (((long)flash4.bcormult * baro) / 100)));
}

int CW_table(int clt, int *table, int *temp_table)
{
    int ix;
    long interp, interp3;
    // returns values for various cold warmup table interpolations
    // bound input arguments
    if(clt > temp_table[NO_TEMPS-1])  {
        return(table[NO_TEMPS -1]);
    }
    if(clt < temp_table[0])  {
        return(table[0]);
    }
    for(ix = NO_TEMPS - 2; ix > -1; ix--)  {
        if(clt > temp_table[ix])  {
            break;
        }
    }
    if(ix < 0)ix = 0;

    interp = temp_table[ix + 1] - temp_table[ix];
    if(interp != 0)  {
        interp3 = (clt - temp_table[ix]);
        interp3 = (100 * interp3);
        interp = interp3 / interp;
    }
    return((int)(table[ix] + interp * (table[ix+1] - table[ix])/ 100));
}

void set_spr_port(char port, char val)
{
    unsigned char pval;

    if (val) {
        outpc.port_status |= (0x01 << port);
    } else {
        outpc.port_status &= ~(0x01 << port);    // JL fix
    }

    // Use the MS ports
    if (port < 4) {
        pval = (0x01 << (port + 2));
        if (val) {
            PTM |= pval;
         } else {
            PTM &= ~pval;
         }
    } else if (port < 6) {
#ifndef MICROSQUIRT
        /* Workaround for MT bug, reverse IAC1 and IAC2 */
        /* But only on MS2. Microsquirt module is correct */
        if (port == 4) {
            port = 5;
        } else if (port == 5) {
            port = 4;
        }
#endif
        pval = (0x01 << (port + 2));
        if (val)  {
            DISABLE_INTERRUPTS
            PTT |= pval;
            ENABLE_INTERRUPTS
        } else  {
            DISABLE_INTERRUPTS
            PTT &= ~pval;
            ENABLE_INTERRUPTS
        }
    } else {
        if (val) {
            PORTA |= 0x01;
        } else {
            PORTA &= ~0x01;
        }
    }
}

/***************************************************************************
 **
 ** Determine remote port settings
 **
 **************************************************************************/

void remote_spr_ports(void)
{
    int ix;
    char ctmp1, ctmp2, cond1, cond12, cond2;
    unsigned char us1, us2;
    long tmp1, tmp2;

    for(ix = 0;ix < 8; ix++)  {
        if(flash5.rmt_spr_port[ix])  {
            cond1 = flash5.rmt_condition1[ix];
            cond12 = flash5.rmt_cond12[ix];
            cond2 = flash5.rmt_condition2[ix];
            ctmp1 = 0;
            ctmp2 = 0;
            tmp1 = 0;
            tmp2 = 0;

            // Evaluate first condition
            if (flash5.rmt_out_byte1[ix] == 0x01) { // signed char
                tmp1 = *((char *) (&outpc) + flash5.rmt_out_offset1[ix]);
            } else if (flash5.rmt_out_byte1[ix] == 0x81) { // unsigned char
                tmp1 = *((unsigned char *) (&outpc) + flash5.rmt_out_offset1[ix]);
            } else if (flash5.rmt_out_byte1[ix] == 0x02) { // signed int
                tmp1 = *(int *) ((char *) (&outpc) + flash5.rmt_out_offset1[ix]);
            } else if (flash5.rmt_out_byte1[ix] == 0x82) { // unsigned int
                tmp1 = *(unsigned int *) ((char *) (&outpc) + flash5.rmt_out_offset1[ix]);
            } else {
                tmp1 = 0;
            }
            us1 = flash5.rmt_out_byte1[ix] & 0x80; // unsigned flag

            if (cond1 == '&') { // bitwise AND
                tmp1 = tmp1 & flash5.rmt_thresh1[ix];
            } else {
                long t;
                if (us1) {
                    t = (long)(unsigned int)flash5.rmt_thresh1[ix];
                } else {
                    t = (long)(int)flash5.rmt_thresh1[ix];
                }
                tmp1 = tmp1 - t;
            }

            if (cond1 == '<') {
                tmp1 = -tmp1;   //  convert < condition to same as > condition
            }
            /* assume hyst value doesn't overflow sign bit */
            if (cond1 == '=') {
                if ((tmp1 >= -(long)flash5.rmt_hyst1[ix]) && (tmp1 <= (long)flash5.rmt_hyst1[ix]))
                    ctmp1 = 1;  // 1st condition true
            } else if (tmp1 > 0) {
                ctmp1 = 1;      // 1st condition true
            } else {
                ctmp1 = 0;      // 1st condition false
            }
            // Evaluate second condition if there is one
            if (cond12 != ' ') {
                if (flash5.rmt_out_byte2[ix] == 0x01) { // signed char
                    tmp2 = *((char *) (&outpc) + flash5.rmt_out_offset2[ix]);
                } else if (flash5.rmt_out_byte2[ix] == 0x81) { // unsigned char
                    tmp2 = *((unsigned char *) (&outpc) + flash5.rmt_out_offset2[ix]);
                } else if (flash5.rmt_out_byte2[ix] == 0x02) { // signed int
                    tmp2 = *(int *) ((char *) (&outpc) + flash5.rmt_out_offset2[ix]);
                } else if (flash5.rmt_out_byte2[ix] == 0x82) { // unsigned int
                    tmp2 = *(unsigned int *) ((char *) (&outpc) + flash5.rmt_out_offset2[ix]);
                } else {
                    tmp2 = 0;
                }
                us2 = flash5.rmt_out_byte2[ix] & 0x80; // unsigned flag

                if (cond2 == '&') { // bitwise AND
                    tmp2 = tmp2 & flash5.rmt_thresh2[ix];
                } else {
                    long t;
                    if (us2) {
                        t = (long)(unsigned int)flash5.rmt_thresh2[ix];
                    } else {
                        t = (long)(int)flash5.rmt_thresh2[ix];
                    }
                    tmp2 = tmp2 - t;
                }

                if (cond2 == '<') {
                    tmp2 = -tmp2;       //  convert < condition to same as > condition
                }
                if (cond2 == '=') {
                    if ((tmp2 >= -(long)flash5.rmt_hyst2[ix])
                        && (tmp2 <= (long)flash5.rmt_hyst2[ix]))
                        ctmp2 = 1;      // 2nd condition true
                } else if (tmp2 > 0) {
                    ctmp2 = 1;  // 2nd condition true
                } else {
                    ctmp2 = 0;  // 2nd condition false
                }
            }
            // Evaluate final condition
            if (((cond12 == '&') && (ctmp1 && ctmp2)) ||
                ((cond12 == '|') && (ctmp1 || ctmp2)) ||
                ((cond12 == ' ') && ctmp1)) {
                if (lst_pval[ix] != flash5.rmt_port_val[ix])  {
                    if (flash5.rmt_port_val[ix]) {
                        outpc.gpioport[flash4.port_generic - 1] |= (0x01 << ix);
                    } else {
                        outpc.gpioport[flash4.port_generic - 1] &= ~(0x01 << ix);
                    }
                    lst_pval[ix] = flash5.rmt_port_val[ix];
                }
            } else {
                // Evaluate hysteresis conditions
                if ((cond1 == '>')
                    || (cond1 == '<')) {
                    tmp1 = -tmp1 - flash5.rmt_hyst1[ix];
                }
                if ((cond1 == '=') || (cond1 == '&')) {
                    ctmp1 = 1 - ctmp1;  // 1st hyst. condition opposite of set cond
                } else if (tmp1 > 0) {
                    ctmp1 = 1;  // 1st hysteresis condition true
                } else {
                    ctmp1 = 0;  // 1st hysteresis condition false
                }
                if (cond12 != ' ') {
                    if ((cond2 == '>')
                        || (cond2 == '<'))
                        tmp2 = -tmp2 - flash5.rmt_hyst2[ix];
                    if ((cond2 == '=') || (cond2 == '&')) {
                        ctmp2 = 1 - ctmp2;      // 2nd hyst. condition opposite of set cond
                    } else if (tmp2 > 0) {
                        ctmp2 = 1;      // 2nd hysteresis condition true
                    } else {
                        ctmp2 = 0;      // 2nd hysteresis condition false
                    }
                }
                // Evaluate final hysteresis condition
                if (((flash5.rmt_cond12[ix] == '&') && (ctmp1 || ctmp2)) ||
                                ((flash5.rmt_cond12[ix] == '|') && (ctmp1 && ctmp2)) ||
                                ((flash5.rmt_cond12[ix] == ' ') && ctmp1))  {
                    if (lst_pval[ix] != 1 - flash5.rmt_port_val[ix])  {
                        if (1 - flash5.rmt_port_val[ix]) {
                            outpc.gpioport[flash4.port_generic - 1] |= (0x01 << ix);
                        } else {
                            outpc.gpioport[flash4.port_generic - 1] &= ~(0x01 << ix);
                        }
                            lst_pval[ix] = 1 - flash5.rmt_port_val[ix];
                    }
                }
            }                   // end eval of hysteresis conditions
        }                       // end if spr_port
    }
}

//*****************************************************************************
//* Function Name: Flash_Init
//* Description : Initialize Flash NVM for HCS12 by programming
//* FCLKDIV based on passed oscillator frequency, then
//* uprotect the array, and finally ensure PVIOL and
//* ACCERR are cleared by writing to them.
//*
//*****************************************************************************
void Flash_Init()
{
    /* Next, initialize FCLKDIV register to ensure we can program/erase */
    FCLKDIV = 39;
    //  FPROT = 0xFF; /* Disable all protection (only in special modes)*/
    // commented as it will likely spew out error normally
    FSTAT = PVIOL|ACCERR;/* Clear any errors */
    return;
}

/**************************************************************************
 **
 ** Calculation of Battery Voltage Correction for Injector Opening Time
 **
 ** Injector open time is implemented as a linear function of
 **  battery voltage, from 7.2 volts to 19.2 volts,
 **  with 13.2 volts being the nominal operating voltage
 **
 ** INJOPEN = injector open time at 13.2 volts in ms x 10
 ** BATTFAC = injector open adjustment factor 6 volts from 13.2V in ms x 10
 **
 **
 ** + (INJOPEN + BATTFAC)
 ** +   *
 ** +                     (INJOPEN)
 ** +                         *
 ** +                                       (INJOPEN - BATTFAC)
 ** +                                               *
 ** +
 ** ++++++++++++++++++++++++++++++++++++++++++++++++++++++
 **    7.2V                 13.2V                19.2
 **
 **************************************************************************
 **
 ** The linear function has been replaced by a non-linear function
 ** which is a more realistic representation of the physics involved.
 **
 ** The correction to the injector open time at 13.2V is multiplied by
 ** (13.2/battery voltage)
 **
 **************************************************************************/
void calc_opentime()
{
    int tmp1,tmp2,tmp3;

    tmp3 = 60 * outpc.batt;
	tmp2 = 132 * (132 - outpc.batt);
	tmp1 = -(((long)pg4_ptr->BatFac * tmp2) / tmp3);

    if ((((int)pg4_ptr->InjOpen) - tmp1) > 0) {
        //positive which is reasonable
        pw_open1 = (unsigned int)(pg4_ptr->InjOpen - tmp1);
    } else {
		// if it was negative then don't set so use default value
        pw_open1 = pg4_ptr->InjOpen;
    }

    if (pw_open1 > 5000) {
        pw_open1 = 5000; // hardcoded 5ms max
    }

    outpc.deadtime1 = pw_open1;

    // if channel 2 has different parameters, then apply them here
    if (pg4_ptr->ICIgnOption & 0x20) {
        tmp1 = -(((long)pg4_ptr->BatFac2 * tmp2) / tmp3);

        if ((((int)pg4_ptr->InjOpen2) - tmp1) > 0) {
            //positive which is reasonable
			pw_open2 = (unsigned int)(pg4_ptr->InjOpen2 - tmp1);
        } else {
			// if it was negative then don't set so use default value
            pw_open2 = pg4_ptr->InjOpen2;
        }

        if (pw_open2 > 5000) {
            pw_open2 = 5000; // hardcoded 5ms max
        }
    } else {
        pw_open2 = pw_open1;
    }

        if (!(seq_inj_ctrl & SEQ_STD_INJ)) {
                // Additional drivers used for staged injection
            // if channel 3 and 4 have different parameters, then apply them here
            if (((flash8.seq_inj & 0x03) == 1) && (pg4_ptr->ICIgnOption & 0x20)) {
                tmp1 = -(((long)pg8_ptr->BatFac3 * tmp2) / tmp3);

                if ((((int)pg8_ptr->InjOpen3) - tmp1) > 0) {
                    //positive which is reasonable
                    pw_open3 = (unsigned int)(pg8_ptr->InjOpen3 - tmp1);
                } else {
                    // if it was negative then don't set so use last value
                    pw_open3 = pg8_ptr->InjOpen3;
                }

                if (pw_open3 > 5000) {
                    pw_open3 = 5000; // hardcoded 5ms max
                }

                tmp1 = -(((long)pg8_ptr->BatFac4 * tmp2) / tmp3);

                if ((((int)pg8_ptr->InjOpen4) - tmp1) > 0) {
                    //positive which is reasonable
                    pw_open4 = (unsigned int)(pg8_ptr->InjOpen4 - tmp1);
                } else {
                    // if it was negative then don't set so use last value
                    pw_open4 = pg8_ptr->InjOpen4;
                }

                if (pw_open4 > 5000) {
                    pw_open4 = 5000; // hardcoded 5ms max
                }
            } else {
                        pw_open3 = pw_open4 = pw_open2;
                        pw_open2 = pw_open1;
            }
        }

}

unsigned int twoptlookup(unsigned int x, unsigned int x0, unsigned int x1, unsigned int y0, unsigned int y1 )
{
    long interp, interp3;
    unsigned int result;

    // bound input arguments
    if(x >= x1)  {
        return(y1);
    }

    if(x <= x0)  {
        return(y0);
    }

    interp = (long)x1 - (long)x0;
    interp3 = ((long)x - (long)x0);
    interp3 = (100 * interp3);
    interp = interp3 / interp;

    interp = interp * ((long)y1 - (long)y0)/100;
    result = (unsigned int)( (long)y0 + interp );

    return(result);
}

long calc_fuel_req_ang (long ang, unsigned long pw, unsigned int pw_open)
{
    long fuel_req_ang;

    // Adjust timing for mid-pulse and end-of-pulse modes
    if (pw == 0) {
        fuel_req_ang = ang;
    } else {
        if (flash8.seq_inj & 0x40) {
            // Mid-pulse
            fuel_req_ang = ang + (((pw * 15)>>1) + (long)(pw_open) * 1500L) / ticks_per_deg;
        } else if (flash8.seq_inj & 0x80) {
            // End-of-pulse
            fuel_req_ang = ang + (pw * 15 + (long)(pw_open) * 1500L) / ticks_per_deg;
        } else {
            fuel_req_ang = ang;
        }
        while (fuel_req_ang > cycle_deg) {
            fuel_req_ang -= cycle_deg;
        }

        while (fuel_req_ang < 0) {
            fuel_req_ang += cycle_deg;
        }
    }

    return(fuel_req_ang);
}

void wheel_fill_map_event_array (map_event * map_events_fill, int map_ang,
                                 ign_time last_tooth_time,
                                 unsigned int last_tooth_ang)
{
    char iterate, tth, wfe_err;
    int tth_ang, tmp_ang, i;
    unsigned int map_time, map_window_time;

    map_window_time = (unsigned int)((((flash4.mapsample_window *10) * last_tooth_time.time_32_bits) / last_tooth_ang)
                      / 192L);
    if (map_window_time < 1) {
        map_window_time = 1;
    }

    for (i = 0; i < no_triggers; i++) {
        wfe_err = 0;
        iterate = 0;
        tth_ang = trig_angs[i];
        tth = trigger_teeth[i];
        while (!iterate) {
            if (tth_ang > map_ang) {
                iterate = 1;
            } else {
                //how far do we step back in deg
                tth--;
                if (tth < 1) {
                    tth = last_tooth;
                    wfe_err++;
                    if (wfe_err > 1) {
                        iterate = 2;
                    }
                }
                tth_ang += deg_per_tooth[tth - 1];
            }
        }
        if (iterate == 2) {
            DISABLE_INTERRUPTS;
            asm ("nop\n");      // something screwed up, place for breakpoint
            ENABLE_INTERRUPTS;
            // can't continue as didn't find a valid tooth
            return;
        }

        tmp_ang = tth_ang - map_ang;

        map_time = (unsigned int)(((tmp_ang * last_tooth_time.time_32_bits) /
                                   last_tooth_ang) / 192L);
        wfe_err = 0;

        while ((wfe_err < 2) && (map_time < 1)) {
            // too soon after tooth, need to step back
            tth--;
            if (tth < 1) {
                tth = last_tooth;
                wfe_err++;
            }
            tth_ang += deg_per_tooth[tth - 1];
            // recalc
            tmp_ang = tth_ang - map_ang;
            map_time =
                (unsigned int)(((tmp_ang * last_tooth_time.time_32_bits) / last_tooth_ang) / 192L);
        }

        if (wfe_err > 1) {
            DISABLE_INTERRUPTS;
            asm ("nop\n");      // something screwed up, place for breakpoint
            ENABLE_INTERRUPTS;
            // can't continue as didn't find a valid tooth
            return;
        }

        map_events_fill[i].tooth = tth;
        map_events_fill[i].time = map_time;
        map_events_fill[i].map_window_set = map_window_time;
        map_events_fill[i].evnum = i;
    }

    /* special workaround for 2 cyl odd wasted*/
    if (((flash4.no_cyl & 0x1f) == 2) && (flash4.ICIgnOption & 0x8) && ((flash4.spk_mode3 & 0xc0) == 0x40) && (no_triggers == 4)) {
        /* use the later of the two close events only, otherwise get two pairs of events that considerably overlap */
        map_events_fill[1].tooth = map_events_fill[2].tooth;
        map_events_fill[1].time = map_events_fill[2].time;
        map_events_fill[1].map_window_set = map_events_fill[2].map_window_set;

        map_events_fill[2].tooth = map_events_fill[0].tooth;
        map_events_fill[2].time = map_events_fill[0].time;
        map_events_fill[2].map_window_set = map_events_fill[0].map_window_set;

        map_events_fill[3].tooth = map_events_fill[1].tooth;
        map_events_fill[3].time = map_events_fill[1].time;
        map_events_fill[3].map_window_set = map_events_fill[1].map_window_set;
    }
}

int calc_ITB_load(int percentbaro)
{
    int tmp3, tmp4, tmp5; 

    tmp3 = intrp_1ditable(outpc.rpm, 10,
            (unsigned int *) flash11.ITB_load_rpms, 1,
            (int *) flash11.ITB_load_loadvals);

    tmp4 = intrp_1ditable(outpc.rpm, 10,
            (unsigned int *) flash11.ITB_load_rpms, 1,
            (int *) flash11.ITB_load_switchpoints); 

    if (percentbaro < 900) {
        /* Make MAP fit in to 0-tmp3 % load... so if user selects 60%,
         * 0-90kPa would be 0-60% load, and the throttle position above
         * that point to 100% throttle will be 60% load to 100% load
         */
        tmp3 = (((long) percentbaro * tmp3) / 900);
    } else {
        /* Make TPS fit in tmp3 - 100% */
        if (outpc.tps >= tmp4) {
            /* This is the amt of load TPS has to fit into */
            tmp5 = 1000 - tmp3;

            /* This is the actual percent above the
             * switchpoint TPS is at */
            tmp4 = ((long)(outpc.tps - tmp4) * 1000) / (1000 - tmp4);


            /* Now scale that into what's left above the 90 % baro 
             * point
             */
            tmp3 = (((long) tmp4 * tmp5) / 1000) + tmp3;

        }
        /* IF TPS hasn't gone above the setpoint, load should
         * stay at the user-set setpoint */
    }

    /* Make 10 the lowest possible load */

    if (tmp3 < 100) {
        tmp3 = 100;
    }

    return tmp3;
}

/***************************************************************************
 **
 ** Determine spare port settings
 ** Programmable on/off outputs
 **
 **************************************************************************/
void handle_spareports(void)
{
    int ix;
    char ctmp1, ctmp2, cond1, cond12, cond2;
    unsigned char us1, us2;
    long tmp1, tmp2;

    for (ix = 0; ix < NPORT; ix++) {
        if (flash4.spr_port[ix]) {
            cond1 = flash4.condition1[ix];
            cond12 = flash4.cond12[ix];
            cond2 = flash4.condition2[ix];
            ctmp1 = 0;
            ctmp2 = 0;
            tmp1 = 0;
            tmp2 = 0;

            // Evaluate first condition
            if (flash4.out_byte1[ix] == 0x01) { // signed char
                tmp1 = *((char *) (&outpc) + flash4.out_offset1[ix]);
            } else if (flash4.out_byte1[ix] == 0x81) { // unsigned char
                tmp1 = *((unsigned char *) (&outpc) + flash4.out_offset1[ix]);
            } else if (flash4.out_byte1[ix] == 0x02) { // signed int
                tmp1 = *(int *) ((char *) (&outpc) + flash4.out_offset1[ix]);
            } else if (flash4.out_byte1[ix] == 0x82) { // unsigned int
                tmp1 = *(unsigned int *) ((char *) (&outpc) + flash4.out_offset1[ix]);
            } else {
                tmp1 = 0;
            }
            us1 = flash4.out_byte1[ix] & 0x80; // unsigned flag

            if (cond1 == '&') { // bitwise AND
                tmp1 = tmp1 & flash4.thresh1[ix];
            } else {
                long t;
                if (us1) {
                    t = (long)(unsigned int)flash4.thresh1[ix];
                } else {
                    t = (long)(int)flash4.thresh1[ix];
                }
                tmp1 = tmp1 - t;
            }

            if (cond1 == '<') {
                tmp1 = -tmp1;   //  convert < condition to same as > condition
            }
            /* assume hyst value doesn't overflow sign bit */
            if (cond1 == '=') {
                if ((tmp1 >= -(long)flash4.hyst1[ix]) && (tmp1 <= (long)flash4.hyst1[ix]))
                    ctmp1 = 1;  // 1st condition true
            } else if (tmp1 > 0) {
                ctmp1 = 1;      // 1st condition true
            } else {
                ctmp1 = 0;      // 1st condition false
            }
            // Evaluate second condition if there is one
            if (cond12 != ' ') {
                if (flash4.out_byte2[ix] == 0x01) { // signed char
                    tmp2 = *((char *) (&outpc) + flash4.out_offset2[ix]);
                } else if (flash4.out_byte2[ix] == 0x81) { // unsigned char
                    tmp2 = *((unsigned char *) (&outpc) + flash4.out_offset2[ix]);
                } else if (flash4.out_byte2[ix] == 0x02) { // signed int
                    tmp2 = *(int *) ((char *) (&outpc) + flash4.out_offset2[ix]);
                } else if (flash4.out_byte2[ix] == 0x82) { // unsigned int
                    tmp2 = *(unsigned int *) ((char *) (&outpc) + flash4.out_offset2[ix]);
                } else {
                    tmp2 = 0;
                }
                us2 = flash4.out_byte2[ix] & 0x80; // unsigned flag

                if (cond2 == '&') { // bitwise AND
                    tmp2 = tmp2 & flash4.thresh2[ix];
                } else {
                    long t;
                    if (us2) {
                        t = (long)(unsigned int)flash4.thresh2[ix];
                    } else {
                        t = (long)(int)flash4.thresh2[ix];
                    }
                    tmp2 = tmp2 - t;
                }

                if (cond2 == '<') {
                    tmp2 = -tmp2;       //  convert < condition to same as > condition
                }
                if (cond2 == '=') {
                    if ((tmp2 >= -(long)flash4.hyst2[ix])
                        && (tmp2 <= (long)flash4.hyst2[ix]))
                        ctmp2 = 1;      // 2nd condition true
                } else if (tmp2 > 0) {
                    ctmp2 = 1;  // 2nd condition true
                } else {
                    ctmp2 = 0;  // 2nd condition false
                }
            }

            // Evaluate final condition
            if (((cond12 == '&') && (ctmp1 && ctmp2)) ||
                ((cond12 == '|') && (ctmp1 || ctmp2)) ||
                ((cond12 == ' ') && ctmp1)) {
                char pv;
                pv = flash4.port_val[ix];
                if (lst_pval[ix] != pv) {
                    set_spr_port((char) ix, pv);
                    lst_pval[ix] = pv;
                }
            } else {
                // Evaluate hysteresis conditions
                if ((cond1 == '>')
                    || (cond1 == '<')) {
                    tmp1 = -tmp1 - flash4.hyst1[ix];
                }
                if ((cond1 == '=') || (cond1 == '&')) {
                    ctmp1 = 1 - ctmp1;  // 1st hyst. condition opposite of set cond
                } else if (tmp1 > 0) {
                    ctmp1 = 1;  // 1st hysteresis condition true
                } else {
                    ctmp1 = 0;  // 1st hysteresis condition false
                }
                if (cond12 != ' ') {
                    if ((cond2 == '>')
                        || (cond2 == '<'))
                        tmp2 = -tmp2 - flash4.hyst2[ix];
                    if ((cond2 == '=') || (cond2 == '&')) {
                        ctmp2 = 1 - ctmp2;      // 2nd hyst. condition opposite of set cond
                    } else if (tmp2 > 0) {
                        ctmp2 = 1;      // 2nd hysteresis condition true
                    } else {
                        ctmp2 = 0;      // 2nd hysteresis condition false
                    }
                }
                // Evaluate final hysteresis condition
                if (((cond12 == '&') && (ctmp1 || ctmp2)) ||
                    ((cond12 == '|') && (ctmp1 && ctmp2)) ||
                    ((cond12 == ' ') && ctmp1)) {
                    char pv;
                    pv = 1 - flash4.port_val[ix];
                    if (lst_pval[ix] != pv) {
                        set_spr_port((char) ix, pv);
                        lst_pval[ix] = pv;
                    }
                }
            }                   // end eval of hysteresis conditions
        }                       // end if spr_port
    }
    if ((flash4.port_generic != 0) && (flash4.can_poll) && (flash4.enable_poll & 0x08) && flash4.ports_dir) {
        // Remote port settings is enabled
        remote_spr_ports();
    }
}

void handle_ovflo(void)
{
    // check for long timers
    if (wheeldec_ovflo) {
        unsigned long wotmp;

        while ((TCNT > 0xfff8) || (TCNT < 6)) { ; } // make sure not right at rollover

        wotmp = ((unsigned long)swtimer<<16) | TCNT;

        /* SPK and DWL removed as no longer used */
        if (wheeldec_ovflo & OVFLO_ROT_DWL) {
            if ((dwl_time_ovflo_trl.time_32_bits - wotmp) < 0x10000) {
                TC_rotINJ3 = dwl_time_ovflo_trl.time_16_bits[1];
                TFLG1 = TFLG_rotINJ3;
                TIE |= TFLG_rotINJ3;
                wheeldec_ovflo &= ~OVFLO_ROT_DWL;   // done overflow
            }
        }

        if (wheeldec_ovflo & OVFLO_ROT_SPK) {
            if ((spk_time_ovflo_trl.time_32_bits - wotmp) < 0x10000) {
                TC_rotINJ4 = spk_time_ovflo_trl.time_16_bits[1];
                TFLG1 = TFLG_rotINJ4;
                TIE |= TFLG_rotINJ4;
                wheeldec_ovflo &= ~OVFLO_ROT_SPK;
            }
        }
    }
}

void ck_log_clr(void)
{
/* Check for clearing trigger/tooth logger buffer */
    if (flagbyte5 & FLAGBYTE5_LOG_CLR) {
        if ((page >= 0xf0) && (page <= 0xf3)) { // double check
            __asm__ __volatile__ (
            "ldd   #512\n"
            "tthclr:\n"
            "movw   #0, 2,y+\n"
            "dbne   d, tthclr\n"
            : 
            : "y"(ram_data)
            : "d");
        }
        log_offset = 0;
        if (page == 0xf0) {
            flagbyte0 |= FLAGBYTE0_TTHLOG;
        } else if (page == 0xf1) {
            flagbyte0 |= FLAGBYTE0_TRGLOG;
        } else if ((page == 0xf2) || (page == 0xf3)) {
            flagbyte0 |= FLAGBYTE0_COMPLOG;
        } else if (page == 0xf4) {
            flagbyte0 |= FLAGBYTE0_MAPLOGARM; // gets started in ISR
        } else if (page == 0xf5) {
            flagbyte0 |= FLAGBYTE0_MAFLOGARM; // gets started in ISR
        } else if ((page == 0xf6) || (page == 0xf7) || (page == 0xf8)) {
            flagbyte0 |= FLAGBYTE0_ENGLOG;
        }
        flagbyte5 &= ~FLAGBYTE5_LOG_CLR;
    }
}

long long_abs(long in)
{
    if (in < 0) {
        return -in;
    } else {
        return in;
    }
}

#define FLEX_ERR_MAX 100      /* count of out of range readings allowed, before flagging error (circa 10s) */
#define FREQ_TOL 50         /* out of range tolerance (5Hz) */
void calc_flexfuel()
{
    int FSensFreq = 0, minfreq, maxfreq;
    unsigned char new_data = 0;

    /* get min/max in higher precision */
    minfreq = flash4.fuelFreq[0] * 10;
    maxfreq = flash4.fuelFreq[1] * 10;

	if (flash4.FlexFuel & 0x8)  {
		// Remote port
		unsigned int tmppwm;
		tmppwm = outpc.gpiopwmin[(flash4.FlexFuel & 0x06) >>1];
		if (tmppwm > 0)  {
			tmppwm >>= remotePWMscale;
			FSensFreq = (int)(remotePWMfreq / tmppwm);   // Hz
			new_data = 1;
		}
		/* NOTE: No failsafe for absent data. */

	} else {
		// Local port
        if (flagbyte22 & FLAGBYTE22_FLEX) { // new pulse ?
            DISABLE_INTERRUPTS;
            flagbyte22 &= ~FLAGBYTE22_FLEX;
            ENABLE_INTERRUPTS;

            flex_accum += FSens_Pd;
            flex_count++;

#define FLEX_TIME 1953
/* Ticks to accumulate up to. This is 6 samples at 50Hz or 18 samples at 150Hz
   gives a more steady calculation interval of circa 250ms */
            if (flex_accum >= FLEX_TIME) {
                FSensFreq = (78125L * flex_count) / flex_accum;    // 0.1Hz, (FSens_Pd in .128 tics)
                flex_count = 0;
                flex_accum = 0;
                new_data = 1;
            }
        }
	}

	if (new_data > 0) {
		unsigned char bad;

        bad = 0;
        if ((FSensFreq < (minfreq - FREQ_TOL)) || (FSensFreq > (maxfreq + FREQ_TOL))) {
            bad = 1; /* invalid frequency, cannot be true */
            /* Sensor fell off should be detected after one measurement period. */
        }

        if (bad) {
            if (flex_err_cnt < FLEX_ERR_MAX) {
                flex_err_cnt++;
            }

            /* bad readings for too long, use defaults and report error */
            if ((flex_err_cnt >= FLEX_ERR_MAX) && (outpc.seconds > 3)) { // give it a chance to start.

                outpc.fuel_pct = 10; // fault condition.
                /* 1% is never going to happen. Should be a safe default for anyone using blended spark tables. */
                outpc.fuelcor = flash4.fuelCorr_default;
                outpc.flex_advance = flash4.fuelSpkDel_default;
            }
        } else { /* not bad */
            /* Get here if we have a valid frequency that we want to process. */
            int eth_pct_new; /* higher precision used internally */
            int eth_delta, eth_max_min;
            int tmp_fuel, tmp_spark, base_fuel, base_spark;

            if (flex_err_cnt) {
                flex_err_cnt--;
            }

            /* We've already checked that the freq isn't wildly out of range, so now rail to min/max */
            if (FSensFreq < minfreq) {
                FSensFreq = minfreq;
            } else if (FSensFreq > maxfreq) {
                FSensFreq = maxfreq;
            } /* no else */

            /* calculate ethanol% */
            eth_pct_new = flash4.fuel_pct[0]
                + ( ((unsigned long) (FSensFreq - minfreq) * (flash4.fuel_pct[1] - flash4.fuel_pct[0]))
                / (maxfreq - minfreq) ); // %

            /* IIR filter on eth% */
#define ETH_BITSHIFT 4 /* 16 */
            if (outpc.seconds <= 3) { /* to begin with, use current value */
                eth_pct_accum = eth_pct_new << ETH_BITSHIFT;
            } else { /* later, use good smoothing */
            /* 15/16 of accumulated value + 1/16 of new value */
                eth_pct_accum = eth_pct_accum - (eth_pct_accum >> ETH_BITSHIFT) + eth_pct_new;
            }

            outpc.fuel_pct = eth_pct_accum >> ETH_BITSHIFT; /* divide to give output low precision value */

            /* now calculate fuel/spark modifiers based on this ethanol percentage, use higher precision value */
            eth_delta = eth_pct_accum - (flash4.fuel_pct[0] << ETH_BITSHIFT);
            eth_max_min = (flash4.fuel_pct[1] - flash4.fuel_pct[0]) << ETH_BITSHIFT;

            tmp_fuel = flash4.fuelCorr[0] + (((long)eth_delta * (flash4.fuelCorr[1] - flash4.fuelCorr[0])) / eth_max_min);      // %
            tmp_spark = flash4.ffSpkDel[0] + (((long)eth_delta * (flash4.ffSpkDel[1] - flash4.ffSpkDel[0])) / eth_max_min);    // degx10

            if (flash4.flex_baseline) {
                int base_delta, base_max_min;

                base_delta = flash4.flex_baseline - flash4.fuel_pct[0];
                base_max_min = flash4.fuel_pct[1] - flash4.fuel_pct[0];

                base_fuel = flash4.fuelCorr[0]
                    + (((long)base_delta * (flash4.fuelCorr[1] - flash4.fuelCorr[0])) / base_max_min);      // %
                base_spark = flash4.ffSpkDel[0]
                    + (((long)base_delta * (flash4.ffSpkDel[1] - flash4.ffSpkDel[0])) / base_max_min);    // degx10

                outpc.fuelcor = (tmp_fuel * 100L) / base_fuel;
                outpc.flex_advance = tmp_spark - base_spark;
            } else {
                outpc.fuelcor = tmp_fuel;
                outpc.flex_advance = tmp_spark;
            }
        }
	}
}

unsigned int maflookup(unsigned int adcval)
{
    return maffactor_table[adcval];
}

int calc_deadzone_sliding_window(char window, int value, int value_last) {
    int t;

    window /= 2;
    t = value - value_last;
    if (t <= window && t >= -window) {
         /*
          * Within the window.  Stay put.
          */
         return(value_last);
    }
    /*
     * Outside the window.  Return the centre of the window whose outer
     * limit is the latest value.
     */
    return(value + (t < 0 ? window : -window));
}

/* The following variable is a global local, it should be the only one and as
   a result will be the last variable allocated, so most exposed to the stack. */
unsigned int stack_watch_var;

void stack_watch_init(void)
{
    stack_watch_var = 0;
}

void stack_watch(void)
{
    if (stack_watch_var != 0) {
        conf_err = 153;
    }
}

unsigned int do_testmode(void)
{
    /* return codes :
        0 = ok
        1 = BUSY (not allowed)
        2 = invalid mode
     */

    if (datax1.testmodemode == 0) {
        flagbyte1 &= ~flagbyte1_tstmode; /* disable test mode */
        outpc.status3 &= ~STATUS3_TESTMODE;
        testmode_glob = 0;
        pin_testio = 0;
    } else if (datax1.testmodemode == 1) {
        flagbyte1 |= flagbyte1_tstmode; /* enable test mode */
        outpc.status3 |= STATUS3_TESTMODE;
        testmode_glob = 0;
        // accept the test mode and return ok
        return 0;
    } else if (flagbyte1 & flagbyte1_tstmode) {
        // only allow test modes to run when enabled
        if (datax1.testmodemode == 2) { // coil testing
            if (outpc.rpm != 0) {
                return 1;
            } else {
                // enable the mode
                testmode_glob = 1;
                return 0;
            }
        } else if (datax1.testmodemode == 3) { // inj testing
            if (outpc.rpm != 0) {
                return 1;
            } else {
                // enable the mode
                testmode_cnt = pg8_ptr->testinjcnt;
                testmode_glob = 2;
                return 0;
            }
        // 4 not used
        } else if (datax1.testmodemode == 5) { // FP on
            PORTE |= 0x10;
            outpc.engine |= ENGINE_READY;
        } else if (datax1.testmodemode == 6) { // FP off
            PORTE &= ~0x10;
            outpc.engine &= ~ENGINE_READY;
        } else if (datax1.testmodemode == 7) { // Cancel inj or spk
            testmode_glob = 0;
            outpc.istatus5 = 0; // testmode injection counter

        } else if (datax1.testmodemode & 0x80) { // I/O ports
            unsigned char ioport, ioport_mode;
            ioport = datax1.testmodemode & 0x7c;
            ioport_mode = datax1.testmodemode & 0x03;
            if (ioport == 0x00) { // PM3
                DDRM |= 0x08;
                port_testio = (unsigned char*)&PTM;
                pin_testio = 0x08;
            } else if (ioport == 0x04) { // PM4
                DDRM |= 0x10;
                port_testio = (unsigned char*)&PTM;
                pin_testio = 0x10;
            } else if (ioport == 0x08) { // PM5
                DDRM |= 0x20;
                port_testio = (unsigned char*)&PTM;
                pin_testio = 0x20;
#ifdef MICROSQUIRT
            } else if (ioport == 0x0c) { // PT6
                DDRT |= 0x40;
                port_testio = (unsigned char*)&PTT;
                pin_testio = 0x40;
            } else if (ioport == 0x10) { // PT7
                DDRT |= 0x80;
                port_testio = (unsigned char*)&PTT;
                pin_testio = 0x80;
#else // transposed on MS2
            } else if (ioport == 0x10) { // PT6
                DDRT |= 0x40;
                port_testio = (unsigned char*)&PTT;
                pin_testio = 0x40;
            } else if (ioport == 0x0c) { // PT7
                DDRT |= 0x80;
                port_testio = (unsigned char*)&PTT;
                pin_testio = 0x80;
#endif
            } else if (ioport == 0x14) { // PT5
                DDRT |= 0x20;
                port_testio = (unsigned char*)&PTT;
                pin_testio = 0x20;
            } else if (ioport == 0x18) { // PA0
                DDRA |= 0x01;
                port_testio = (unsigned char*)&PORTA;
                pin_testio = 0x01;
            } else if (ioport == 0x1c) { // PM2
                DDRM |= 0x04;
                port_testio = (unsigned char*)&PTM;
                pin_testio = 0x04;
            } else {
                port_testio = (unsigned char*)&dummyReg;
                pin_testio = 0;
            }

            testmode_glob = 0;
            if (ioport_mode == 0) {
                DISABLE_INTERRUPTS;
                *port_testio &= ~pin_testio;
                ENABLE_INTERRUPTS;
            } else if (ioport_mode == 2) {
                testmode_glob = 3;
            } else if (ioport_mode == 3) {
                DISABLE_INTERRUPTS;
                *port_testio |= pin_testio;
                ENABLE_INTERRUPTS;
            }

        } else { // invalid mode
            return 2;
        }
    } else {
        /* IAC tests do not require and not possible when in inj/spk test mode */
        if (datax1.testmodemode == 8) { // Cancel IAC test
            iactest_glob = 0;
            if ((outpc.rpm == 0) && ((IdleCtl == 4) || (IdleCtl == 6))) {
                pwmidle_reset = 0;
            }
        } else if (datax1.testmodemode == 9) { // IAC test home
            iactest_glob = 1;
            pwmidle_reset = PWMIDLE_RESET_INIT;
        } else if (datax1.testmodemode == 10) { // IAC test run
            iactest_glob = 3; // nb 2 is used as a holding phase after homing
        } else {
            // tried to run an invalid test when not in test mode?!
            return 2;
        }
    }

    return 0;
}


void ckstall(void)
{
    unsigned long stalltime, stalltime2;

    if (flagbyte2 & flagbyte1_tstmode) {
        return;
    }

    DISABLE_INTERRUPTS;
    stalltime = lmms - ltch_lmms;
    ENABLE_INTERRUPTS;
    if ((outpc.rpm < 3) || (flagbyte2 & flagbyte2_crank_ok)) {
        /* Longer non-running timeout or not yet out of crank mode
            Saves pump bouncing on and off during starting attempt. */
        if (outpc.seconds > (2 + ((unsigned int)flash4.primedelay / 10))) {
            stalltime2 = 3906; // 0.5s, was 2s
        } else {
            /* right at start include the primedelay too */
            stalltime2 = 15625 + (781 * (unsigned int)flash4.primedelay);
        }

    } else {
        /* quick timeout while running */
        stalltime2 = stall_timeout;
    }

    if (stalltime > stalltime2) {
        if (synch & SYNC_SYNCED) {
            DISABLE_INTERRUPTS;
            ign_reset();
            ENABLE_INTERRUPTS;
        }
        clear_all();
    }
}

void clear_all(void)
{
    PORTE &= ~0x10; // Turn off fuel Pump
    if (IdleCtl == 1) {
        *pPTMpin2 &= ~0x04; // ON/OFF idle turned off
    }
    outpc.engine &= ~1;
    outpc.pw1 = 0;
    outpc.pw2 = 0;
    outpc.pw3 = 0;
    outpc.pw4 = 0;
    req_pw1 = 0;
    req_pw2 = 0;
    req_pw3 = 0;
    req_pw4 = 0;
    asecount = 0;
    tcrank_done = 0xffff;
    running_seconds = 0;
    flagbyte2 |= flagbyte2_crank_ok;
    if (!(flash4.EAEOption & 0x01)) {
        outpc.EAEfcor1 = 100;
        outpc.EAEfcor2 = 100;
        outpc.wallfuel1 = 0;
        outpc.wallfuel2 = 0;
        WF1 = 0;
        AWA1 = 0;
        SOA1 = 0;
        WF2 = 0;
        AWA2 = 0;
        SOA2 = 0;
    }
}

void sample_map_tps(char *localflags)
{
    unsigned int utmp1;
    int tmp1;
    unsigned int map_local, maf_local;

    if (((flagbyte3 & flagbyte3_samplemap) &&
        !(flash4.mapsample_opt & MAPSAMPLE_OPT_USE_AVG)) ||
        ((flagbyte11 & FLAGBYTE11_MAP_AVG_RDY) &&
         (flash4.mapsample_opt & MAPSAMPLE_OPT_USE_AVG))) {
        /* Need to make these for correct behaviour */
        volatile unsigned long map_sum_local, maf_sum_local;
        volatile unsigned int map_cnt_local, maf_cnt_local;

        *localflags |= LOCALFLAGS_RUNFUEL;

        if (flash4.mapsample_opt & MAPSAMPLE_OPT_USE_AVG) {
            DISABLE_INTERRUPTS;
            map_sum_local = map_sum;
            map_cnt_local = map_cnt;
            maf_sum_local = maf_sum;
            maf_cnt_local = maf_cnt;
            flagbyte3 &= ~flagbyte3_samplemap;
            flagbyte11 &= ~FLAGBYTE11_MAP_AVG_RDY;
            ENABLE_INTERRUPTS;
            map_local = (int)(map_sum_local / (unsigned long)map_cnt_local);
        } else {
            DISABLE_INTERRUPTS;
            map_local = map_temp;
            maf_sum_local = maf_sum;
            maf_cnt_local = maf_cnt;
            flagbyte3 &= ~flagbyte3_samplemap;
            ENABLE_INTERRUPTS;
        }
        maf_local = (int)(maf_sum_local / maf_cnt_local);

        if (map_local == 0) {
            /* Can occur on first sample, take a direct reading */
            map_local = ATD0DR0;
        }

        if (flagbyte20 & FLAGBYTE20_USE_MAP) { // only process if MAP enabled
            __asm__ __volatile__ (
                    "ldd    %1\n"
                    "subd   %2\n"
                    "ldy    %3\n"
                    "emul\n"
                    "ldx    #1023\n"
                    "ediv\n"
                    "tfr    y,d\n"
                    "addd   %2\n"
                    : "=d"(utmp1)
                    : "m"(flash4.mapmax),
                    "m"(flash4.map0),
                    //"m"(ATD0DR0)
                    "m"(map_local)
                    : "y", "x");

            __asm__ __volatile__ (
                    "ldd    %1\n"
                    "subd   %3\n"
                    "tfr    d,y\n"
                    "clra\n"
                    "ldab    %2\n"      // it is a uchar
                    "emuls\n"
                    "ldx     #100\n"
                    "edivs\n"
                    "tfr     y,d\n"
                    "addd    %3\n"
                    : "=d"(outpc.map)
                    : "m"(utmp1),
                    "m"(flash4.mapLF),
                    "m"(outpc.map)
                    : "x", "y" );
        }

        if (flagbyte6 & FLAGBYTE6_USE_MAF) {

            //                utmp1 = maffactor_table[maf_local]; // this will NOT work here
            outpc.maf_volts = (5000L * maf_local) / 1023; // 0.001V

            if (flash4.feature7 & 0x04) { /* old calibration table */
                utmp1 = maflookup(maf_local);
            } else {
                utmp1 = intrp_1ditable(outpc.maf_volts, 64, (int *)flash12.mafv, 0, (unsigned int *)
                    flash12.mafflow);
            }

            __asm__ __volatile__(
                    "ldd    %1\n"
                    "subd   %3\n"
                    "tfr    d,y\n"
                    "clra\n"
                    "ldab    %2\n" // it is a uchar
                    "emuls\n"
                    "ldx     #100\n"
                    "edivs\n"
                    "tfr   y,d\n"
                    "addd    %3\n"
                    :"=d"(mafraw)
                    :"m"(utmp1), "m"(flash4.mafLF), "m"(mafraw)
                    :"x", "y");

            if (flash4.feature7 & 0x04) { /* old correction table */
                /* this is the new code with the unsigned X axis lookup */
                utmp1 = intrp_1dctableu(mafraw, 12, (int *)flash9.MAFFlow, 0, (unsigned char *)
                        flash9.MAFCor);
                outpc.maf = ((unsigned long)mafraw * utmp1) / 100;
            } else {
                outpc.maf = mafraw;
            }

            /* outpc.aircor is in 0.1 units in MS2/Extra and MS3 */
            if (outpc.rpm > 5) { // ensure that 1,2 rpm don't give a bogus huge MAFload value
                unsigned long scaled_maf = outpc.maf * ((flash4.maf_range & 0x03) + 1);
                outpc.mafload = (int)(((unsigned long)(MAFCoef / outpc.aircor) * scaled_maf) / outpc.rpm);
                mafload_no_air = (int)(((unsigned long)(MAFCoef / 1000) * scaled_maf) / outpc.rpm);
            } else {
                outpc.mafload = 1000;
                mafload_no_air = 1000;
            }
        }

        // mapdot
        if (mapsample_time > 78) { // minimum 10ms
            volatile unsigned int tmp_mapsample_time; /* volatile required */
            DISABLE_INTERRUPTS;
            tmp_mapsample_time = mapsample_time;
            mapsample_time = 0;
            ENABLE_INTERRUPTS;
            if (flagbyte6 & FLAGBYTE6_USE_MAF_ONLY) {
                /* not using real MAP anywhere, use mafload for mapdot */
                map_local = outpc.mafload;
            } else {
                map_local = outpc.map;
            }

            outpc.mapdot = (781L * ((int)map_local - last_map)) / (int)tmp_mapsample_time;
            last_map = map_local;
        }
    }


    // perform lag factors in mainloop instead of chewing time in interrupt
    if (flagbyte20 & FLAGBYTE20_50MS) {
        unsigned int tmp_tpssample_time, raw_tps;
        unsigned int raw_tps_accum;

        DISABLE_INTERRUPTS;
        flagbyte20 &= ~FLAGBYTE20_50MS; // clear flag
        tmp_tpssample_time = tpssample_time;
        tpssample_time = 0;
        raw_tps_accum = tps_ring[0];
        raw_tps_accum += tps_ring[1];
        raw_tps_accum += tps_ring[2];
        raw_tps_accum += tps_ring[3];
        raw_tps_accum += tps_ring[4];
        raw_tps_accum += tps_ring[5];
        raw_tps_accum += tps_ring[6];
        raw_tps_accum += tps_ring[7];
        ENABLE_INTERRUPTS;

        raw_tps = raw_tps_accum >> 3;

        outpc.tpsadc = raw_tps; // send back for TPS calib

        // get map, tps
        // map, tps lag(IIR) filters

        __asm__ __volatile__ (
                "ldd %3\n"
                "subd %2\n"
                "tfr  d,y\n"
                "ldd  %1\n"
                "subd %2\n"
                "pshd\n"
                "ldd #1000\n"
                "emuls\n"
                "pulx\n"
                "edivs\n"
                : "=y"(tmp1)
                : "m"(flash4.tpsmax),
                "m"(flash4.tps0),
                "m"(raw_tps)
                : "d", "x");

        __asm__ __volatile__ (
                "ldd    %1\n"
                "subd   %3\n"
                "tfr    d,y\n"
                "clra\n"
                "ldab    %2\n"      // it is a uchar
                "emuls\n"
                "ldx     #100\n"
                "edivs\n"
                "tfr     y,d\n"
                "addd    %3\n"
                : "=d"(outpc.tps)
                : "m"(tmp1),
                "m"(flash4.tpsLF),
                "m"(outpc.tps)
                : "x", "y" );

        tmp1 = outpc.tps;
        if (flash4.feature7 & 0x10) {
            /* use TPSwot curve to ignore TPS > WOT vs. RPM */
            int tps_max;
            tps_max = intrp_1ditable(outpc.rpm, 6,
                     (unsigned int *) flash12.tpswot_rpm, 1,
                     (int *) flash12.tpswot_tps);
            if (tmp1 > tps_max) {
                tmp1 = tps_max;
            }

            /* scale tmp1 as 0-tps_max */
            tmp1 = (tmp1 * 1000L) / tps_max;

        }

            /* sliding windows */

            /* tpsdot calc - sliding window - variable dataset and max sample rate */
            tpsdot_data[0][0] = (unsigned int)lmms; /* store actual 16 bit time to first pt in array */
            tpsdot_data[0][1] = tmp1; /* w/o extra bits */

            /* minimum 10ms between samples */
            if ((tpsdot_data[0][0] - tpsdot_data[1][0]) > 78) {
                int tpsi, samples, a, b;
                long toprow, btmrow;

                /* decide how many samples to use based on rate from last two points
                    miniumum is three, max is TPSDOT_N (20)
                */
                a = tpsdot_data[0][1] - tpsdot_data[1][1];
                b = tpsdot_data[0][0] - tpsdot_data[1][0];
                a = (int)((7812L * a) / b);
                a = long_abs(a);

                if (a > 2500) { // 250%/s
                    samples = 3;
                } else if (a > 1000) {
                    samples = 4;
                } else {
                    samples = 5;
                }

    /* note that this only uses first and last, so doesn't fully benefit from the over-sampling */
                toprow = (int)tpsdot_data[0][1] - (int)tpsdot_data[samples - 1][1];
                btmrow = tpsdot_data[0][0] - tpsdot_data[samples - 1][0];    

                btmrow = btmrow / 10; /* allows top row to be 10x less to reduce overflow. */
                toprow = (toprow * 781) / btmrow;
                if (toprow > 32767) {
                    toprow = 32767;
                } else if (toprow < -32767) {
                    toprow = -32767;
                }

                toprow = 50L * (toprow - outpc.tpsdot); /* now 50% lag */
                if ((toprow > 0) && (toprow < 100)) {
                    toprow = 100;
                } else if ((toprow < 0) && (toprow > -100)) {
                    toprow = -100;
                }

                outpc.tpsdot += (int)(toprow / 100);

                /* shuffle data forwards by one */
                for (tpsi = TPSDOT_N - 1; tpsi > 0 ; tpsi--) {
                    tpsdot_data[tpsi][0] = tpsdot_data[tpsi - 1][0];
                    tpsdot_data[tpsi][1] = tpsdot_data[tpsi - 1][1];
                }
            }

            /* end sliding window */

        ego_get_sample();
    }
}

void shifter()
{
    /**************************************************************************
     ** Bike type ignition cut on shift and optional air-shift output
     **************************************************************************/
    if ((flash12.shift_cut_on & 1) == 0) {
        outpc.status3 &= ~STATUS3_BIKESHIFT;
        return;
    }
    // state machine
    if (shift_cut_phase == 0) {
        if ((outpc.rpm > flash12.shift_cut_rpm) && (outpc.tps > flash12.shift_cut_tps) &&   // base conditions AND
            ((pin_shift_cut_in && ((*port_shift_cut_in & pin_shift_cut_in) == pin_shift_cut_match))  // button pressed
             ) ) {
            shift_cut_phase = 1;
            DISABLE_INTERRUPTS;
            *port_shift_cut_out |= pin_shift_cut_out; // enable solenoid
            ENABLE_INTERRUPTS;
            shift_cut_timer = flash12.shift_cut_delay;
        }
    } else if ((shift_cut_phase == 1) && (shift_cut_timer == 0)) {
        shift_cut_timer = flash12.shift_cut_time;
        shift_cut_phase = 2;
    } else if (shift_cut_phase == 2) {            
        if (shift_cut_timer == 0) {
            shift_cut_timer = flash12.shift_cut_soldelay;
            shift_cut_phase = 3;
        } else {
            flagbyte20 |= FLAGBYTE20_SPKCUTTMP; // have to do this every loop
            spkcut_thresh_tmp = 255; //full cut
        }
    } else if ((shift_cut_phase == 3) && (shift_cut_timer == 0)) {
        DISABLE_INTERRUPTS;
        *port_shift_cut_out &= ~pin_shift_cut_out; // disable solenoid
        ENABLE_INTERRUPTS;
        shift_cut_timer = flash12.shift_cut_reshift;
        shift_cut_phase = 4;
    } else if ((shift_cut_phase == 4) && (shift_cut_timer == 0)) {
        //check button not already pressed
        if (pin_shift_cut_in && ((*port_shift_cut_in & pin_shift_cut_in) != pin_shift_cut_match)) {
            shift_cut_phase = 0; // back to the start
        }
    }
    if (shift_cut_phase) {
        outpc.status3 |= STATUS3_BIKESHIFT;
    } else {
        outpc.status3 &= ~STATUS3_BIKESHIFT;
    }
}
