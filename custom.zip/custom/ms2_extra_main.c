/* $Id: ms2_extra_main.c,v 1.358 2019/05/09 12:30:42 jsmcortina Exp $
 * Copyright 2006, 2007, 2008, 2009, 2010, 2011, 2012, 2013
 * James Murray and Kenneth Culver
 *
 * This file is a part of MS2/Extra.
 *
 * main()
    Origin: Al Grippo
    Major: Re-write, split up. James Murray / Kenneth Culver
           Add sequential fuel. Jean Belanger
    Majority: James Murray / Kenneth Culver / Jean Belanger
 *
 * You should have received a copy of the code LICENSE along with this source,
 * ask on the www.msextra.com forum if you did not.
 *
 **   This header must appear on all derivatives of this code.
 **
 ***************************************************************************
 **************************************************************************/

/*************************************************************************
 **************************************************************************
 **   M E G A S Q U I R T  II - 2 0 0 4 - V1.000
 **
 **   (C) 2003 - B. A. Bowling And A. C. Grippo
 **
 **   This header must appear on all derivatives of this code.
 **
 ***************************************************************************
 **************************************************************************/

/*************************************************************************
 **************************************************************************
 **   GCC Port
 **
 **   (C) 2004,2005 - Philip L Johnson
 **
 **   This header must appear on all derivatives of this code.
 **
 ***************************************************************************
 **************************************************************************/

/* Historical ChangeLog moved to ChangeLog-older */

#include "ms2_extra.h"
#include "cltfactor.inc"
#include "matfactor.inc"
#include "egofactor.inc"
#include "maffactor.inc"

char ram_data[1024];

#include "ms2_extra_main_vectors.h"
#include "ms2_extra_main_defaults.h"
#include "ms2_extra_main_decls.h"

int main(void)
{
    int tmp1=0,tmp2=0,tmp3 = 0,tmp4,wrmtmp,tpsatmp,tpsaccel_end=0,ae_scaler;
    unsigned int utmp1;
    long lsum=0,lsum1=0,lsum2=0;
    unsigned int tASTol = 0;
    unsigned char uctmp, uctmp1, uctmp2, uctmp3, uctmp4, uctmp5, uctmp6;
    unsigned char localflags = 0;
    int local_div;

    tmp_pw1 = tmp_pw2 = tmp_pw3 = tmp_pw4 = 0;

    main_init(); // set up all timers, initialise stuff

    mltimestamp = TCNT;
    //  main loop
    for (;;)  {
        if (conf_err != 0) {
            configerror();          // only returns for errors >= 190
        }
        outpc.looptime = (outpc.looptime + TCNT - mltimestamp)>>1; // rolling avg
        mltimestamp = TCNT;

        stack_watch();

        //reset COP timer (That's Computer Operating Properly, not Coil On Plug...)
        ARMCOP = 0x55;
        ARMCOP = 0xAA;

        serial();
        injpwms(); // also calc PWM duties
        if (!(flagbyte15 & FLAGBYTE15_DONEPRIME)) {
            do_prime();
        }

        if (flagbyte1 & flagbyte1_tstmode) {
            get_adc(4,4); // do update battery voltage for display
            goto SKIP_THE_LOT;  // in special test mode don't do any of normal mainloop
        }

        sample_map_tps(&localflags);

        /* Noise Filter Table Lookup */
        noisefilter_lookup(); 

        if (((unsigned int)lmms - adc_lmms) > 78)  {          // every 10 ms (78 x .128 ms clk)
            adc_lmms = (unsigned int)lmms;
            // read 10-bit ADC results, convert to engineering units and filter
            next_adc++;
            if (next_adc > 7) {
                next_adc = 1;
            }
            if ((next_adc == 1) || (next_adc == 2) || (next_adc == 4)) {
                get_adc(next_adc,next_adc);    // get one channel on each pass
            } else if (next_adc >= 6) {
                get_adc(next_adc,next_adc);      // get one channel on each pass
            }
        }

        if ((localflags & LOCALFLAGS_RUNFUEL) || (outpc.engine & ENGINE_CRANK)) {

            if(flash4.BaroOption == 0)  {
                outpc.barocor = 1000;
            } else {                                     // barometric correction (%)
                outpc.barocor = barocor_eq(outpc.baro) + intrp_1ditable(outpc.baro,
                        NO_BARS, (int *)flash12.BaroVals, 1, (unsigned int *)flash12.BaroCorDel);
            }

            if ((flash10.feature3 & 0x40) && (outpc.engine & ENGINE_ASE)) {
                outpc.aircor = 1000;
                outpc.airtemp = outpc.mat;  // use raw MAT in this mode
            } else {
                unsigned int flow; // beware of signed ness of function if flow > 32767
                unsigned long flowtmp;

                flowtmp = (unsigned long)outpc.fuelload * outpc.rpm;
                flowtmp /= 1000; // 10 for fuelload. 100 for 0.01 final units
                flowtmp *= outpc.vecurr1;

                flow = (unsigned int) (flowtmp / 1000UL); // normalise VE

                // use MAT/CLT scaling for a temporary mat value
                tmp1 = intrp_1ditable(flow, 6, (int *)flash9.matclt_flow, 0, (unsigned int *)flash9.matclt_pct);    // returns %clt * 100

                outpc.airtemp = (int) ((((long) outpc.mat * (10000 - tmp1)) + ((long) outpc.clt * tmp1)) / 10000L);  // 'corrected' MAT

                // airdensity correction (%)
                outpc.aircor = intrp_1ditable(outpc.airtemp, NO_MATS, (int *)flash12.MatVals, 1,
                                (unsigned int *)flash12.AirCorDel);
                // ...  = aircor_eq(tmp2) + ... removed
            }

            tmp1 = outpc.map;

            serial();
            uctmp1 = flash4.FuelAlgorithm & 0xF;
            uctmp2 = flash4.FuelAlgorithm & 0xF0;
            uctmp3 = flash4.IgnAlgorithm & 0xF;
            uctmp4 = flash4.IgnAlgorithm & 0xF0;
            uctmp5 = flash4.extra_load_opts & 0xF;
            uctmp6 = flash4.extra_load_opts & 0xF0;
            if ((uctmp1 == 2) || (uctmp2 == 0x20) ||
                    (uctmp1 == 6) || (uctmp2 == 0x60) ||
                    (uctmp3 == 2) || (uctmp4 == 0x20) ||
                    (uctmp3 == 6) || (uctmp4 == 0x60) ||
                    (uctmp5 == 2) || (uctmp5 == 6) ||
                    (uctmp6 == 0x20) || (uctmp6 == 0x60)) {

                tmp2 = (int) (((long) tmp1 * 1000) / outpc.baro);
            }

            if ((uctmp1 == 6) || (uctmp2 == 0x60) ||
                    (uctmp3 == 6) || (uctmp4 == 0x60) ||
                    (uctmp5 == 6) || (uctmp6 == 0x60)) {
                tmp3 = calc_ITB_load(tmp2);
            }

            /* Fuel Load 1 */
            if (uctmp1 == 1) {
                outpc.fuelload = tmp1;  // kpa x 10, speed density
            } else if (uctmp1 == 2) {
                outpc.fuelload = tmp2; // % baro
            } else if (uctmp1 == 3) {
                outpc.fuelload = outpc.tps; // alpha-n
            } else if (uctmp1 == 4 || uctmp1 == 5) { // maf or mafload
                outpc.fuelload = outpc.mafload;
            } else if (uctmp1 == 6) { // ITB
                outpc.fuelload = tmp3;
            } else {
                /* somehow something is set wrong, just use map */
                outpc.fuelload = outpc.map;
            }

            if (!(flash4.dual_tble_optn & 1)) {
                if (uctmp2 == 0x10) {
                    outpc.fuelload2 = tmp1;
                } else if (uctmp2 == 0x20) {
                    outpc.fuelload2 = tmp2;
                } else if (uctmp2 == 0x30) {
                    outpc.fuelload2 = outpc.tps;
                } else if (uctmp2 == 0x40 || uctmp2 == 0x50) {
                    outpc.fuelload2 = outpc.mafload;
                } else if (uctmp2 == 0x60) {
                    outpc.fuelload2 = tmp3;
                } 
            } else {
                outpc.fuelload2 = outpc.fuelload; // needed for Megatune
            }

            /* Ign Load 1 */
            if (uctmp3 == 1) {
                outpc.ignload = outpc.map;
            } else if (uctmp3 == 2) {
                outpc.ignload = tmp2;
            } else if (uctmp3 == 3) {
                outpc.ignload = outpc.tps;
            } else if (uctmp3 == 4) {
                outpc.ignload = outpc.mafload;
            } else if (uctmp3 == 6) {
                outpc.ignload = tmp3;
            } else {
                outpc.ignload = outpc.fuelload;
            }

            if (uctmp4 == 0x10) {
                outpc.ignload2 = outpc.map;
            } else if (uctmp4 == 0x20) {
                outpc.ignload2 = tmp2;
            } else if (uctmp4 == 0x30) {
                outpc.ignload2 = outpc.tps;
            } else if (uctmp4 == 0x40) {
                outpc.ignload2 = outpc.mafload;
            } else if (uctmp4 == 0x60) {
                outpc.ignload2 = tmp3;
            }
            /* AFR load */
            if (uctmp5 == 1) {
                outpc.afrload = outpc.map;
            } else if (uctmp5 == 2) {
                outpc.afrload = tmp2;
            } else if (uctmp5 == 3) {
                outpc.afrload = outpc.tps;
            } else if (uctmp5 == 4) {
                outpc.afrload = outpc.mafload;
            } else if (uctmp5 == 6) {
                outpc.afrload = tmp3;
            } else {
                outpc.afrload = outpc.fuelload;
            } 

            /* EAEload */
            if (uctmp6 == 0x10) {
                outpc.eaeload = outpc.map;
            } else if (uctmp6 == 0x20) {
                outpc.eaeload = tmp2;
            } else if (uctmp6 == 0x30) {
                outpc.eaeload = outpc.tps;
            } else if (uctmp6 == 0x40) {
                outpc.eaeload = outpc.mafload;
            } else if (uctmp6 == 0x60) {
                outpc.eaeload = tmp3;
            } else {
                outpc.eaeload = outpc.fuelload;
            }
        }

        idle_target_lookup();
        idle_ctl();
        if (flash4.FlexFuel & 0x01)  {
            calc_flexfuel();
        } else {                    // no flex fuel
            outpc.fuelcor = 100;    // %
            outpc.flex_advance = 0;           // degx10
            outpc.fuel_pct = 0;
        }

        /* Shut it down... */
        if ((flagbyte22 & FLAGBYTE22_SHUTDOWNLOCKOUT) == 0) {
            if (datax1.shutdowncode == SHUTDOWN_CODE_ACTIVE) {
                flagbyte22 |= FLAGBYTE22_SHUTDOWNACTIVE;
            } else if (datax1.shutdowncode == SHUTDOWN_CODESPK_ACTIVE) {
                flagbyte22 |= FLAGBYTE22_SHUTDOWNSPKACTIVE;
            } else if (datax1.shutdowncode == (SHUTDOWN_CODE_ACTIVE | SHUTDOWN_CODESPK_ACTIVE)) {
                flagbyte22 |= FLAGBYTE22_SHUTDOWNACTIVE | FLAGBYTE22_SHUTDOWNSPKACTIVE;
            } else if (datax1.shutdowncode == SHUTDOWN_CODE_INACTIVE) {
                flagbyte22 &= ~(FLAGBYTE22_SHUTDOWNACTIVE | FLAGBYTE22_SHUTDOWNSPKACTIVE);
            } else {
                /* Received an invalid code, disable the feature */
                flagbyte22 |= FLAGBYTE22_SHUTDOWNLOCKOUT;
            }
        }

        // check for stall
        if(((outpc.engine & ENGINE_READY) == 0) || (outpc.rpm == 0))goto EVERY_TOOTH;

        // check idle control
        // test mode first - only after stepper init

        /* BOOST CONTROL */
        if (flash5.boost_ctl_settings & BOOST_CTL_ON) {
            boost_ctl();
            if (flash5.boost_ctl_settings & BOOST_CTL_REMOTE) {
                if (outpc.boostduty == 100) {
                    outpc.gpioport[(flash5.boost_ctl_pins>>4) - 1] = 255;
                } else {
                    outpc.gpioport[(flash5.boost_ctl_pins>>4) - 1] = (unsigned char)((((unsigned int)outpc.boostduty)<<8) / 100);
                }
            }
        }

        if (flash4.OverBoostOption & 0x03) {
            if (outpc.map > flash4.OverBoostKpa) {
                outpc.status2 |= STATUS2_OVERBOOST_ACTIVE;
            }

            if ((flash4.OverBoostOption & 0x04) && (flash5.boost_ctl_settings & BOOST_CTL_CLOSED_LOOP)
                && ((outpc.map - outpc.boost_targ) > flash4.boosttol)) {
                outpc.status2 |= STATUS2_OVERBOOST_ACTIVE;
            } else {
                if (outpc.map < (flash4.OverBoostKpa - flash4.OverBoostHyst)) {
                    if ((flash4.OverBoostOption & 0x04) && (flash5.boost_ctl_settings & BOOST_CTL_CLOSED_LOOP)) {
                        if (outpc.map < (outpc.boost_targ + flash4.boosttol - flash4.OverBoostHyst)) {
                            outpc.status2 &= ~STATUS2_OVERBOOST_ACTIVE;
                        }
                    } else {
                        outpc.status2 &= ~STATUS2_OVERBOOST_ACTIVE;
                    }
                }
            }

            if (flash4.OverBoostOption & 0x02) {
                if (outpc.status2 & STATUS2_OVERBOOST_ACTIVE) {
                    spkcut_thresh_tmp = 255; // full cut
                    flagbyte20 |= FLAGBYTE20_SPKCUTTMP;
                }
            }
        }

        shifter();

        /**************************************************************************
         **
         ** Cranking Mode
         **
         ** Pulsewidth is directly set by the coolant temperature to a value of
         **  CWU (at temp_table[0]) and CWH (at temp_table[NO_TEMPS -1]).
         **  The value is interpolated at clt.
         **
         **************************************************************************/
        if ((outpc.rpm < flash4.crank_rpm) && (flagbyte2 & flagbyte2_crank_ok))  {
            unsigned long crpw;
            PulseTol = flash4.CrnkTol;
            if (resetholdoff == 0) {
                tcrank_done = 0xFFFF;
                running_seconds = 0;
            }
            outpc.engine |= ENGINE_CRANK;    // set cranking bit
            outpc.engine &= ~(ENGINE_ASE | ENGINE_WUE);   // clr starting warmup bit & warmup bit
            if(outpc.tps > flash4.TPSWOT)  {
                tmp_pw1 = 0;    // usec  (0 ms for Flood Clear)
                tmp_pw2 = 0;
                tmp_pw3 = 0;
                tmp_pw4 = 0;
                goto KNK;
            }

            // cranking pulse width now uses a %age lookup table calculated from ReqFuel.
            // Hopefully new users can leave this table alone and engine will start
            // Changing injector size is corrected by ReqFuel

            utmp1 = CW_table(outpc.clt,(int *)flash5.CrankPctTable, (int *)flash5.temp_table_p5);

            if ((flash8.seq_inj & 0x03) == 0) {
                // Make adjustment when no sequential/semi-sequential mode is active
                if (flash4.Alternate & 0x02) {
                    utmp1 <<= 1;
                }

                utmp1 /= flash4.Divider;

                if (flash4.Alternate & 0x01) {
                    utmp1 >>= 1;
                }
            }

            crpw = (flash4.ReqFuel * (unsigned long)utmp1) / 100UL;

            if (crpw > 65000) {
                crpw = 65000;
            }
            utmp1 = crpw;

            calc_opentime();

            tmp_pw1 = (unsigned long)utmp1 * 100;
            if (flash4.FlexFuel & 0x01)  {
                tmp_pw1 = ((unsigned long)tmp_pw1 * outpc.fuelcor) / 100;
            }
            tmp_pw2 = tmp_pw1;
            goto CHECK_STAGED;
        } else if (tcrank_done == 0xFFFF) {
            tcrank_done = outpc.seconds;
            DISABLE_INTERRUPTS;
            tcrank_done_lmms = lmms;
            ENABLE_INTERRUPTS;
        } else {
            unsigned char chkhei = 0;
            if ((outpc.seconds > (tcrank_done + 5)) || sync_holdoff) {
                DISABLE_INTERRUPTS;
                flagbyte2 &= ~flagbyte2_crank_ok;
                ENABLE_INTERRUPTS;
                if (sync_holdoff) {
                    chkhei = 1;
                }
            } else if (outpc.seconds > (tcrank_done + 2)) {
                chkhei = 1;
            }
            if (chkhei) {
                if ((spkmode == 2) && (flash4.spk_conf2 & SPK_CONF2_GMBYPASS)) {
                    // Set HEI bypass to 5v - relies on same wiring as main spark output
                    if (flash4.ICIgnOption & 0x10) { /* Going high */
#ifdef MICROSQUIRT
                        PTT |= 0x10;
#else
                        PTM |= 0x10;
#endif
                    } else { /* Going low */
#ifdef MICROSQUIRT
                        PTT &= ~0x10;
#else
                        PTM &= ~0x10;
#endif
                    }
                }
            }
        }

        if ((localflags & LOCALFLAGS_RUNFUEL) || (outpc.engine & ENGINE_CRANK)) {
            /**************************************************************************
             **
             ** Warm-up and After-start Enrichment Section
             **
             ** The Warm-up enrichment is a linear interpolated value for the current clt
             ** temperature from warmen_table[NO_TEMPS] vs temp_table[NO_TEMPS]. The
             ** interpolation is done in subroutine warmcor_table.
             **
             ** Also, the after-start enrichment value is calculated and applied here - it
             **  is an added percent value on top of the warmup enrichment, and it is applied
             **  for the number of ignition cycles specified in ase_cycles. This enrichment starts
             **  at a value of ase_value at first, then it linearly interpolates down to zero
             **  after ase_cycles cycles.
             **
             **  If (startw, engine is set) then:
             **   compare if (ase_cycles > 0) then:
             **    interpolate for warmup enrichment
             **   else clear startw bit in engine
             **
             **************************************************************************/
            wrmtmp = outpc.warmcor;
            if(outpc.engine & ENGINE_CRANK)  {     // if engine cranking
                outpc.engine &= ~ENGINE_CRANK;       // clear crank bit
                if ((resetholdoff == 0) && (sync_holdoff == 0)) {
                    /* not within burn timeout period or just after a high-speed resync - i.e. normal*/
                    outpc.engine |= ENGINE_ASE | ENGINE_WUE;        // set starting warmup bit (ase) & warmup bit
                    asecount = 0;
                }
                PulseTol = flash4.ASTol;
                tASTol = outpc.seconds;

                set_prime_ASE();
                DISABLE_INTERRUPTS;
                running_seconds = 0;
                ENABLE_INTERRUPTS;
            }
            wrmtmp = intrp_1dctable(outpc.clt, NO_TEMPS, (int *)flash4.temp_table, 0,
                    (unsigned char *)flash4.warmen_table);    // %
            outpc.cold_adv_deg = CW_table(outpc.clt,(int *)flash4.cold_adv_table, (int *)flash4.temp_table); // deg x 10

            if(wrmtmp == 100)  {     // done warmup
                outpc.engine &= ~ENGINE_WUE;        // clear start warmup bit (ase) & warmup bit
                *pPTMpin5 &= ~0x20;         // clear warmup led
                if(outpc.seconds > tASTol + 5) {
                    PulseTol = flash4.PulseTol;
                }
            } else {
                *pPTMpin5 |= 0x20;            // set warmup led
                outpc.engine |= ENGINE_WUE;           // set warmup bit
            }
            if(!(outpc.engine & ENGINE_ASE)) {     // if starting warmup bit clear
                goto END_WRM;
            }
            if((asecount > ase_cycles) || (ase_value == 0))  {
                outpc.engine &= ~ENGINE_ASE;        // clear start warmup bit
                if(outpc.seconds > tASTol + 5)
                    PulseTol = flash4.PulseTol;
                goto END_WRM;
            }

            if (ase_cycles > 0) {
                //        utmp1 = (unsigned long)(ase_value * (ase_cycles - asecount)) / ase_cycles;
                __asm__ __volatile__ (
                        "tfr d,x\n"
                        "subd %1\n"
                        "ldy  %2\n"
                        "emul\n"
                        "ediv\n"
                        : "=y" (utmp1)
                        : "m" (asecount), "m" (ase_value), "d" (ase_cycles)
                        : "x"
                        );

                wrmtmp += utmp1;
            }
END_WRM:
            outpc.warmcor = wrmtmp;

            serial();

            /**************************************************************************
             **
             **  Throttle Position Acceleration Enrichment
             **
             **   Method is the following:
             **
             **
             **   ACCELERATION ENRICHMENT:
             **   If (tpsdot < 0) goto DEACCELERATION_ENRICHMENT
             **   If tpsdot > tpsthresh and TPSAEN bit = 0 then (acceleration enrichment):
             **   {
             **    1) Set acceleration mode
             **    2) Continuously determine rate-of-change of throttle, and perform
             **        interpolation of table values to determine acceleration
             **        enrichment amount to apply.
             **   }
             **   If (TPSACLK > TpsAsync) and TPSAEN is set then:
             **   {
             **    1) Clear TPSAEN bit in engine
             **    2) Set TPSACCEL to 0
             **    3) Go to EGO Delta Step Check Section
             **   }
             **   Enrichment tail-off pulsewidth:
             **
             **   ------------------ tpsaccel
             **   |            |\
             **   |            |   \
             **   |            |      \
             **   |            |         \          ____ TpsAccel2
             **   |            |            |
             **   |            |            |
             **   ---------------------------
             **   <--TpsAsync--><-TpsAsync2->
             **
             **
             **   DEACCELERATION ENRICHMENT:
             **   If (-tpsdot) > tpsthresh then (deceleration fuel cut)
             **   {
             **    If (TPSAEN = 1) then:
             **    {
             **      1) TPSACCEL = 0 (no acceleration)
             **      2) Clear TPSAEN bit in ENGINE
             **      3) Go to EGO Delta Step
             **    }
             **    If (RPM > 1500 then (fuel cut mode):
             **    {
             **      1) Set TPSACCEL value to TPSDQ
             **      2) Set TPSDEN bit in ENGINE
             **      3) Go to EGO Delta Step Check Section
             **    }
             **   }
             **   else
             **   {
             **    If (TPSDEN = 1) then
             **    {
             **     1) Clear TPSDEN bit in ENGINE
             **     2) TPSACCEL = 0
             **     3) Go to EGO Delta Step Check Section
             **    }
             **   }
             **
             **************************************************************************/
            /* Hold tight, there's a GOTO storm coming. */
            tpsatmp = outpc.tpsaccel;
            DISABLE_INTERRUPTS;
            tpsdot_ltch = outpc.tpsdot;
            mapdot_ltch = outpc.mapdot;
            ENABLE_INTERRUPTS;
            if ((tpsdot_ltch < 0) && (flash4.Tps_acc_wght != 0)) {
                goto TDE; // decelerating
            }
            if ((mapdot_ltch < 0) && (flash4.Tps_acc_wght != 100)) {
                goto TDE;
            }
            if (outpc.engine & ENGINE_TPSACC) {
                goto AE_COMP_SHOOT_AMT;   // if accel enrich bit set
            }
            if (outpc.engine & ENGINE_MAPACC) {
                goto AE_COMP_SHOOT_AMT;
            }
            if (((flash4.Tps_acc_wght == 0) || (tpsdot_ltch < flash4.TpsThresh))
               && ((flash4.Tps_acc_wght == 100) || (mapdot_ltch < flash4.MapThresh))) {
                goto TAE_CHK_TIME;
            }
            // start out using first element - determine actual next time around
            tpsatmp = (((short)flash4.tpsen_table[0] * flash4.Tps_acc_wght) +
                    ((short)flash4.mapen_table[0] * (100 - flash4.Tps_acc_wght))) / 100;
            tpsaccel_end = tpsatmp;               // latch last tpsaccel before tailoff
            tpsaclk = 0;                    // incremented in .1 sec timer
            if ((tpsdot_ltch > flash4.TpsThresh) && (flash4.Tps_acc_wght != 0)) {
                outpc.engine |= ENGINE_TPSACC;       // set tpsaen bit
            }
            if ((mapdot_ltch > flash4.MapThresh) && (flash4.Tps_acc_wght != 100)) {
                outpc.engine |= ENGINE_MAPACC;
            }
            outpc.engine &= ~ENGINE_TPSDEC;      // clear tpsden bit
            outpc.engine &= ~ENGINE_MAPDEC;
            *pPTMpin4 |= 0x10;        // set accel led
            goto END_TPS;
            /* First, calculate Cold temperature add-on enrichment value from coolant value
               TPSACOLD at min temp & 0 at high temp.

               Then determine cold temperature multiplier value ACCELMULT (in percent).

               Next, Calculate Shoot amount (quantity) for acceleration enrichment from table.
               Find bins (between) for corresponding TPSDOT and MAPDOT, and linear interpolate
               to find enrichment amount from table. This is continuously
               checked every time thru main loop while in acceleration mode,
               and the highest value is latched and used.

               The final acceleration enrichment (in .1 ms units) applied is AE =
               (((Alookup(TPSDOT)*Tps_acc_wght + Alookup(MAPDOT)*(100 - Tps_acc_wght))
               /100) * ACCELMULT/100) + TPSACOLD.
             */

AE_COMP_SHOOT_AMT:

            if (tpsaclk <= flash4.TpsAsync)  {
                tmp1 = (short)flash4.Tpsacold  - (short)((flash4.Tpsacold *
                            (long)(outpc.clt - flash4.temp_table[0]) / (flash4.temp_table[NO_TEMPS-1]
                                - flash4.temp_table[0])));          // in .1 ms
                tmp2 = (short)flash4.AccMult + (short)(((100 - flash4.AccMult) *
                            (long)(outpc.clt - flash4.temp_table[0]) / (flash4.temp_table[NO_TEMPS-1]
                                - flash4.temp_table[0])));          // in %
                if (flash4.Tps_acc_wght > 0) {
                    tmp3 = intrp_1dctable(tpsdot_ltch, NO_TPS_DOTS, (int *)flash4.tpsdot_table, 0,
                            (unsigned char *)flash4.tpsen_table);   // .1 ms units
                } else {
                    tmp3 = 0;
                }
                if (flash4.Tps_acc_wght < 100)  {
                    tmp4 = intrp_1dctable(mapdot_ltch, NO_MAP_DOTS, (int *)flash4.mapdot_table, 0,
                            (unsigned char *)flash4.mapen_table);   // .1 ms units
                } else {
                    tmp4 = 0;
                }
                tmp3 = ((tmp3 * flash4.Tps_acc_wght) + (tmp4 * (100 - flash4.Tps_acc_wght))) / 100;
                tmp3 = (tmp3 * tmp2) / 100;
                if(tmp3 > 200)
                    tmp3 = 200;  // rail at 20 ms
                tmp3 += tmp1;
                if (tmp3 > tpsatmp) {
                    tpsatmp = tmp3; // make > tps/mapen_table entry for lowest tps/mapdot
                }
                // plus latch and hold largest pw
                tpsaccel_end = tpsatmp;         // latch last tpsaccel before tailoff
            } else {      // tailoff enrichment pulsewidth
TAILOFF:
                if (flash4.TpsAsync2 > 0) {
                    tpsatmp = tpsaccel_end + (short)(((flash4.TpsAccel2 - tpsaccel_end) *
                                (long)(tpsaclk - flash4.TpsAsync)) / flash4.TpsAsync2);
                } else {
                    tpsatmp = 0;
                }
            }

TAE_CHK_TIME:
            // check if accel is done
            // if tps decel bit not set, accel bit is
            if ((!(outpc.engine & ENGINE_TPSDEC) && (outpc.engine & ENGINE_TPSACC))
                || (!(outpc.engine & ENGINE_MAPDEC) && (outpc.engine & ENGINE_MAPACC))) {
                if (tpsaclk < (flash4.TpsAsync + flash4.TpsAsync2)) {
                    goto END_TPS;
                }
            }
            goto KILL_ACCEL;

TDE:             // tpsdot < 0
            if ((outpc.engine & ENGINE_TPSACC) || (outpc.engine & ENGINE_MAPACC)) {     // if tps accel bit set
                if ((-tpsdot_ltch) > flash4.TpsThresh) {
                    goto KILL_ACCEL;
                }
                if ((-mapdot_ltch) > flash4.MapThresh) {
                    goto KILL_ACCEL;
                }
                if (tpsaclk < flash4.TpsAsync) {
                    tpsaclk = flash4.TpsAsync;  // just tail off AE
                }
                goto TAILOFF;
            }
            // decel
            if (((-tpsdot_ltch) > flash4.TpsThresh) && (flash4.TPSDQ != 100)
                && (flash4.Tps_acc_wght > 0)) {
                if (outpc.rpm < 1500) {
                    goto END_TPS;
                }
                outpc.tpsfuelcut = flash4.TPSDQ;    // in %
                outpc.engine |= ENGINE_TPSDEC;             // set tps decel bit
                goto END_TPS;
            }
            if (((-mapdot_ltch) > flash4.MapThresh) && (flash4.TPSDQ != 100)
                && (flash4.Tps_acc_wght < 100)) {
                if (outpc.rpm < 1500) {
                    goto END_TPS;
                }
                outpc.tpsfuelcut = flash4.TPSDQ;
                outpc.engine |= ENGINE_MAPDEC;
                goto END_TPS;
            }
            if (outpc.engine & (ENGINE_TPSACC | ENGINE_TPSDEC | ENGINE_MAPACC | ENGINE_MAPDEC))  {     // if decel or just finished accel
KILL_ACCEL:
                outpc.engine &= ~(ENGINE_TPSACC | ENGINE_TPSDEC | ENGINE_MAPACC | ENGINE_MAPDEC);       // clear tps decel, accel bits
                outpc.tpsfuelcut = 100;
                *pPTMpin4 &= ~0x10;        // clear accel led
                tpsatmp = 0;
            }
END_TPS:
            // apply AE rpm-based scaler
            if (outpc.rpm <= flash4.ae_lorpm) {
                ae_scaler =  100;
            } else if (outpc.rpm >= flash4.ae_hirpm) {
                ae_scaler = 0;
            } else {
                ae_scaler = (short)(((long)100 * (flash4.ae_hirpm - outpc.rpm)) /
                        (flash4.ae_hirpm - flash4.ae_lorpm));
            }
            outpc.tpsaccel = (tpsatmp * ae_scaler) / 100;

            /**************************************************************************
             **
             **  Exhaust Gas Oxygen Sensor Measurement Section
             **
             **************************************************************************/
            ego_get_targs_gl();
            ego_get_targs();
            ego_calc();  // this is on page 3d
            /**************************************************************************
             **  Look up volumetric efficiency as function of rpm and map (tps
             **   in alpha N mode)
             **************************************************************************/
            uctmp = 0; //uctmp is local tmp var
            // nitrous control will also use this var as pin behaviour will be different
            if ((flash5.feature5_0 & 2) && (!(flash4.dual_tble_optn & 1))) { // table switching
                if ((flash5.feature5_0 & 0x0c) == 0) {
                    if (flash5.ts_port & 0x08) {
                        // Remote switch
                        if (!(outpc.gpioport[2] & (0x01 << (flash5.ts_port & 0x07)))) {
                            uctmp = 1;
                        }
                    } else if ((flash5.ts_port & 0x0f) == 1) {
                        // Local switch
                        if (!(PORTE & 0x1)) { // PE0/FLEX. Pullup always enabled.
                            uctmp = 1;
                        }
                    } else {
                        // Local switch
                        if (!(PORTE & 0x2)) { // the bastard pin. Pullup always enabled.
                            uctmp = 1;
                        }
                    }
                } else if ((flash5.feature5_0 & 0x0c) == 4) {
                    if (outpc.rpm > flash5.tsf_rpm) {
                        uctmp = 1;
                    }
                } else if ((flash5.feature5_0 & 0x0c) == 8) {
                    if (outpc.map > flash5.tsf_kpa) {
                        uctmp = 1;
                    }
                } else if ((flash5.feature5_0 & 0x0c) == 0xc) {
                    if (outpc.tps > flash5.tsf_tps) {
                        uctmp = 1;
                    }
                }
            }

            if (uctmp) {
                outpc.status1 |= status1_ftblsw;
            } else {
                outpc.status1 &= ~status1_ftblsw;
            }

            if (flash4.feature4_0 & 0x04) { // 12x12 tables
                if ((uctmp == 1) || (((flash8.seq_inj & 0x03) == 3) && (seq_inj_ctrl & SEQ_HYBRID))) {
                    if (((flash4.FuelAlgorithm & 0xf) != 5) || (((flash4.FuelAlgorithm & 0xf) == 5) && (flash4.feature7 & 0x02))) {
                        // using table switching will disable secondary load table
                        // grab VE from table 3
                        outpc.vecurr1 = intrp_2dctable(outpc.rpm, outpc.fuelload, NO_FRPMS, NO_FMAPS,
                                &pg9_ptr->frpm_tables.frpm_tablevS[2][0], &pg9_ptr->fmap_tables.fmap_tablevS[2][0], 
                                (unsigned char *)&pg9_ptr->ve_tables.ve_tableS[2][0][0], 1); // in .1 %
                    } else {
                        /* Pure MAF algorithm takes VE1 as 100% */
                        outpc.vecurr1 = 1000;
                    }
                } else {
                    if (((flash4.FuelAlgorithm & 0xf) != 5) || (((flash4.FuelAlgorithm & 0xf) == 5) && (flash4.feature7 & 0x02))) {
                        tmp1 = intrp_2dctable(outpc.rpm, outpc.fuelload, NO_FRPMS, NO_FMAPS,
                                &pg9_ptr->frpm_tables.frpm_tablevS[0][0], &pg9_ptr->fmap_tables.fmap_tablevS[0][0], 
                                (unsigned char *)&pg9_ptr->ve_tables.ve_tableS[0][0][0], 1); // in .1%
                    } else {
                        /* Pure MAF algorithm takes VE1 as 100% */
                        tmp1 = 1000;
                    }

                    if ((flash4.FuelAlgorithm & 0xF0) && ((flash4.FuelAlgorithm & 0xF0) != 0x50)) {
                        utmp1 = intrp_2dctable(outpc.rpm, outpc.fuelload2, NO_FRPMS, NO_FMAPS,
                                &pg9_ptr->frpm_tables.frpm_tablevS[1][0], &pg9_ptr->fmap_tables.fmap_tablevS[1][0],
                                (unsigned char *)&pg9_ptr->ve_tables.ve_tableS[1][0][0], 1);
                        if (flash4.loadopts & LOADOPTS_FUELMULT) {
                            outpc.vecurr1 = ((long)tmp1 * utmp1) / 1000;
                        } else {
                            outpc.vecurr1 = tmp1 + utmp1;
                        }
                    } else {
                        outpc.vecurr1 = tmp1;
                    }
                }
                // cannot have DT and secondary load tables - check in tuning SW
                if (flash4.dual_tble_optn & 1) {
                    outpc.vecurr2 = intrp_2dctable(outpc.rpm, outpc.fuelload, NO_FRPMS, NO_FMAPS,   // should we use outpc.fuelload2 ?
                            &pg9_ptr->frpm_tables.frpm_tablevS[1][0], &pg9_ptr->fmap_tables.fmap_tablevS[1][0], 
                            (unsigned char *)&pg9_ptr->ve_tables.ve_tableS[1][0][0], 1); // in %
                } else {
                    outpc.vecurr2 = outpc.vecurr1;
                }

                if (((flash8.seq_inj & 0x03) == 3) && (seq_inj_ctrl & SEQ_HYBRID)) {
                    outpc.vecurr2 = 0;
                }
                if ((flash8.seq_inj & 0x03) && (pg8_ptr->seq_inj & 0x10)) {
                    int ix;
                    outpc.vetrim[0] = intrp_2dctable_signed(outpc.rpm, outpc.fuelload, NO_FRPMS, NO_FMAPS,
                            &pg8_ptr->frpm_tables.frpm_trimvS[0], &pg8_ptr->fmap_tables.fmap_trimvS[0], 
                            (unsigned char *)&pg8_ptr->ve_tables.ve_trim1S[0][0]); // in .1 %
                    for (ix = 0; ix < no_inj -1; ix++) {
                        outpc.vetrim[ix+1] = intrp_2dctable_signed(outpc.rpm, outpc.fuelload, NO_FRPMS, NO_FMAPS,
                                &pg11_ptr->frpm_tables.frpm_trimvS[ix][0], &pg11_ptr->fmap_tables.fmap_trimvS[ix][0], 
                                (unsigned char *)&pg11_ptr->ve_tables.ve_trimS[ix][0][0]); // in .1 %
                    }
                    if (flash10.staged & 0x7) {
                        if (no_inj == 1) {
                            outpc.vetrim[1] = outpc.vetrim[0];
                        } else {
                            outpc.vetrim[2] = outpc.vetrim[0];
                            outpc.vetrim[3] = outpc.vetrim[1];
                        }
                    }
                }
            } else {  // 16x16 tables
                if ((uctmp == 1) || (((flash8.seq_inj & 0x03) == 3) && (seq_inj_ctrl & SEQ_HYBRID))) {
                    // using table switching will disable secondary load table
                    // grab VE from table 3
                    if (((flash4.FuelAlgorithm & 0xf) != 5) || (((flash4.FuelAlgorithm & 0xf) == 5) && (flash4.feature7 & 0x02))) {
                        outpc.vecurr1 = intrp_2dctable(outpc.rpm, outpc.fuelload, NO_EXFRPMS, NO_EXFMAPS,
                                &pg9_ptr->frpm_tables.frpm_tablevL[2][0], &pg9_ptr->fmap_tables.fmap_tablevL[2][0], 
                                (unsigned char *)&pg9_ptr->ve_tables.ve_tableL[2][0][0], 1); // in .1 %
                    } else {
                        outpc.vecurr1 = 1000;
                    }
                } else {
                    if (((flash4.FuelAlgorithm & 0xf) != 5) || (((flash4.FuelAlgorithm & 0xf) == 5) && (flash4.feature7 & 0x02))) {
                        tmp1 = intrp_2dctable(outpc.rpm, outpc.fuelload, NO_EXFRPMS, NO_EXFMAPS,
                                &pg9_ptr->frpm_tables.frpm_tablevL[0][0], &pg9_ptr->fmap_tables.fmap_tablevL[0][0], 
                                (unsigned char *)&pg9_ptr->ve_tables.ve_tableL[0][0][0], 1); // in .1%
                    } else {
                        tmp1 = 1000;
                    }

                    if ((flash4.FuelAlgorithm & 0xF0) && ((flash4.FuelAlgorithm & 0xF0) != 0x50)) {
                        utmp1 = intrp_2dctable(outpc.rpm, outpc.fuelload2, NO_EXFRPMS, NO_EXFMAPS,
                                &pg9_ptr->frpm_tables.frpm_tablevL[1][0], &pg9_ptr->fmap_tables.fmap_tablevL[1][0],
                                (unsigned char *)&pg9_ptr->ve_tables.ve_tableL[1][0][0], 1);
                        if (flash4.loadopts & LOADOPTS_FUELMULT) {
                            outpc.vecurr1 = ((long)tmp1 * utmp1) / 1000;
                        } else {
                            outpc.vecurr1 = tmp1 + utmp1;
                        }
                    } else {
                        outpc.vecurr1 = tmp1;
                    }
                }
                // cannot have DT and secondary load tables - check in tuning SW
                if (flash4.dual_tble_optn & 1) {
                    outpc.vecurr2 = intrp_2dctable(outpc.rpm, outpc.fuelload, NO_EXFRPMS, NO_EXFMAPS,
                            &pg9_ptr->frpm_tables.frpm_tablevL[1][0], &pg9_ptr->fmap_tables.fmap_tablevL[1][0], 
                            (unsigned char *)&pg9_ptr->ve_tables.ve_tableL[1][0][0], 1); // in %
                } else {
                    outpc.vecurr2 = outpc.vecurr1;
                }
                if (((flash8.seq_inj & 0x03) == 3) && (seq_inj_ctrl & SEQ_HYBRID)) {
                    outpc.vecurr2 = 0;
                }
                if ((flash8.seq_inj & 0x03) && (pg8_ptr->seq_inj & 0x10)) {
                    int ix;
                    outpc.vetrim[0] = intrp_2dctable_signed(outpc.rpm, outpc.fuelload, NO_EXFRPMS, NO_EXFMAPS,
                            &pg8_ptr->frpm_tables.frpm_trimvL[0], &pg8_ptr->fmap_tables.fmap_trimvL[0], 
                            (unsigned char *)&pg8_ptr->ve_tables.ve_trim1L[0][0]); // in .1 %
                    for (ix = 0; ix < no_inj -1; ix++) {
                        outpc.vetrim[ix+1] = intrp_2dctable_signed(outpc.rpm, outpc.fuelload, NO_EXFRPMS, NO_EXFMAPS,
                                &pg11_ptr->frpm_tables.frpm_trimvL[ix][0], &pg11_ptr->fmap_tables.fmap_trimvL[ix][0], 
                                (unsigned char *)&pg11_ptr->ve_tables.ve_trimL[ix][0][0]); // in .1 %
                    }
                }
            }


            serial();
            /**************************************************************************
             **
             ** Computation of Fuel Parameters
             ** Note that GAMMAE only includes Warm, Tpsfuelcut, Barocor, and Aircor
             ** (EGO no longer included)
             **
             **************************************************************************/
            lsum = ((outpc.warmcor * (long)outpc.tpsfuelcut) / 100);
            if ((flash4.FuelAlgorithm & 0xf) != 5) {
                /* Use baro and aircor for everything except primary MAF mode */
                lsum = (lsum * ((outpc.barocor * (long)outpc.aircor) / 1000L)/1000L);
            }
            outpc.gammae = (int)lsum;

            if ((flash4.FuelAlgorithm & 0xf) == 5) {
                int inj_load;

                if (flash4.feature7 & 0x01) { // MAT cor curve
                    inj_load = (int)( ((long)mafload_no_air * 
                        (1000 + intrp_1ditable(outpc.mat, NO_MAFMATS, (int *)flash5.MatVals, 1,
                        (unsigned int *)flash5.AirCorDel) )) / 1000);
                } else {
                    inj_load = mafload_no_air;
                }

                lsum2 = inj_load;
                local_div = 1000;
                /* MAF algorithm uses MAF to calculate mafload_no_air (calc is ~line )
                  mafload is a 'synthetic' load.
                  mafload_no_air excludes the aircor variable to avoid cancelling it out again here.
                  VE is taken as 100.0% as MAF ideally gives a perfect mass flow number.
                  The rest of the fuel calc follows as normal.
                  i.e. PW = RF * mafload_no_air * other_corrections
                  cf. Speed density where PW = RF * map * VE(rpm,map) * airden * other_corrections
                */
            } else {
                if (flash4.loadopts & LOADOPTS_LOADMULT) {
                    lsum2 = (long)outpc.map;
                } else {
                    lsum2 = 1000;                // normalizes to ~1 when divide by baro
                }
                if (flash4.loadopts & LOADOPTS_OLDBARO) {
                    local_div = outpc.baro;
                } else {
                    local_div = 1000;
                }
            }

            lsum1 = (lsum * ((outpc.egocor1 * lsum2) / local_div)/100);
            lsum1 = lsum1 * ((outpc.vecurr1 * (long)flash4.ReqFuel)/ 10000); // .01 usec
            if (((flash8.seq_inj & 0x03) == 3) && (seq_inj_ctrl & SEQ_HYBRID)) {
                lsum1 *= 2; // double the reqfuel due to the single pulse
            }
            lsum2 = (lsum * ((outpc.egocor2 * lsum2) / local_div)/100);
            lsum2 = lsum2 * ((outpc.vecurr2 * (long)flash4.ReqFuel)/ 10000); // .01 usec

            if (flash4.loadopts & LOADOPTS_LOADSTOICH) { /* factor in afr target */
                lsum1 = (lsum1 * (long)flash4.stoich) / (long)gl_afrtgt1;
                if (flash4.dual_tble_optn & 1) {
                    lsum2 = (lsum2 * (long)flash4.stoich) / (long)gl_afrtgt2;
                } else {
                    lsum2 = (lsum2 * (long)flash4.stoich) / (long)gl_afrtgt1;
                }
            }

            calc_opentime();

            /**************************************************************************
             **
             ** Calc. of Flex Fuel Sensor %alcohol and PW,spk correction (fuelcor,ffspkdel)
             **
             **************************************************************************/
            if (flash4.FlexFuel & 0x01)  {
                lsum1 = (lsum1 * outpc.fuelcor)/ 100;           // usec
                lsum2 = (lsum2 * outpc.fuelcor)/ 100;           // usec
            } else {            // no flex fuel or fuel sensor not yet ready/ broken
                outpc.fuelcor = 100; // %
                outpc.flex_advance = 0;                        // degx10
            }

            /**************************************************************************
             **
             ** Calculation of Fuel Pulse Width
             **
             **************************************************************************/
            lsum = (long)outpc.tpsaccel * 10000;     // .01 usec
            if (lsum1 > 0) {
                lsum1 += lsum;      // usec
            }
            tmp_pw1 = lsum1;
            if (lsum2 > 0) {
                lsum2 += lsum;      // usec
            }
            tmp_pw2 = lsum2;
            if (outpc.status3 & STATUS3_CUT_FUEL)  {
                tmp_pw1 = 0;
                tmp_pw2 = 0;
            }

            /**************************************************************************
             **
             ** Over Run Fuel Cut
             **
             **************************************************************************/
            flagbyte20 &= ~FLAGBYTE20_OVERRUNFC; // only checked in mainloop code
            if (flash5.feature5_0 & 0x1) {
                if ((outpc.rpm > flash5.fc_rpm) && (outpc.map < flash5.fc_kpa)
                        && (outpc.tps < flash5.fc_tps) && (outpc.clt > flash5.fc_clt) ) {
                    if (fc_counter == 0) {
                        flagbyte20 |= FLAGBYTE20_OVERRUNFC;
                        fc_off_time = 0xff;
                    } else if (fc_counter > flash5.fc_delay) {
                        fc_counter = flash5.fc_delay;
                    }
                } else if ((outpc.rpm < flash5.fc_rpm_lower) || (outpc.map >= flash5.fc_kpa) ||
                        (outpc.tps >= flash5.fc_tps) || (outpc.clt <= flash5.fc_clt)) {
                    fc_counter = 0xff;
                    if (fc_off_time == 0xff) {
                        fc_off_time = 0;
                    }
                } else {
                    /* if we're here, we're in hysteresis, so if the counter is < 0
                     * and none of the other conditions are above the threshold
                     * yet, continue cutting fuel
                     */
                    if (fc_counter == 0) {
                        flagbyte20 |= FLAGBYTE20_OVERRUNFC;
                        fc_off_time = 0xff;
                    }
                }
            } else {
                fc_counter = 0xff;
                fc_off_time = 0xff;
            }

            /**************************************************************************
             ** Additional fuel from nitrous. Zero if unused.
             **************************************************************************/
            if (flash4.dual_tble_optn & 1) {
                if (flash10.N2Oopt & 1) {
                    tmp_pw1 += (unsigned long)outpc.n2o_addfuel * 100;
                    goto DONE_ADD_N2O;
                } else if (flash10.N2Oopt & 2) {
                    tmp_pw2 += (unsigned long)outpc.n2o_addfuel * 100;
                    goto DONE_ADD_N2O;
                }
            }
            tmp_pw1 += (unsigned long)outpc.n2o_addfuel * 100;
            tmp_pw2 += (unsigned long)outpc.n2o_addfuel * 100;

DONE_ADD_N2O:

CHECK_STAGED:
            global_base_pw1 = tmp_pw1; // store this away for anything that wants to figure out duty
            if (flash10.staged & 0x7) {
                if (seq_inj_ctrl & SEQ_STD_INJ) {
                    calc_staged_pw(tmp_pw1, 0);

                    tmp_pw1 = pw_staged1;
                    tmp_pw2 = pw_staged2;
                } else {
                    pw_staged3 = pw_staged4 = 0;  // Needed to reset them if tmp_pw2 changes to 0

                    calc_staged_pw(tmp_pw1, tmp_pw2);

                    tmp_pw1 = pw_staged1;
                    tmp_pw2 = pw_staged3;
                    tmp_pw3 = pw_staged2;
                    tmp_pw4 = pw_staged4;
                }
            }

            run_EAE_calcs();
            if ((flash10.staged & 0x7) && !(seq_inj_ctrl & SEQ_STD_INJ)) {
                unsigned long ttmppw1, ttmppw2;
                ttmppw1 = tmp_pw1;
                ttmppw2 = tmp_pw2;
                tmp_pw1 = tmp_pw3;
                tmp_pw2 = tmp_pw4;
                run_EAE_calcs();
                tmp_pw3 = tmp_pw1;
                tmp_pw4 = tmp_pw2;
                tmp_pw1 = ttmppw1;
                tmp_pw2 = ttmppw2;
            }

            /**************************************************************************
             ** Set pulse widths 3 and 4 and Add VE trim
             **************************************************************************/
            if (flash8.seq_inj & 0x03) {
                if (no_inj > 2) {
                    tmp_pw3 = tmp_pw1;
                    tmp_pw4 = tmp_pw2;
                }
                if (pg8_ptr->seq_inj & 0x10)
                    add_vetrim();
            }
            localflags &= ~LOCALFLAGS_RUNFUEL;
        }

        /* Check what bits are wanting to cut fuel and set/clear the master setbit */
        if ( (flagbyte20 & FLAGBYTE20_REVLIMFC) || (flagbyte20 & FLAGBYTE20_OVERRUNFC)
            || ((flash4.OverBoostOption & 0x01) && (outpc.status2 & STATUS2_OVERBOOST_ACTIVE))
            || (flagbyte20 & FLAGBYTE20_LAUNCHFC)
            || ((outpc.engine & ENGINE_CRANK) && (outpc.tps > flash4.TPSWOT))
            || (flagbyte22 & FLAGBYTE22_SHUTDOWNACTIVE)
            ) {
            outpc.status3 |= STATUS3_CUT_FUEL;
        } else {
            outpc.status3 &= ~STATUS3_CUT_FUEL;
        }


        serial();
        /**************************************************************************
         **
         ** Calculation of Knock retard, Distributor Advance & coil charge time correction
         **
         **************************************************************************/
KNK:
        if (flash4.knk_option & 0x03) {
            // read from digi ports and set outpc var (only using 1 bit of a uint)
            // Want to display this on the dash even if outside window
            if (flash4.knkport & 0x08) {
                // Remote knock input
                unsigned char tmp_knk;
                tmp_knk = outpc.gpioport[2] & (1 << (flash4.knkport & 0x07));
                if ( ((flash4.knk_option & 0x10) && (tmp_knk)) // high input
                        || ((!(flash4.knk_option & 0x10)) && (!(tmp_knk))) ) {
                    outpc.knock = 1000;
                } else {
                    outpc.knock = 0;
                }
            } else {
                // Local knock analogue input pin
                if (flash4.knk_option & 0x80) {
                    // Local knock input pin
                    if (flash4.knkport & 0x01) { // option AD6/JS5
                        outpc.knock = ATD0DR6;
                    } else {
                        outpc.knock = ATD0DR7;
                    }
                } else {
                    // Local knock digi input pin
                    if (flash4.knkport & 0x01) { // option AD6/JS5
                        if ( ((flash4.knk_option & 0x10) && (PTAD & 0x40)) // high input
                                || ((!(flash4.knk_option & 0x10)) && (!(PTAD & 0x40))) ) {
                            outpc.knock = 1000;
                        } else {
                            outpc.knock = 0;
                        }
                    } else { // default AD7/JS4
                        if ( ((flash4.knk_option & 0x10) && (PTAD & 0x80)) // high input
                                || ((!(flash4.knk_option & 0x10)) && (!(PTAD & 0x80))) ) {
                            outpc.knock = 1000;
                        } else {
                            outpc.knock = 0;
                        }
                    }
                }
            }
        }

        if (!(flash4.knk_option & 0x03) ||
                (outpc.map > flash4.knk_maxmap) || (outpc.rpm < flash4.knk_lorpm) ||
                (outpc.rpm > flash4.knk_hirpm))  {  // no knock correction
            outpc.knk_rtd = 0;
        } else {   // latch any knocks that occur during the knk_clk_test interval
            // knock input active?
            unsigned int thresh = 0;

            if (flash4.knk_option & 0x80) {
                /* lookup analogue threshold */
                /* analogue input, grab threshold */
                thresh =  intrp_1ditable(outpc.rpm, 10,
                    (int *) flash12.knock_rpms, 1,
                    (int *) flash12.knock_thresholds);
            }

            if (outpc.knock > thresh) {
                // signal(Vx100) indicates knock occurred
                if(knk_count < 255)              // don't want to overflow to 0
                    knk_count++;
                if((knk_stat == 0) && (knk_count > flash4.knk_ndet))
                    knk_clk = knk_clk_test;             // just caught knock - force 1st retard
                // immediately (as fast as main loop allows)
            }
            if(knk_clk >= knk_clk_test)  {       // time to check for retard/ adv spark
                if(knk_count > flash4.knk_ndet)  {        // got valid knock. req ndet consec
                    // knocks to be sure
                    knk_clk_test = flash4.knk_trtd;
                    if(knk_stat == 4)   // thought had enough retard, but need more
                        knk_stat = 2;
                    if(knk_stat < 2)
                        uctmp = flash4.knk_step1;               // haven't stopped knock yet
                    else
                        uctmp = flash4.knk_step2;               // stopped once - use smaller step
                    uctmp = outpc.knk_rtd + uctmp;
                    if(uctmp < flash4.knk_maxrtd)
                        outpc.knk_rtd = uctmp;
                    else
                        outpc.knk_rtd = flash4.knk_maxrtd;
                    if(knk_stat == 0)                                   // 1st knock
                        knk_stat = 1;
                    else if(knk_stat == 2)      {  // this is knk returning due to too much adv
                        if((flash4.knk_option & 0x03) == 1)      // operate one step below knock
                            knk_stat = 3;
                    }
                } else {                                       // did not get unambiguous knock
                    knk_clk_test = flash4.knk_tadv;             // change time interval
                    //switch causes gcc complaints about banked memory
                    //                    switch (knk_stat)  {
                    //                        case 0:
                    if ((knk_stat == 1) || (knk_stat == 2)) {
                        //                            break;
                        //                        case 1:
                        //                        case 2:
                        if((knk_stat == 2) && (outpc.knk_rtd == 0))
                            knk_stat = 0;  // back to table value & no knock- restart process
                        else  {
                            if(outpc.knk_rtd >= flash4.knk_step2)
                                outpc.knk_rtd -= flash4.knk_step2;   // remove some retard
                            else
                                outpc.knk_rtd = 0;
                            knk_stat = 2;                       // had knock, eliminated it, now try get closer
                            //  to threshhold
                        }
                    } else if (knk_stat == 3) {
                        //                            break;
                        //                        case 3:    // had knock, eliminated it, couldn't get closer to thresh
                        // This is as good as can get; save tps, rpm
                        knk_tble_adv = outpc.adv_deg;
                        knk_stat = 4;
                    } else if (knk_stat == 4) {
                        //                            break;
                        //                        case 4:               // maintain status until knock or change in tps or map
                        tmp1 = outpc.adv_deg - knk_tble_adv;
                        if(tmp1 < 0)tmp1 = -tmp1;
                        if(tmp1 > flash4.knk_dtble_adv)  {
                            outpc.knk_rtd = 0;    // conditions changed- restart process
                            knk_stat = 0;
                        }
                        //                            break;
                    }    // end status switch
                }
                knk_count = 0;
                knk_clk = 0;
                }
            }

            calc_advance(); /* lsum_ign is set in here */

            // do launch in here too

            if ((flash10.launch_opt & 0x40)
                    && (outpc.tps > flash10.launch_tps)) {
                unsigned int soft_lim = 65535, hard_lim = 65535;
                unsigned char lcmode; // saves gcc suboptimal code
                //check if the chosen pin is low
                lcmode = flash10.launch_opt & 0x3f;
                if (lcmode == 0) {
                    if (!(PORTE & 0x01)) goto DO_LAUNCH;
                } else if (lcmode == 1) {
                    if (!(PORTE & 0x02)) goto DO_LAUNCH;
                } else if (lcmode == 2) {
                    if (!(PORTT & 0x20)) goto DO_LAUNCH;
                } else if (lcmode == 3) {
                    if (!(PORTA & 0x01)) goto DO_LAUNCH;
                } else if (lcmode == 4) {
                    if (!(PTAD & 0x40)) goto DO_LAUNCH;
                } else if (lcmode == 5) {
                    if (!(PTAD & 0x80)) goto DO_LAUNCH;
                } else {
                    // Remote port
                    if (!(outpc.gpioport[2] & (0x01<<(lcmode-6)))) goto DO_LAUNCH;
                }
                // nothing active
                if (outpc.status2 & status2_launch) { // if we were on, then set nitrous delay timer
                    if (flash10.launch_opt & 0x80) {
                        n2o_act_timer = flash10.N2Odel_flat;  //flat shift timer
                    } else {
                        n2o_act_timer = flash10.N2Odel_launch;  //launch timer
                    }
                }

                outpc.status2 &= ~(status2_launch | status2_flatshift); // turn off both
                flagbyte20 &= ~FLAGBYTE20_LAUNCHFC;
                goto NO_LAUNCH;

DO_LAUNCH:
                if (!(outpc.status2 & status2_launch)) {
                    outpc.status2 |= status2_launch; // turn it on (code below shuts down nitrous immediately)
                    if ((flash10.launch_opt & 0x80) && (outpc.rpm > flash10.flats_arm)) {
                        outpc.status2 |= status2_flatshift; // turn it on
                    }
                }
                if (outpc.status2 & status2_flatshift) {
                    // use flat shift limits
                    hard_lim = flash10.flats_hrd;
                    soft_lim = flash10.flats_hrd - flash10.launch_sft_zone;
                    if (outpc.rpm > soft_lim) {
                        lsum_ign = (long)flash10.flats_deg;
                    }
                } else {
                    // use launch limits
                    hard_lim = flash10.launch_hrd_lim;
                    soft_lim = flash10.launch_hrd_lim - flash10.launch_sft_zone;
                    if (outpc.rpm > soft_lim) {
                        lsum_ign = (long)flash10.launch_sft_deg;
                    }
                }

                if (outpc.rpm > soft_lim) {
                    if (flash10.launchlimopt & 1)  {
                        unsigned char sc_tmp;
                        if (outpc.rpm >= hard_lim) {
                            sc_tmp = 255;
                        } else {
                            sc_tmp = (255L * (outpc.rpm - soft_lim)) / (hard_lim - soft_lim);
                        }
                        if (sc_tmp > spkcut_thresh_tmp) {
                            spkcut_thresh_tmp = sc_tmp;
                        }
                        flagbyte20 |= FLAGBYTE20_SPKCUTTMP;
                    }
                }

                if (flash10.launchlimopt & 2)  {
                    if (outpc.rpm > hard_lim) {
                        flagbyte20 |= FLAGBYTE20_LAUNCHFC;
                    } else if (outpc.rpm < soft_lim) {
                        flagbyte20 &= ~FLAGBYTE20_LAUNCHFC;
                    } // in between is hyst zone
                }
            } else { /* Launch not on at all */
                outpc.status2 &= ~(status2_launch | status2_flatshift); // turn off both
                flagbyte20 &= ~FLAGBYTE20_LAUNCHFC;
            }

NO_LAUNCH:

            /**************************************************************************
             **
             ** Nitrous
             **
             **************************************************************************/
            if (flash10.N2Oopt & 0x04) {  // are we using nitrous at all
                unsigned char nmode; // saves gcc suboptimal code
                if (outpc.status2 & status2_launch) {
                    outpc.status2 &= ~status2_nitrous1;
                    outpc.status2 &= ~status2_nitrous2;
                    goto NITROUS_OUTPUTS;
                }
                // is enable input on
                //check if the chosen pin is low
                if (flash10.N2Oopt_pins & 0x08) {
                    // Remote port
                    nmode = 0x01 << (flash10.N2Oopt_pins & 0x07);
                    if (!(outpc.gpioport[2] & nmode)) goto DO_NITROUS;
                } else {
                    nmode = flash10.N2Oopt_pins & 0x07;
                    if (nmode == 0x00) {
                        if (!(PORTE & 0x01)) goto DO_NITROUS;
                    } else if (nmode == 0x01) {
                        if (!(PORTE & 0x02)) goto DO_NITROUS;
                    } else if (nmode == 0x02) {
                        if (!(PORTT & 0x20)) goto DO_NITROUS;
                    } else if (nmode == 0x03) {
                        if (!(PORTA & 0x01)) goto DO_NITROUS;
                    } else if (nmode == 0x04) {
                        if (!(PTAD & 0x40)) goto DO_NITROUS;
                    } else if (nmode == 0x05) {
                        if (!(PTAD & 0x80)) goto DO_NITROUS;
                    }
                }
                // no valid input so turn it off
                outpc.status2 &= ~status2_nitrous1;
                outpc.status2 &= ~status2_nitrous2;
                outpc.n2o_addfuel = 0;
                goto NITROUS_OUTPUTS;
DO_NITROUS:
                // selection logic
                if ( (outpc.rpm > flash10.N2ORpm) && (outpc.rpm < flash10.N2ORpmMax) 
                        && (outpc.tps > flash10.N2OTps) && (outpc.clt > flash10.N2OClt) && (n2o_act_timer == 0) ) {
                    int ret = 0;
                    if (!(outpc.status2 & status2_nitrous1)) {
                        n2o2_act_timer = flash10.N2O2delay; // if first change then set delay to stage 2
                    }
                    outpc.status2 |= status2_nitrous1;
                    outpc.n2o_addfuel = twoptlookup(outpc.rpm, flash10.N2ORpm, flash10.N2ORpmMax, flash10.N2OPWLo, flash10.N2OPWHi);
                    ret += flash10.N2OAngle; // retard timing

                    // if stage 1 on, then check for stage 2
                    if ( (flash10.N2Oopt & 0x08) && (outpc.rpm > flash10.N2O2Rpm) && (outpc.rpm < flash10.N2O2RpmMax) 
                            && (n2o2_act_timer == 0)) {
                        outpc.status2 |= status2_nitrous2;
                        outpc.n2o_addfuel += twoptlookup(outpc.rpm, flash10.N2O2Rpm, flash10.N2O2RpmMax, flash10.N2O2PWLo, flash10.N2O2PWHi);
                        ret += flash10.N2O2Angle; // retard timing
                    } else {
                        outpc.status2 &= ~status2_nitrous2; // if stage1 is off then so is stage2
                    }
                    outpc.nitrous_retard = ret;                    
                    lsum_ign -= ret;

                } else {
                    outpc.status2 &= ~status2_nitrous1;
                    outpc.status2 &= ~status2_nitrous2; // if stage1 is off then so is stage2
                    outpc.n2o_addfuel = 0;
                    outpc.nitrous_retard = 0;
                }


NITROUS_OUTPUTS:
                // here we flip the bits for chosen output pins
                if (flash10.N2Oopt_pins & 0x80) {
                    // Remote port
                    nmode = 0x01 << ((flash10.N2Oopt_pins & 0x70)>>4);
                    // stage 1
                    if (outpc.status2 & status2_nitrous1) {
                        outpc.gpioport[0] |= nmode; // turn on
                    } else {
                        outpc.gpioport[0] &= ~nmode; // turn off
                    }

                    if (flash10.N2Oopt & 0x08) {
                        // stage 2
                        nmode <<= 1;
                        if (outpc.status2 & status2_nitrous2) {
                            outpc.gpioport[0] |= nmode; // turn on
                        } else {
                            outpc.gpioport[0] &= ~nmode; // turn off
                        }
                    }
                } else {
                    if (flash10.N2Oopt_pins & 0x10) { // FIDLE + D15
                        // stage 1
                        if (outpc.status2 & status2_nitrous1) {
                            PORTM |= 0x04; // turn on FIDLE
                        } else {
                            PORTM &= ~0x04; // turn off
                        }

                        if (flash10.N2Oopt & 0x08) {
                            // stage 2
                            if (outpc.status2 & status2_nitrous2) {
                                PORTM |= 0x20; // turn on D15
                            } else {
                                PORTM &= ~0x20; // turn off
                            }
                        }
                    } else { // IAC 1+2
                        // stage 1
                        if (outpc.status2 & status2_nitrous1) {
                            PORTT |= 0x80; // turn on IAC1
                        } else {
                            PORTT &= ~0x80; // turn off
                        }

                        if (flash10.N2Oopt & 0x08) {
                            // stage 2
                            if (outpc.status2 & status2_nitrous2) {
                                PORTT |= 0x40; // turn on IAC2
                            } else {
                                PORTT &= ~0x40; // turn off
                            }
                        }
                    }
                }
            }

            /**************************************************************************/
            if ((spkmode == 2) || (spkmode == 3) || (spkmode == 14)) { // 2,3,14 dizzy or twin trigger
                if (pg4_ptr->adv_offset < 200) { // next cyl
                    // allow at least 1 deg ahead of trigger
                    if (lsum_ign < (pg4_ptr->adv_offset + 10)) {
                        lsum_ign = pg4_ptr->adv_offset + 10;
                    }
                } else { // this cyl
                    // allow at least 5 deg after trigger
                    if (lsum_ign > (pg4_ptr->adv_offset - 50)) {
                        lsum_ign = pg4_ptr->adv_offset - 50;
                    }
                }
            }

            outpc.ext_retard = datax1.SpkAdj;
            lsum_ign += datax1.SpkAdj;     // degx10 - adjustment from remote CAN device (dangerous)

            outpc.adv_deg = (int)lsum_ign;  // Report advance before we fudge it

            /* check for difference between flash and ram trigger angles (trigger wizard?) for on-the-fly adjustment */
            if (spkmode != 4) { /* but not for trigger wheel */
                if (pg4_ptr->adv_offset != flash_adv_offset) {
                    int local_offset;
                    local_offset = pg4_ptr->adv_offset;
                    if (spkmode > 3) {
                        /* only permit +/-20 here too */
                        if (local_offset < -200) {
                            local_offset = -200;
                        } else if (local_offset > 200) {
                            local_offset = 200;
                        }
                    }
                    lsum_ign += flash_adv_offset - local_offset;
                }
            } else { /* spkmode4 only */
                /* ONLY FOR TRIGGER WHEEL - check for on-the-fly adjustment */
                if ((int)pg4_ptr->Miss_ang != flash_adv_offset) {
                    int diffang;
                    diffang = flash_adv_offset - (int)pg4_ptr->Miss_ang;
                    /* Not really expecting huge deltas here as user should power cycle,
                     * but try to handle 0->719.9 or reverse case.
                     */
                    if (diffang < -3600) {
                        diffang += 7200;
                    } else if (diffang > 3600) {
                        diffang -= 7200;
                    } else {
                        /* Leave alone. */
                    }

                    lsum_ign += (long)diffang;
                }
            }

            if (lsum_ign < -100) {
                lsum_ign = -100;
            }
            /* ROTARY */
            if ((flash4.EngStroke & 0x03) == 0x03) {
                if (outpc.engine & ENGINE_CRANK) {
                    lsum_rot = flash4.crank_timing;
                } else if (pg4_ptr->timing_flags & TIMING_FIXED) {
                    lsum_rot = pg4_ptr->fixed_timing;
                } else {
                    lsum_rot = intrp_2ditable(outpc.rpm, outpc.fuelload, 8, 8, &pg10_ptr->RotarySplitRPM[0],
                            &pg10_ptr->RotarySplitMAP[0], (int *)&pg10_ptr->RotarySplitTable[0][0]);
                    if (!(pg10_ptr->RotarySplitMode & ROTARY_SPLIT_ALLOW_NEG_SPLIT)) {
                        if (lsum_rot < 0) {
                            lsum_rot = 0;
                        }
                    }

                    /* now since split is with reference to the leading timing, add split to leading timing */
                    lsum_rot = lsum_ign - lsum_rot;
                }
            }

            /* Fuel injection timing */ 
            if ((flash8.seq_inj & 0x03) != 0) {     
                if (outpc.engine & ENGINE_CRANK) {  // cranking
                    lsum_fuel1 = flash8.inj_adv_crank[0];
                } else if (pg8_ptr->seq_inj & 0x20) {  // use table
                    if (((flash8.seq_inj & 0x03) == 3) && (seq_inj_ctrl & SEQ_HYBRID)) {
                        lsum_fuel1 = intrp_2ditable(outpc.rpm, outpc.fuelload, 6, 6,
                                &pg5_ptr->srpm_inj_adv3[0], &pg5_ptr->smap_inj_adv3[0], (int *)&pg5_ptr->inj_adv_table3[0][0]);
                    } else {
                        lsum_fuel1 = intrp_2ditable(outpc.rpm, outpc.fuelload, 6, 6,
                                &pg8_ptr->srpm_inj_adv[0][0], &pg8_ptr->smap_inj_adv[0][0], (int *)&pg8_ptr->inj_adv_table[0][0][0]);
                    }
                } else {  // fixed timing
                    if ((flash10.staged & 0x7) && (flagbyte4 & flagbyte4_staging_on)) {
                        if (((flash8.seq_inj & 0x03) == 3) && (seq_inj_ctrl & SEQ_HYBRID)) {
                            lsum_fuel1 = pg8_ptr->inj_adv_fixed[5];  // staging on
                        } else {
                            lsum_fuel1 = pg8_ptr->inj_adv_fixed[3];  // staging on
                        }
                    } else {
                        if (((flash8.seq_inj & 0x03) == 3) && (seq_inj_ctrl & SEQ_HYBRID)) {
                            lsum_fuel1 = pg8_ptr->inj_adv_fixed[2];  // staging off or not enabled
                        } else {
                            lsum_fuel1 = pg8_ptr->inj_adv_fixed[0];  // staging off or not enabled
                        }
                    }
                }

                outpc.inj_adv1 = (int)lsum_fuel1;    

                /* check for difference between flash and ram trigger angles (trigger wizard?) for on-the-fly adjustment */
                if ((spkmode != 4) && (pg4_ptr->adv_offset != flash_adv_offset)) {
                    lsum_fuel1 += flash_adv_offset - pg4_ptr->adv_offset;
                }
                if (lsum_fuel1 < 0) {
                    lsum_fuel1 += cycle_deg;
                }

                if ((flash8.seq_inj & 0x03) == 3) {     
                    if (seq_inj_ctrl & SEQ_HYBRID) {
                        lsum_fuel2 = lsum_fuel1 + 3600;
                    } else if (flash8.seq_inj & 0x08) {     
                        // Dual timing values
                        if (outpc.engine & ENGINE_CRANK) {  // cranking
                            lsum_fuel2 = flash8.inj_adv_crank[1];
                        } else if (pg8_ptr->seq_inj & 0x20) {  // use table
                            lsum_fuel2 = intrp_2ditable(outpc.rpm, outpc.fuelload, 6, 6,
                                    &pg8_ptr->srpm_inj_adv[1][0], &pg8_ptr->smap_inj_adv[1][0], (int *)&pg8_ptr->inj_adv_table[1][0][0]);
                        } else {  // fixed timing
                            if ((flash10.staged & 0x7) && (flagbyte4 & flagbyte4_staging_on)) {
                                lsum_fuel2 = pg8_ptr->inj_adv_fixed[4];  // staging on
                            } else {
                                lsum_fuel2 = pg8_ptr->inj_adv_fixed[1];  // staging off or not enabled
                            }
                        }
                        outpc.inj_adv2 = (int)lsum_fuel2;    

                        /* check for difference between flash and ram trigger angles (trigger wizard?) for on-the-fly adjustment */
                        if ((spkmode != 4) && (pg4_ptr->adv_offset != flash_adv_offset)) {
                            lsum_fuel2 += flash_adv_offset - pg4_ptr->adv_offset;
                        }
                        if (lsum_fuel2 < 0) {
                            lsum_fuel2 += 7200;
                        }
                    } else {
                        lsum_fuel2 = lsum_fuel1;
                    }
                }
            }       

            /* --------------------------------------------------------------------------------------- */
            /* EVERY TOOTH WHEEL DECODER */
            /* --------------------------------------------------------------------------------------- */
EVERY_TOOTH:
            if (tmp_pw1 > 3200000) {
                tmp_pw1 = 3200000;
            }

            if (tmp_pw2 > 3200000) {
                tmp_pw2 = 3200000;
            }

            if (tmp_pw3 > 3200000) {
                tmp_pw3 = 3200000;
            }

            if (tmp_pw4 > 3200000) {
                tmp_pw4 = 3200000;
            }

            pwcalc1 = tmp_pw1 / 100;
            pwcalc2 = tmp_pw2 / 100;
            if (!(seq_inj_ctrl & SEQ_STD_INJ)) {
                pwcalc3 = tmp_pw3 / 100;
                pwcalc4 = tmp_pw4 / 100;
            }

            do_spkmode();

            recheck_syncfirst();

            tachmask_calc();

            // that's most of the spark calcs done

            if (flash4.RevLimOption & 0x27) { // any rev limiting?
                unsigned int limit;
                limit = flash4.RevLimNormal2; /* Start with hard limit */

                if (flash4.RevLimOption & 0x8) {
                    if (outpc.clt < (int)pg8_ptr->RevLimLookup[7]) {
                        if (outpc.tps < flash4.TpsBypassCLTRevlim) {
                            limit = intrp_1ditable(outpc.clt,8,(int *)pg8_ptr->RevLimLookup, 0,
                                    (unsigned int *)pg8_ptr->RevLimRpm1);
                        }
                    }
                }

                RevLimRpm2 = limit;
                RevLimRpm1 = limit - flash4.RevLimNormal2_hyst;


                /* random number based spark cut */
                if (flash4.RevLimOption & 0x4) {
                    if (outpc.rpm > flash4.RevLimNormal2) {
                        spkcut_thresh_tmp = 255;
                         flagbyte20 |= FLAGBYTE20_SPKCUTTMP;
                    } else if (outpc.rpm > RevLimRpm1) {
                        unsigned char sc_tmp;
                        if (outpc.rpm >= RevLimRpm2) {
                            sc_tmp = 255;
                        } else {
                            sc_tmp = (255L * (outpc.rpm - RevLimRpm1)) / (RevLimRpm2 - RevLimRpm1);
                     }
                        if (sc_tmp > spkcut_thresh_tmp) {
                            spkcut_thresh_tmp = sc_tmp;
                        }
                        flagbyte20 |= FLAGBYTE20_SPKCUTTMP;
                    }
                    // no else, initialised to zero on each mainloop pass
                }

                /* Check for fuel cut */
                if (flash4.RevLimOption & 0x20) {
                    if ((flash4.RevLimOption & 0x10) && (no_inj > 1)) {
                        /* progressive fuel cut */
                        if (outpc.rpm > (RevLimRpm2 - flash4.RevLimNormal2_hyst - 100)) {
                            unsigned int step, b, base;
                            base = RevLimRpm2 - flash4.RevLimNormal2_hyst;
                            /* use no hyst on each channel for the moment */
                            step = flash4.RevLimNormal2_hyst / (no_inj - 1);
                            for (b = 0 ; b < no_inj ; b++) {
                                if (outpc.rpm > (base + (step * b))) {
                                    skipinj_revlim |= fuelcut_array[no_inj - 1][b];
                                } else if (outpc.rpm < (base + (step * b) - 100)) {
                                    skipinj_revlim &= ~fuelcut_array[no_inj - 1][b];
                                }
                            }
                        } else {
                            skipinj_revlim = 0;
                        }
                    } else {
                        /* hard fuel cut only */
                        if (outpc.rpm > RevLimRpm2) {
                            // Cut fuel for Over Rev
                            flagbyte20 |= FLAGBYTE20_REVLIMFC;
                        } else if (outpc.rpm < (RevLimRpm2 - flash4.RevLimNormal2_hyst)) {
                            // restore fuel
                            flagbyte20 &= ~FLAGBYTE20_REVLIMFC;
                        }
                    }
                } else {
                    flagbyte20 &= ~FLAGBYTE20_REVLIMFC;
                }

            } // end of any rev limiting

            if (flagbyte22 & FLAGBYTE22_SHUTDOWNSPKACTIVE) {
                outpc.status2 |= STATUS2_SPKCUT;
                spkcut_thresh = 255; /* full cut */
            } else if (!(flagbyte20 & FLAGBYTE20_SPKCUTTMP)) {
                outpc.status2 &= ~STATUS2_SPKCUT;
                spkcut_thresh = 0; // no cut
            } else {
                outpc.status2 |= STATUS2_SPKCUT;
                spkcut_thresh = spkcut_thresh_tmp;
            }
            spkcut_thresh_tmp = 0; // set to no cut for the next pass around mainloop
            flagbyte20 &= ~FLAGBYTE20_SPKCUTTMP;

            serial();

            if (flash4.EAEOption == 3) {
                int source;

                utmp1 = tmp_pw1 / EAEdivider;

                if (utmp1) {
                    if (utmp1 < (65000 - pw_open1)) {
                        utmp1 += pw_open1;
                    } else {
                        utmp1 = 65000;
                    }
                }
                utmp1 = ((unsigned long)utmp1 * 3)>>1;

                DISABLE_INTERRUPTS;
                pwcalc_eae1 = utmp1;
                ENABLE_INTERRUPTS;

                utmp1 = tmp_pw2 / EAEdivider;

                if (utmp1) {
                    if (utmp1 < (65000 - pw_open2)) {
                        utmp1 += pw_open2;
                    } else {
                        utmp1 = 65000;
                    }
                }
                utmp1 = ((unsigned long)utmp1 * 3)>>1;

                DISABLE_INTERRUPTS;
                pwcalc_eae2 = utmp1;
                ENABLE_INTERRUPTS;

                if (flash5.EAElagsource) {
                    /* use mapdot, otherwise, tpsdot */
                    source = outpc.mapdot;
                } else {
                    source = outpc.tpsdot / 10;
                }

                if ((source > flash5.EAElagthresh) &&
                        ((outpc.EAEfcor1 > 100) || (outpc.EAEfcor2 > 100)) &&
                        (outpc.rpm < flash5.EAElagRPMmax)) {
                    DISABLE_INTERRUPTS;
                    flagbyte2 |= flagbyte2_EAElag;
                    ENABLE_INTERRUPTS;
                } else {
                    DISABLE_INTERRUPTS;
                    flagbyte2 &= ~flagbyte2_EAElag;
                    ENABLE_INTERRUPTS;
                }

                DISABLE_INTERRUPTS;
                injtime_EAElagcomp = injtime / flash4.Divider;
                ENABLE_INTERRUPTS;
            }

            handle_ovflo();

            /***************************************************************************
             **
             ** Check whether to burn flash
             ** (do this in SCI now)
             **************************************************************************/
            ckstall();

            handle_spareports();

            /***************************************************************************
             **
             **  Check for CAN receiver timeout
             **
             **************************************************************************/
            if (flagbyte3 & flagbyte3_can_reset) {
                CanInit();          // start over again and clear flags
            }

            /* CAN polling and broadcast. */
            if (!(flagbyte15 & FLAGBYTE15_CANSUSP) && (flash4.can_poll & CAN_POLL_ON)) {
                unsigned long lmms_tmp;
                if (!((flagbyte3 & (flagbyte3_sndcandat | flagbyte3_getcandat))
                    || ((flagbyte4 & FLAGBYTE4_POLLOK) == 0) ))  {
                    /* while doing a passthrough read/write, do not add any other requests to the queue */
                    DISABLE_INTERRUPTS;
                    lmms_tmp = lmms;
                    ENABLE_INTERRUPTS;
                    if (lmms_tmp > cansendclk)  {
                        cansendclk = lmms_tmp + 78;      // 10ms ( 1s = 7812 x .128 ms) clk
                        // CAN polling code.
                        // If enabled it sends a request to a GPIO type board which then sends data back to us.
                        // This gets ADC values from a GPIO with user defined CAN_ID= flash4.can_poll_id
                        can_poll_remote();
                    }
                    if (flash4.can_bcast1 & 0x01) {
                        can_broadcast();
                    }
                    can_dashbcast();
                }
            }

            if (flagbyte15 & FLAGBYTE15_ONESEC) { // once per second
                int x;
                flagbyte15 &= ~FLAGBYTE15_ONESEC;
                // check and decrement CAN error counters
                for (x = 0 ; x < 15 ; x++) {
                    if (can_err_cnt[x]) {
                        can_err_cnt[x]--;
                    }
                }
            }

            {
                unsigned long ltmp1;
                /* Calcs for fuel injection time mask */
                DISABLE_INTERRUPTS;
                ltmp1 = dtpred;
                ENABLE_INTERRUPTS;
                ltmp1 *= flash4.Divider;
                ltmp1 = (ltmp1 * flash10.inj_time_mask) / 100;
                /* convert to .128ms units */
                ltmp1 /= 192;

                if ((ltmp1 == 0) || (outpc.engine & ENGINE_CRANK)) {
                    ltmp1 = 1;
                }

                DISABLE_INTERRUPTS;
                injtime = ltmp1;
                ENABLE_INTERRUPTS;
            }


            /* Calculate fuel metering pw for 80ul */
            if (pin_injpw != 0) {
                unsigned long ltmp1;
                ltmp1 = (unsigned long)flash10.staged_pri_size;
                ltmp1 *= (unsigned long)(flash4.NoInj & 0x1f);
                ltmp1 = (80UL * 90UL * 1000UL) / ltmp1; /* 80ul * ml -> ul and per minute to per second */ /* *1.5 per customer feedback */
                ltmp1 = (ltmp1 * (unsigned long)pg5_ptr->injpw_scale) / 1000UL;
                injpw_thresh = (unsigned int)ltmp1;
            }

#ifdef USER_DEF_ON
            /* 'user defined' */
            user_defined(); // call the user defined function - put your code in there
            /* end user defined section */
#endif

SKIP_THE_LOT:;
            /* port status */
            outpc.portbde = (PORTE & 0x13) | (PTAD & 0xc0) | ((PORTB & 0x10) << 1);
            outpc.portam = (PTM & 0x3c) | (PORTA & 0x01);
            outpc.portt = PTT;

            /* add any debug variable code here */

            /* end debug */
        }     //  END Main while(1) Loop
    }
