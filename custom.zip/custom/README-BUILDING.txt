MS2/Extra source code building
==============================

First - be sure you have read and understood LICENSE-SOURCE.txt and LICENSE.txt
within the source. 

WINDOWS
=======
Cygwin is required. You may need the 32bit version.
Go to http://www.cygwin.com/ and download and install. Be sure to include
development packages such as 'make' and 'tar'

Note - all building of the MS2/Extra code is from the commandline.

S12X build tools (gcc/binutils) are required.
Go to http://www.msextra.com/tools/ download and extract the Windows binaries
package. Then follow the included README.
Once extracted, the binaries will be in /usr/bin for Cygwin.

To edit source files, use a text editor (not a word processor.) Don't try to
use Notepad as it lacks many features needed for code development. Perhaps try
vim, gedit, notepad+
You can use Eclipse, import existing Makefile project.

LINUX
=====
Note - all building of the MS2/Extra code is from the commandline.

S12X build tools (gcc/binutils) are required.
Go to http://www.msextra.com/tools/ download and extract the Linux binaries
package. Then follow the included README.
Once extracted, the binaries will be in /usr/bin

To edit source files, use a text editor (not a word processor.)
You can use Eclipse, import existing Makefile project.

MAC
===
A pre-built toolchain is not provided at this time. Try the source.

GENERAL build notes
===================
To build MS2/Extra code for MS2 type 'make' in the ms2extra source directory,
this will generate a new 'megasquirt2.s19' and 'megasquirt2.ini'

The supported make targets are:
make clean             - removes all object files and cleans up
make                   - builds for Megasquirt-2
make ms2               - builds for Megasquirt-2
make microsquirt       - builds for Microsquirt (cased)
make microsquirtmodule - builds for Microsquirt-module
make mspnp2            - builds for DIYautotune MS-PNP2
make release - builds all .s19 and .ini files and copies to release sub-dir.

After major changes or when changing between make targets be
sure to run 'make clean'

Having built your new s19, make sure that the downloader is seeing it.
Typically you will copy the new s19 to the same directory as the downloader.
(e.g. cp *s19 ..)

18 November 2013
