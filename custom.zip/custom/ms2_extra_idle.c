/* $Id: ms2_extra_idle.c,v 1.59 2016/01/14 00:11:22 jsmcortina Exp $
 * Copyright 2006, 2007, 2008, 2009, 2010, 2011, 2012, 2013
 * James Murray and Kenneth Culver
 *
 * This file is a part of MS2/Extra.
 *
 * idle_ac_idleup()
    Majority: Kenneth Culver (ported from MS3 by James Murray)
 * idle_ctl_init
    Majority: Kenneth Culver
 * idle_test_mode
    Majority: James Murray
 * idle_on_off
    Origin: Al Grippo
    Majority: Al Grippo
 * idle_iac_warmup
    Origin: Al Grippo
    Minor: James Murray
    Majority: Al Grippo
 * idle_pwm_warmup
    Origin: Al Grippo
    Minor: James Murray
    Majority: Al Grippo
 * idle_closed_loop_throttlepressed
    Majority: Kenneth Culver
 * idle_closed_loop_throttlelifted
    Majority: Kenneth Culver
 * idle_closed_loop_pid
    Majority: Kenneth Culver
 * idle_closed_loop_newtarg
    Majority: Kenneth Culver
 * idle_closed_loop
    Majority: Kenneth Culver
 * idle_closed_loop_calc_dp_decay
    Majority: Kenneth Culver
 * idle_ctl
    Majority: Kenneth Culver
 * move_IACmotor
    Origin: Al Grippo
    Minor: Bug Fixes Kenneth Culver
    Majority: Al Grippo
 *
 * You should have received a copy of the code LICENSE along with this source,
 * ask on the www.msextra.com forum if you did not.
 *
*/
#include "ms2_extra.h"

void idle_ac_idleup(void)
{
    if (flash12.idle_up_options & IDLE_UP_OPTIONS_ON) {

        if (outpc.rpm < flash12.ac_idleup_min_rpm) {
            DISABLE_INTERRUPTS;
            *port_ac_out &= ~pin_ac_out;
            ENABLE_INTERRUPTS;
            ac_time_since_last_on = 0;
            return;
        }

        /* Check AC idleup input pin */
        if ((*port_ac_in & pin_ac_in) == pin_match_ac_in) {

            /* NB no protection against switch bounce */
            if (ac_time_since_last_on > flash12.ac_delay_since_last_on) {
                /* button pressed and conditions met, start timer */
                if (last_acbutton_state == 0) {
                    last_acbutton_state = 1;
                    ac_idleup_timer = 0;
                    ac_idleup_adder = flash12.ac_idleup_adder;
                    ac_idleup_cl_targetadder = flash12.ac_idleup_cl_targetadder;
                    return;
                }

                if (ac_idleup_timer >= flash12.ac_idleup_delay) {
                    DISABLE_INTERRUPTS;
                    *port_ac_out |= pin_ac_out;
                    ENABLE_INTERRUPTS;
                    outpc.status3 |= STATUS3_ACOUT;
                }
            }
        } else {
            if (last_acbutton_state == 1) {
                last_acbutton_state = 0;
                ac_idleup_timer = 0;
                ac_idleup_adder = 0;
                ac_idleup_cl_targetadder = 0;
                ac_time_since_last_on = 0;
                return;
            }

            if (ac_idleup_timer >= flash12.ac_idleup_delay) {
                DISABLE_INTERRUPTS;
                *port_ac_out &= ~pin_ac_out;
                ENABLE_INTERRUPTS;
                outpc.status3 &= ~STATUS3_ACOUT;
            }
        }
    }
}

void idle_ctl_init(void)
{
    pwmidle_timer = 0;
    pwmidle_stepsize = 0;
    pwmidle_numsteps = 0;
    pwmidle_targ_stepsize = 0;
    pwmidle_targ_numsteps = 0;
    pwmidle_targ_last = 0;
    PV_last[0] = PV_last[1] = 0;
    idle_wait_timer = flash5.pwmidle_pid_wait_timer;
    pwmidle_shift_timer = flash5.pwmidle_shift_open_time;
    last_acbutton_state = idle_voltage_comp = 0;
    rpm_last = 0;
    pwmidle_max_rpm_last = pg5_ptr->pwmidle_max_rpm;
}

void idle_test_mode(void)
{
    int pos_tmp;
    pos_tmp = pg8_ptr->iacpostest; // adding this temp var halves the code size for this if {} section
    //for PWM valves, scale the result
    if ((IdleCtl == 4) || (IdleCtl == 6)) {   // 4 or 6
        if (pos_tmp > 100) {
            pos_tmp = 100;
        }
        pos_tmp = (pos_tmp * 256) / 100; // means user enters 0-100% // sensible code with temp var, crap without
        if (pos_tmp > 255) {
            pos_tmp = 255;
        }
        IACmotor_pos = pos_tmp;
    } else {
        IACmotor_pos = pos_tmp;
    }

    if (iactest_glob == 1) {   // home feature
        iactest_glob = 2; // done it
        if ((IdleCtl == 2) || (IdleCtl == 3) ||
                (IdleCtl == 5) || (IdleCtl == 7) ||
                (IdleCtl == 8)) {
            DISABLE_INTERRUPTS;
            IAC_moving = 0;
            motor_step = -1;
            if (flash4.IdleCtl & 0x20) { // home open
                outpc.iacstep = flash4.iacfullopen - pg8_ptr->iachometest;  // set current motor step position (should be negative)
                IACmotor_pos = flash4.iacfullopen; // target position
            } else {
                outpc.iacstep = pg8_ptr->iachometest;  // set current motor step position
                IACmotor_pos = 0; // target position
            }
            ENABLE_INTERRUPTS;
            (void)move_IACmotor();
        }
    } else if (iactest_glob == 3) { // run mode
        if ((outpc.iacstep != IACmotor_pos)) {
            // move IAC motor to new step position
            move_IACmotor();
        }
    }
}

void idle_on_off(void)
{
    if(outpc.clt < flash4.FastIdle - flash4.IdleHyst)
        *pPTMpin2 |= 0x04;             // turn on fast idle solenoid
    else if(outpc.clt > flash4.FastIdle)
        *pPTMpin2 &= ~0x04;            // turn off fast idle solenoid
}

void idle_iac_warmup(void)
{
    int pos, tmp2, crankpos, runpos;

    crankpos = intrp_1ditable(outpc.clt, 4, (int *)pg5_ptr->pwmidle_crank_clt_temps, 0,
                             (unsigned int *)pg5_ptr->pwmidle_crank_dutyorsteps);
    runpos = CW_table(outpc.clt,(int *)flash4.iacstep_table, (int *)flash4.temp_table);

    if (((outpc.engine & ENGINE_CRANK) || (outpc.rpm == 0)) && (resetholdoff == 0)) {
        pos = crankpos;
        tble_motor_pos = pos;
    } else {
        // after cranking flare back to normal temperature dependent pos
        if ((outpc.seconds >= tcrank_done) &&
                (outpc.seconds <= (tcrank_done + flash4.IACcrankxt)))  {
            pos = runpos;
            if (pos < crankpos) {
                unsigned long t_lmms;
                unsigned int t, u;

                /* calc in deciseconds for smoother taper from crank to run */
                DISABLE_INTERRUPTS;
                t_lmms = lmms;
                ENABLE_INTERRUPTS;
                t_lmms -= tcrank_done_lmms;
                t = t_lmms / 781; // deciseconds since crank->run
                u = flash4.IACcrankxt * 10; // deciseconds of target crank->run time

                if (t < u) {
                    tmp2 = ((long)(crankpos - pos) * (u - t)) / u;
                } else {
                    tmp2 = 0;
                }
                pos += tmp2;
            }
            tble_motor_pos = pos;

            // check if there has been a significant change in clt temp
        } else if ((outpc.clt < (last_iacclt - flash4.IdleHyst)) ||
                (outpc.clt > last_iacclt))  {
            tble_motor_pos = runpos;
        } // else tble_motor_pos unchanged

        pos = tble_motor_pos + datax1.IdleAdj; /* Apply whole of remote adjustment */
        if (pos < 0) {
            pos = 0;
        }
        pos += ac_idleup_adder;
    }

    IACmotor_pos = pos;

    if (outpc.iacstep != IACmotor_pos)  {
        // move IAC motor to new step position
        if (move_IACmotor()) {
            last_iacclt = outpc.clt;
        }
    }
}

void idle_pwm_warmup(void)
{
    int tmp1, tmp2, pos;

    pos = intrp_1ditable(outpc.clt, 4, (int *)pg5_ptr->pwmidle_crank_clt_temps, 0,
                             (unsigned int *)pg5_ptr->pwmidle_crank_dutyorsteps);

    //pwmidle warmup only simplified
    if (((outpc.engine & ENGINE_CRANK) || (outpc.rpm == 0)) && (resetholdoff == 0)) {
        DISABLE_INTERRUPTS;
        IACmotor_pos = pos;
        ENABLE_INTERRUPTS;
    } else {
        // after cranking taper back to normal temperature dependent pos
        // 0% duty is fully closed
        if (outpc.clt < flash4.temp_table[0]) {
            tmp2 = flash4.pwmidle_table[0];
        } else if (outpc.clt > flash4.temp_table[9]) {
            tmp2 = flash4.pwmidle_table[9]; 
        } else {
            tmp2 = CW_table(outpc.clt,(int *)pg4_ptr->pwmidle_table, (int *)flash4.temp_table);
        }

        if((outpc.seconds >= tcrank_done) &&
           (outpc.seconds <= tcrank_done + flash5.pwmidlecranktaper))  {
            // check for taper requirement
            if(tmp2 <= pos) {
                /* should be (cranking pos - end pos) / seconds */
                tmp1 = (int) ((long) (pos - tmp2) *
                       (tcrank_done + flash5.pwmidlecranktaper - outpc.seconds) /
                       flash5.pwmidlecranktaper);
                tmp2 += tmp1;
            } 
        }

        tmp2 += ac_idleup_adder;
        tmp2 += idle_voltage_comp;
        tmp2 += datax1.IdleAdj;  /* Apply whole of remote adjustment */

        //check range
        DISABLE_INTERRUPTS;
        if (tmp2 > 255) {
            IACmotor_pos = 255;
        } else if (tmp2 < 0) {
            IACmotor_pos = 0;
        } else {
            IACmotor_pos = tmp2;
        }
        ENABLE_INTERRUPTS;
    }
}

#define VALVE_CLOSED 1
#define VALVE_CLOSED_PARTIAL 2

void idle_closed_loop_throttlepressed(unsigned int rpm_thresh)
{
    int pos = IACmotor_pos;

    outpc.status2 &= ~status2_pwmidle_closedloop;

    if (outpc.rpm > rpm_thresh) {       /* should we close the valve? */
        if (IACmotor_pos_tmp == IACmotor_last) {
            /* IF so, the number of steps is the delay in ms divided by how 
             * often we will run, and the step size is the amount to move total
             * divided by the number of steps
             */
            if (flash5.pwmidle_close_delay) {
                pwmidle_numsteps =
                    ((long)(flash5.pwmidle_close_delay * 1000)) / 
                    flash5.pwmidle_ms;
                if (pwmidle_numsteps > 0) {
                    pwmidle_stepsize = (IACmotor_pos - flash5.pwmidle_closed_duty) /
                        pwmidle_numsteps;
                    if (pwmidle_stepsize == 0) {
                        pwmidle_stepsize = 1;
                    }
                } else {
                    pos = flash5.pwmidle_closed_duty;
                    valve_closed = VALVE_CLOSED;
                }

                if (pwmidle_stepsize == 0) {
                    pwmidle_stepsize = 1;
                }
            } else {
                pos = IACmotor_last;
                valve_closed = VALVE_CLOSED;
            }
        }
        if (flagbyte2 & flagbyte2_runidle) {
            if ((pos > flash5.pwmidle_closed_duty)) {
                pos -= pwmidle_stepsize;
                valve_closed = VALVE_CLOSED;
            }
            if (pos <= flash5.pwmidle_closed_duty) {
                pos = flash5.pwmidle_closed_duty;
            }

            DISABLE_INTERRUPTS;
            flagbyte2 &= ~flagbyte2_runidle;
            IACmotor_pos = pos;
            ENABLE_INTERRUPTS;
            IACmotor_pos_tmp = pos;
        }
    }

    pwmidle_reset = PWMIDLE_RESET_JUSTLIFTED;

    idle_wait_timer = 0;
    pwmidle_shift_timer = 0;
}

void idle_closed_loop_throttlelifted(unsigned int rpm_thresh, unsigned int rpm_targ) 
{
    int y_val_lookup; 
    char tmp = 0;

    PV_last[0] = PV_last[1] = 0;

    if (flash12.pwmidle_cl_opts & PWMIDLE_CL_USE_INITVALUETABLE) {
        if (flash12.pwmidle_cl_opts & PWMIDLE_CL_INITVAL_CLT) {
            y_val_lookup = outpc.clt;
        } else {
            y_val_lookup = outpc.mat;
        }
        IACmotor_last = intrp_2dctable(rpm_targ, y_val_lookup, 5, 5,
                                       &pg12_ptr->pwmidle_cl_initialvalue_rpms[0],
                                       &pg12_ptr->pwmidle_cl_initialvalue_matorclt[0],
                                       &pg12_ptr->pwmidle_cl_initialvalues[0][0],
                                       0);
    }
    
    if (((!flash5.pwmidle_close_delay) ||
        (outpc.rpm <= flash5.pwmidle_shift_lower_rpm) ||
        (pwmidle_shift_timer > flash5.pwmidle_shift_open_time)) && 
        (!(pwmidle_reset & PWMIDLE_RESET_DPADDED))) {


        if (valve_closed == VALVE_CLOSED) {
            IACmotor_pos_tmp = IACmotor_last + pg5_ptr->pwmidle_dp_adder;
            tmp = PWMIDLE_RESET_DPADDED;
        } else {
            IACmotor_pos_tmp = IACmotor_last;
        }
    }

    if (IACmotor_pos_tmp > (int)flash5.pwmidle_open_duty) {
        IACmotor_pos_tmp = flash5.pwmidle_open_duty;
    }

    /* check for PID lockout */
    if (flagbyte2 & flagbyte2_runidle) {
        int rpmdot, tmpload;

        DISABLE_INTERRUPTS;
        flagbyte2 &= ~flagbyte2_runidle;
        ENABLE_INTERRUPTS;

        rpmdot = outpc.rpmdot;

        if (rpmdot < 0) {
            rpmdot = -rpmdot;
        }

        if ((flash4.FuelAlgorithm & 0xF) == 3) {
            tmpload = outpc.map;
        } else {
            tmpload = outpc.fuelload;
        }

        if (idle_wait_timer >= flash5.pwmidle_pid_wait_timer) {
            if (rpmdot < flash5.pwmidle_rpmdot_threshold) {
                if (tmpload > flash5.pwmidle_decelload_threshold) {
                    pwmidle_reset = PWMIDLE_RESET_CALCNEWTARG;
                    valve_closed = 0;
                    goto throttlelifted_end;
                }
            }
        } else {
            /* If the timer is not yet expired... reset the timer to
             * zero if rpmdot or load are outside the acceptable range
             * in order to keep this feature from false triggering
             */
            if ((rpmdot >= flash5.pwmidle_rpmdot_threshold) || 
                (tmpload <= flash5.pwmidle_decelload_threshold)) {
                    idle_wait_timer = 0;
            }
        }
    }
throttlelifted_end:
    pwmidle_reset |= tmp;
}

void idle_closed_loop_pid(unsigned int cl_targ_rpm, unsigned int rpm_thresh, char savelast)
{
    int pwmidle_deriv, rpm_error, tmp2, rpm;
    long Kp, Ki, Kd, PV, SP, tmp1;
    unsigned int clKp, clKi, clKd;

    DISABLE_INTERRUPTS;
    flagbyte2 &= ~flagbyte2_runidle;
    ENABLE_INTERRUPTS;

    outpc.status2 |= status2_pwmidle_closedloop; // turn on CL indicator

    /* Convert the rpms to generic percents in % * 10000 units.
     * Avoid going below the min rpm set by the user.
     * That will cause a large duty cycle spike
     */
     
    rpm = outpc.rpm;

    if (pg12_ptr->pidrpm_window > 1) {
        rpm = calc_deadzone_sliding_window(pg12_ptr->pidrpm_window, rpm, rpm_last);
    }
    rpm_last = rpm;

    if (flash5.pwmidle_freq & PWMIDLE_FREQ_CL_DISPLAY_PID) {
        clKp = pg5_ptr->pwmidle_Kp;
        clKi = pg5_ptr->pwmidle_Ki;
        clKd = pg5_ptr->pwmidle_Kd;
    } else {
        clKp = 1000;
        clKi = 1000;
        clKd = 0;
    }


    PV = (rpm * 10000L) / (4001 - pg5_ptr->pwmidle_max_rpm);
    SP = (cl_targ_rpm * 10000L) / (4001 - pg5_ptr->pwmidle_max_rpm);

    if ((pwmidle_reset & PWMIDLE_RESET_CALCNEWTARG) || 
        (pwmidle_reset & PWMIDLE_RESET_JUSTCRANKED)) {
        PV_last[0] = PV_last[1] = PV;
        /* This means we just got into PID, so also set
         * IACmotor_100 variable
         */
        IACmotor_100 = IACmotor_pos_tmp * 100;
    }

    if (pwmidle_max_rpm_last != pg5_ptr->pwmidle_max_rpm) {
        pwmidle_max_rpm_last = pg5_ptr->pwmidle_max_rpm;
        PV_last[0] = PV_last[1] = PV;
        IACmotor_100 = IACmotor_pos_tmp * 100;
    }

    rpm_error = SP - PV;

    pwmidle_deriv = PV - (2*PV_last[0]) + PV_last[1];

    /* don't divide these down (I'm using them as percents)
     * to help get better resolution in the next calcs
     */

    Kp = ((long)((PV - PV_last[0]) * clKp));
    Ki = ((((long)rpm_error * flash5.pwmidle_ms) / 1000) * clKi);
    Kd = ((long)pwmidle_deriv * ((clKd * 100L) / flash5.pwmidle_ms));

    PV_last[1] = PV_last[0];
    PV_last[0] = PV;

    /* now that we have the raw values in percent to change the output by, we need
     * to convert it down to the actual output's units.
     * To do that we multiply by the open duty - the closed duty, and divide that by
     * 100 (cross multiply). 
     */

    tmp1 = IACmotor_100 - ((long)(Kp - Ki + Kd) / 1000);

    tmp2 = tmp1 / 100L;

    if (tmp2 < flash5.pwmidle_closed_duty) {
        tmp2 = flash5.pwmidle_closed_duty;
        tmp1 = tmp2*100;
    } else if (tmp2 > flash5.pwmidle_open_duty) {
        tmp2 = flash5.pwmidle_open_duty;
        tmp1 = tmp2*100;
    }

    IACmotor_100 = tmp1;
    IACmotor_pos_tmp = tmp2;

    if (outpc.rpmdot < flash5.pwmidle_rpmdot_disablepid) {
        if (savelast && (outpc.rpm < rpm_thresh)) {
            IACmotor_last = IACmotor_pos_tmp;
        }
    } else {
        if ((outpc.rpm >= rpm_thresh) &&
            (pwmidle_reset & PWMIDLE_RESET_PID)) {
            pwmidle_reset = PWMIDLE_RESET_JUSTLIFTED;
            outpc.status2 &= ~status2_pwmidle_closedloop;
            idle_wait_timer = 0;
            return;
        }
    }

    pwmidle_reset = PWMIDLE_RESET_PID;
}

int idle_closed_loop_newtarg(unsigned int nt_targ_rpm, unsigned char ramptime)
{
    int new_targ, rpm;

    /* This function gradually drops the target from where it is now
     * to the end target
     */

    if ((pwmidle_reset & PWMIDLE_RESET_CALCNEWTARG) ||
            (pwmidle_reset & PWMIDLE_RESET_JUSTCRANKED)) {
        /* first time here, figure out number of steps
         * and the amount per step
         */

        if (outpc.rpm > nt_targ_rpm) {
            rpm = outpc.rpm;
            pwmidle_targ_numsteps = (ramptime * 100U) /
                flash5.pwmidle_ms;
            if (pwmidle_targ_numsteps > 0) {
                pwmidle_targ_stepsize = 
                    (rpm - nt_targ_rpm) / pwmidle_targ_numsteps;
                if (pwmidle_targ_stepsize == 0) {
                    pwmidle_targ_stepsize = 1;
                }
                pwmidle_targ_last = rpm;
                return rpm;
            } else {
                pwmidle_targ_last = 0;
                return nt_targ_rpm;
            }
        } else {
            pwmidle_targ_last = 0;
            return nt_targ_rpm;
        }
    }

    if (pwmidle_targ_last != 0) {
        new_targ = pwmidle_targ_last - pwmidle_targ_stepsize;
        if (new_targ >= (int)nt_targ_rpm) {
            pwmidle_targ_last = new_targ;
            return new_targ;
        } 
        pwmidle_targ_last = 0;
    }
    return nt_targ_rpm;
}

void idle_closed_loop_calc_dp_decay(void)
{
    int subtractor, tmp1;

    if (outpc.rpmdot >= 0) {
        return;
    }

    subtractor = ((pg5_ptr->pwmidle_dp_decay_factor*10)/-outpc.rpmdot);

    tmp1 = IACmotor_pos_tmp - subtractor;

    if (tmp1 < IACmotor_last) {
        tmp1 = IACmotor_last;
    }

    IACmotor_pos_tmp = tmp1;
}

void idle_target_lookup(void)
{
    if ((IdleCtl == 6) || (IdleCtl == 7) || (IdleCtl == 8) ||
        ((flash8.idle_special_ops & 0x07) == 0x04)) {
        targ_rpm = intrp_1ditable(outpc.clt,PWMIDLE_NUM_BINS,(int *)pg5_ptr->pwmidle_clt_temps, 0,
                                 (unsigned int *)pg5_ptr->pwmidle_target_rpms);

        targ_rpm += ac_idleup_cl_targetadder; 
        if (IdleCtl < 6) {
            outpc.cl_idle_targ_rpm = targ_rpm; // target for open-loop
        }
    }
}

void idle_closed_loop(void)
{
    unsigned int rpm_thresh, adj_targ;
    int pos;

    adj_targ = targ_rpm;
    rpm_thresh = targ_rpm + 200;
    if (((outpc.engine & ENGINE_CRANK) || (outpc.rpm == 0)) && (resetholdoff == 0)) {
        /* cranking */
        pos = intrp_1ditable(outpc.clt, 4, (int *)pg5_ptr->pwmidle_crank_clt_temps, 0,
                             (unsigned int *)pg5_ptr->pwmidle_crank_dutyorsteps); 
        DISABLE_INTERRUPTS;
        IACmotor_pos = pos;
        IACmotor_last = pos;
        IACmotor_pos_tmp = pos;
        idle_wait_timer = 0;
        ENABLE_INTERRUPTS;
        valve_closed = 0;
        outpc.status2 &= ~status2_pwmidle_closedloop;
        pwmidle_reset = PWMIDLE_RESET_JUSTCRANKED;
    } else {
        if ((outpc.tps >= (int)flash5.pwmidle_tps_thresh || 
            (pwmidle_reset & PWMIDLE_RESET_INGEAR))) {
            idle_closed_loop_throttlepressed(rpm_thresh);
        } else {
            if ((pwmidle_reset & PWMIDLE_RESET_DPADDED) &&
                (flagbyte15 & FLAGBYTE15_DPCNT)) {
                DISABLE_INTERRUPTS;
                flagbyte15 &= ~FLAGBYTE15_DPCNT;
                ENABLE_INTERRUPTS;
                idle_closed_loop_calc_dp_decay();
            }
            if (pwmidle_reset & PWMIDLE_RESET_JUSTLIFTED) {
                idle_closed_loop_throttlelifted(rpm_thresh, targ_rpm);
            } else {
                /* just after crank */
                unsigned char ramptime;

                if (pwmidle_reset & PWMIDLE_RESET_JUSTCRANKED) {
                    ramptime = flash5.pwmidlecranktaper;
                } else {
                    ramptime = flash5.pwmidle_targ_ramptime;
                }

                if ((flagbyte2 & flagbyte2_runidle) &&
                        (idle_wait_timer >= flash5.pwmidle_pid_wait_timer) && !IAC_moving) {

                    adj_targ = idle_closed_loop_newtarg(targ_rpm, ramptime);
                    idle_closed_loop_pid(adj_targ, rpm_thresh, adj_targ == targ_rpm);
                    DISABLE_INTERRUPTS;
                    flagbyte2 &= ~flagbyte2_runidle;
                    ENABLE_INTERRUPTS;
                    outpc.cl_idle_targ_rpm = adj_targ; // the actual target we are using including taper
                } 
            }

            pos = IACmotor_pos_tmp;

            if ((!flash5.pwmidle_close_delay) ||
                    (outpc.rpm <= flash5.pwmidle_shift_lower_rpm) ||
                    (pwmidle_shift_timer > flash5.pwmidle_shift_open_time)) {
                pos += ac_idleup_adder;
                pos += idle_voltage_comp;
            }

            pos += datax1.IdleAdj - idleadj_last; /* Apply delta of remote idle adjustment once */
            idleadj_last = datax1.IdleAdj;

            if (pos < (int)flash5.pwmidle_closed_duty) {
                pos = flash5.pwmidle_closed_duty;
            } else if (pos > (int)flash5.pwmidle_open_duty) {
                pos = flash5.pwmidle_open_duty;
            }

            IACmotor_pos = pos;
        }
    }

    if ((IdleCtl == 7) || (IdleCtl == 8)) {
        (void)move_IACmotor();
    }
}

void idle_ctl(void)
{
    if (pwmidle_reset & PWMIDLE_RESET_INIT) {
        if (!IAC_moving) {
            // When stepper idle has stopped homing, clear the flag
            // for CL modes, calc a new target
            pwmidle_reset = PWMIDLE_RESET_CALCNEWTARG;
        } else {
            return; // do nothing else until it homed (steppers only)
        }
    }

    /* Next fragment was in idle_ac_idleup */
    if (outpc.rpm && !(outpc.engine & ENGINE_CRANK)) { // dont enable when engine stopped.
        /* clutch/neutral not engaged, force throttle pressed */ 
        if ((flash12.ClutchPIDEntry & 0x01) && (PORTE & 0x1)) {
            pwmidle_reset |= PWMIDLE_RESET_INGEAR;
        }
    }

    /* idle voltage compensation */
    idle_voltage_comp = intrp_1ditable(outpc.batt, 6, (int *)pg12_ptr->idle_voltage_comp_voltage,
        1, (int *)pg12_ptr->idle_voltage_comp_delta);

    idle_ac_idleup();

    if (iactest_glob ) {
        if (!IAC_moving) {
            idle_test_mode();
        }
    } else {
        if (IdleCtl == 1)  {
            idle_on_off();
        } else if ((IdleCtl == 2) || (IdleCtl == 3) || (IdleCtl == 5))  {
            idle_iac_warmup();
        } else if (IdleCtl == 4) {
            if (((flash5.pwmidleset & 0x80) == 0) && ((outpc.engine & ENGINE_READY) == 0)) {
                IACmotor_pos = 0; // force it off
            } else {
                idle_pwm_warmup();
            }
        } else if (IdleCtl == 6) {
            if (((flash5.pwmidleset & 0x80) == 0) && ((outpc.engine & ENGINE_READY) == 0)) {
                IACmotor_pos = 0; // force it off
            } else {
                idle_closed_loop();
            }
        } else if ((IdleCtl == 7) || (IdleCtl == 8)) {
            idle_closed_loop();
        }
    }

    idle_pwmdithcalc();
}

void idle_pwmdithcalc(void)
{
    if ((IdleCtl == 4) || (IdleCtl == 6)) {
        /* calc software PWM for isr_rtc.s */
        unsigned char div;
        unsigned int max, trig, dith, pos;
        div = (flash5.pwmidle_freq & 0x0f) + 1;

        max = 255 / div;
        if (IACmotor_pos > 255) {
            IACmotor_pos = 255;
        }
        if (flash5.pwmidleset & 2) {
            pos = 255 - IACmotor_pos;
        } else {
            pos = IACmotor_pos;
        }
        trig = pos / div;
        dith = pos % div;
        dith = (dith * 4) / div;

        if (dith == 0) {
            idle_max_on[0] = trig; // on time
            idle_max_on[1] = idle_max_on[0];
            idle_max_on[2] = idle_max_on[0];
            idle_max_on[3] = idle_max_on[0];
            idle_max_off[0] = max - trig; // off time
            idle_max_off[1] = idle_max_off[0];
            idle_max_off[2] = idle_max_off[0];
            idle_max_off[3] = idle_max_off[0];
        } else if (dith == 1) {
            idle_max_on[0] = trig; // on time
            idle_max_on[1] = idle_max_on[0];
            idle_max_on[2] = idle_max_on[0];
            idle_max_on[3] = idle_max_on[0] + 1;
            idle_max_off[0] = max - trig; // off time
            idle_max_off[1] = idle_max_off[0];
            idle_max_off[2] = idle_max_off[0];
            if (idle_max_off[0] > 0) {
                idle_max_off[3] = idle_max_off[0] - 1;
            } else {
                idle_max_off[3] = 0;
            }
        } else if (dith == 2) {
            idle_max_on[0] = trig; // on time
            idle_max_on[1] = idle_max_on[0];
            idle_max_on[2] = idle_max_on[0] + 1;
            idle_max_on[3] = idle_max_on[0] + 1;
            idle_max_off[0] = max - trig; // off time
            idle_max_off[1] = idle_max_off[0];
            if (idle_max_off[0] > 0) {
                idle_max_off[2] = idle_max_off[0] - 1;
            } else {
                idle_max_off[2] = 0;
            }
            idle_max_off[3] = idle_max_off[2];
        } else if (dith == 3) {
            idle_max_on[0] = trig; // on time
            idle_max_on[1] = idle_max_on[0] + 1;
            idle_max_on[2] = idle_max_on[0] + 1;
            idle_max_on[3] = idle_max_on[0] + 1;
            idle_max_off[0] = max - trig; // off time
            if (idle_max_off[0] > 0) {
                idle_max_off[1] = idle_max_off[0] - 1;
            } else {
                idle_max_off[1] = 0;
            }
            idle_max_off[2] = idle_max_off[1];
            idle_max_off[3] = idle_max_off[1];
        }
        if ((pwm_idle_stat & 1) == 0) {
            pwm_idle_clk = 1; // bring it back to earth
            pwm_idle_stat |= 1; // enabled
        }
    }
}

int move_IACmotor(void)
{
    //unsigned char coils;
    short del;

    if ((IAC_moving) || (outpc.iacstep == IACmotor_pos)) {
        return 0;
    }

    if ((IdleCtl == 4) || (IdleCtl == 6)) {
        /* PWM idle */
        return 0;
    }

    del = IACmotor_pos - outpc.iacstep;
    if (del < 0) {
        del = -del;
    }

    if (del < pg4_ptr->IACminstep) {
        return 0;
    }

    // set up the motor move

    DISABLE_INTERRUPTS;
    motor_time_ms = flash4.IAC_tinitial_step;  // units changed to 1 ms
    ENABLE_INTERRUPTS
    if (pol_iacen) {
 // inverted enable current to motor (set bit= 1)
        iac_dty = 2;
    } else {
 // enable current to motor always(set bit= 0)
        iac_dty = 0;
    }
    IAC_moving = 2;
    return 1;
}
