/* $Id: premain.c,v 1.4 2010/10/01 00:32:46 jsmcortina Exp $ */
void __premain() 
{ 
	(*((volatile unsigned char*)(0x0030))) = 0x3d; //PPAGE set to 0x3C
} 

